# Nova Siege — GitHub Pages Edition

A sci-fi HUD space shooter that runs entirely in the browser. Your ship follows the mouse (or your finger) and auto-fires through endless waves, with a boss fight every fifth wave. Farm coins, upgrade in the Hangar, buy ships and perks in the Store, climb the Battle Pass, claim daily rewards, and pull 4★ and 5★ ships from the Warp Gate.

Free to play. No ads, no purchases, no server, no sign-in.

---

## Tech stack

| Part | Technology |
| --- | --- |
| Language | **TypeScript** (strict) |
| UI (menus, HUD, screens) | **React 19** |
| Styling | **Tailwind CSS 4** + CSS custom properties (`src/theme-tokens.css`) |
| Battle engine | **HTML Canvas 2D** (`src/engine/`) |
| Music and sound effects | **Web Audio API**, fully synthesised in code (`src/audio/`), no audio files |
| State | **Jotai**, saved to the browser's `localStorage` |
| Icons | **lucide-react** |
| Build tool | **Vite** |

## Project structure

```
nova-siege/
├── index.html                     Page shell (fonts, mobile meta tags)
├── vite.config.ts                 Build config (relative base for GitHub Pages)
├── package.json
├── .github/workflows/deploy.yml   Automatic GitHub Pages deployment
├── public/
│   ├── favicon.svg
│   └── images/                    Ship, boss, key-art and Warp Gate artwork
└── src/
    ├── main.tsx                   Entry point
    ├── App.tsx                    Screen switching, age gate, music per screen
    ├── index.css, theme-tokens.css    Tailwind setup + Vector HUD theme
    ├── engine/                    Canvas game: player, enemies, bosses, physics, drawing
    ├── audio/                     Web Audio synth and songs (menu, combat, boss, warp)
    ├── data/                      Ships, upgrades, perks, pass, gacha, saves, ranking, legal text
    ├── hooks/useSave.ts           Loads and saves progress on the device
    └── components/                Menus, HUD, Store, Warp Gate, Leaderboard, Legal, Download
```

---

## 1. Run the game on your computer

You need **Node.js 20 or newer**. Download the LTS version from <https://nodejs.org> and install it.

1. Unzip `nova-siege-github-edition.zip`. You get a folder called `nova-siege`.
2. Open a terminal in that folder:
   - **Windows:** open the folder in File Explorer, click the address bar, type `cmd`, press Enter.
   - **Mac:** right-click the folder in Finder > *New Terminal at Folder*.
3. Install the packages (only needed once):
   ```bash
   npm install
   ```
4. Start the game:
   ```bash
   npm run dev
   ```
5. Open the address it prints (usually <http://localhost:5173>) in your browser. Click once anywhere to enable sound.

To test on your phone on the same Wi-Fi, run `npm run dev -- --host` and open the "Network" address it prints.

Other commands:

```bash
npm run build      # production build into dist/
npm run preview    # serve the production build locally
npm run typecheck  # check the TypeScript code for errors
```

---

## 2. Publish on GitHub Pages (free)

### A. Create the repository

1. Sign in at <https://github.com> (create a free account if needed).
2. Click **+** (top right) > **New repository**.
3. Name it, for example `nova-siege`. Choose **Public**. Do **not** add a README (this project already has one). Click **Create repository**.

### B. Upload the code

**Option 1: GitHub Desktop (no commands)**

1. Install GitHub Desktop from <https://desktop.github.com> and sign in.
2. *File > Add local repository*, choose the `nova-siege` folder. When asked, click **create a repository**.
3. Click **Publish repository**, pick your account, keep the name, untick "Keep this code private", and publish.

**Option 2: Command line** (replace `YOUR-USERNAME`)

```bash
git init
git add .
git commit -m "Nova Siege"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/nova-siege.git
git push -u origin main
```

> Upload the folder **with** the hidden `.github` folder. The GitHub website's drag-and-drop uploader can skip it; GitHub Desktop and git include it.

### C. Turn on GitHub Pages

1. In your repository, open **Settings > Pages**.
2. Under **Build and deployment > Source**, choose **GitHub Actions**.
3. Open the **Actions** tab. The *Deploy to GitHub Pages* workflow runs on every push to `main` (or start it with **Run workflow**).
4. When it shows a green check, your game is live at:

```
https://YOUR-USERNAME.github.io/nova-siege/
```

Share that link. Anyone can play on desktop or mobile.

### D. Updating the game

Change the code, then commit and push (GitHub Desktop: *Commit to main* > *Push origin*). The site redeploys automatically in about a minute.

---

## 3. Differences from the original hosted edition

| Feature | GitHub Pages edition |
| --- | --- |
| Gameplay, ships, enemies, bosses, upgrades, perks, Store, Warp Gate, Battle Pass, Rewards, music and sound | Unchanged |
| Leaderboard | **Local**: ranks your top 50 runs on this device (highest wave and most kills in one run), stored in `localStorage` |
| Player identity | None needed; set a callsign on the Leaderboard screen |
| Save and restore | Unchanged: *Download* screen > **Download save** exports a JSON file; **Restore from file** loads it on any device or browser |
| Hosting | Static files only; no backend, API keys or accounts |

Progress is stored per browser and per website address. Players moving to a new device should use **Download save** and **Restore from file**.

### Adding a global leaderboard later (optional)

GitHub Pages cannot run server code. To share scores between players, add a hosted database such as Firebase or Supabase, then replace `src/components/menu/Leaderboard.tsx` and `src/data/localRanking.ts` with calls to it.

---

## 4. Customising

| What | Where |
| --- | --- |
| Colours, fonts, corner cuts | `src/theme-tokens.css` |
| Ships and their stats | `SHIPS` in `src/data/config.ts` |
| Upgrade and perk costs | `UPGRADES`, `PERKS` in `src/data/config.ts` |
| Warp Gate odds, cost, pity | `src/data/gacha.ts` and `src/data/config.ts` |
| Enemy waves and difficulty | `src/engine/enemies.ts`, `src/engine/Game.ts` |
| Boss attack patterns | `src/engine/boss.ts` |
| Music (notes, tempo, sections) | `src/audio/songs.ts` |
| Sound effects | `sfx()` in `src/audio/arcadeAudio.ts` |
| Terms, Privacy Policy, age limit | `src/data/legal.ts` (raise `LEGAL_VERSION` when the text changes so players re-accept) |
| Artwork | Replace files in `public/images/` (keep the same names) |
| Donation details, QR codes, card checkout | `src/data/donate.ts` (see below) |

If the ZIP was created in a browser that could not download the artwork, `src/data/config.ts` keeps the original online image addresses. The game still works; to host the images yourself, save each image into `public/images/` and change its address in `config.ts` to `./images/<file>.jpg`.

### Support page (donations)

Every payment detail on the Support page is in `src/data/donate.ts`. The game never processes money: players finish every donation in their own app or on a hosted checkout page.

1. **Add your QR codes:** create the folder `public/donate/`, save your images there (for example `momo-qr.png`, `zalopay-qr.png`, `mbbank-qr.png`), then set `qrImage: './donate/momo-qr.png'` (and so on) for each method. Until then the page shows a "QR not added yet" frame.
2. **Official logos (optional):** put logo files in `public/donate/` and set `logo: './donate/momo-logo.png'`. Empty keeps the built-in badge.
3. **Card donations:** create a hosted donation or checkout page with a payment provider that supports your country, then set `international.checkoutUrl` to its `https://` address and `providerName` to the provider's name. If the provider accepts an amount in the address, keep `passAmount: true` and set `amountParam` / `currencyParam` to its parameter names; otherwise set `passAmount: false`. While the address is empty, the Visa button shows a "not connected yet" message and nothing is charged.
4. **Never** add card number, CVV or expiry fields to the game — the card form must stay on the provider's page.

---

## 5. Troubleshooting

- **Blank page on GitHub Pages:** check *Settings > Pages > Source* is **GitHub Actions** and the latest workflow run is green, then hard-refresh (Ctrl+F5 / Cmd+Shift+R).
- **`npm` is not recognised:** Node.js is not installed, or the terminal was opened before installing it. Install Node.js and open a new terminal.
- **No sound:** browsers only allow audio after a click or key press. Click once and check the music and sound switches on the main menu.
- **Workflow fails at `npm install`:** open the failed step in the Actions tab to read the message; re-running often fixes temporary network errors.

---

## Legal

Created by **Bảo Lâm Nguyễn**. All rights reserved unless you add a licence file. The in-game Terms of Use and Privacy Policy live in `src/data/legal.ts`; review them before publishing and add your contact email.
