import { useState } from 'react';
import { AGE_RATING, EFFECTIVE_DATE, MIN_AGE, PRIVACY, TERMS, type LegalTab } from '@generated/data/legal';
import { ScreenShell } from '@generated/components/menu/ScreenShell';
import { Panel } from '@generated/components/hud/Panel';
import { LegalDocument } from '@generated/components/legal/LegalDocument';
import { DataControls } from '@generated/components/legal/DataControls';
import { cn } from '@lib/utils';

const TABS: { id: LegalTab; label: string }[] = [
  { id: 'terms', label: 'Terms of Use' },
  { id: 'privacy', label: 'Privacy Policy' },
  { id: 'age', label: `Age ${MIN_AGE}+` },
];

export function AgeRating() {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center gap-5">
        <div className="hud-bloom-strong grid size-24 shrink-0 place-items-center rounded-[var(--radius-badge)] border-2 border-foreground font-[family-name:var(--font-display)] text-4xl">
          {AGE_RATING.label}
        </div>
        <p className="min-w-0 max-w-[60ch] text-sm leading-relaxed text-foreground/85">{AGE_RATING.parents}</p>
      </div>
      <dl className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        {AGE_RATING.descriptors.map((d) => (
          <div key={d.title} className="min-w-0 border-t border-foreground/15 pt-3">
            <dt className="text-xs font-bold uppercase tracking-[0.1em]">{d.title}</dt>
            <dd className="mt-1 text-sm leading-relaxed text-muted-foreground">{d.text}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}

export function LegalScreen({ onBack, initialTab = 'terms' }: { onBack: () => void; initialTab?: LegalTab }) {
  const [tab, setTab] = useState<LegalTab>(initialTab);
  return (
    <ScreenShell section="COMMAND // LEGAL" title="Terms & privacy" subtitle={`Effective ${EFFECTIVE_DATE}. Nova Siege is free, ad-free and for players ${MIN_AGE} and older.`} onBack={onBack}>
      <div role="tablist" aria-label="Policies" className="flex flex-wrap gap-2">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            role="tab"
            aria-selected={tab === t.id}
            onClick={() => setTab(t.id)}
            className={cn(
              'hud-chamfer hud-chamfer-xs min-h-11 px-4 text-xs font-bold uppercase tracking-[0.12em] transition-colors',
              tab === t.id ? 'bg-foreground text-[hsl(var(--ink))]' : 'bg-foreground/10 hover:bg-foreground/20',
            )}
          >
            {t.label}
          </button>
        ))}
      </div>
      <div className="mt-6 flex flex-col gap-8">
        {tab === 'terms' && (
          <Panel label="TERMS // OF USE">
            <LegalDocument sections={TERMS} />
          </Panel>
        )}
        {tab === 'privacy' && (
          <>
            <Panel label="PRIVACY // POLICY">
              <LegalDocument sections={PRIVACY} />
            </Panel>
            <DataControls />
          </>
        )}
        {tab === 'age' && (
          <Panel label="AGE // RATING">
            <AgeRating />
          </Panel>
        )}
      </div>
    </ScreenShell>
  );
}
