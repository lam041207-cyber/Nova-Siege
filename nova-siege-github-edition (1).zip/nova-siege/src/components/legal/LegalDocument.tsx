import type { LegalSection } from '@generated/data/legal';
import { cn } from '@lib/utils';

/** Readable long-form policy text: hairline-separated sections, comfortable measure. */
export function LegalDocument({ sections, compact }: { sections: LegalSection[]; compact?: boolean }) {
  return (
    <div className={cn('flex flex-col', compact ? 'gap-4' : 'gap-6')}>
      {sections.map((s) => (
        <section key={s.title} className="min-w-0 border-t border-foreground/15 pt-4 first:border-t-0 first:pt-0">
          <h2 className={cn('font-bold uppercase tracking-[0.08em]', compact ? 'text-xs' : 'text-sm')}>{s.title}</h2>
          {s.body.map((p) => (
            <p key={p.slice(0, 40)} className={cn('mt-2 max-w-[68ch] break-words leading-relaxed text-foreground/85', compact ? 'text-xs' : 'text-sm')}>
              {p}
            </p>
          ))}
          {s.list && (
            <ul className="mt-2 flex max-w-[68ch] flex-col gap-1.5">
              {s.list.map((li) => (
                <li key={li.slice(0, 40)} className={cn('flex gap-2 leading-relaxed text-foreground/85', compact ? 'text-xs' : 'text-sm')}>
                  <span aria-hidden className="mt-[0.55em] size-1 shrink-0 bg-foreground" />
                  <span className="min-w-0 break-words">{li}</span>
                </li>
              ))}
            </ul>
          )}
        </section>
      ))}
    </div>
  );
}
