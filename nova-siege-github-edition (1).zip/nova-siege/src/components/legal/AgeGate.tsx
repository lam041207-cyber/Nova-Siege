import { useMemo, useState } from 'react';
import { ShieldCheck, ShieldX } from 'lucide-react';
import { EFFECTIVE_DATE, LEGAL_VERSION, MIN_AGE, PRIVACY, TERMS } from '@generated/data/legal';
import { useSave } from '@generated/hooks/useSave';
import { audio } from '@generated/audio/arcadeAudio';
import { Panel, IdBadge } from '@generated/components/hud/Panel';
import { HudButton } from '@generated/components/hud/HudButton';
import { LegalDocument } from '@generated/components/legal/LegalDocument';
import { AgeRating } from '@generated/components/legal/LegalScreen';
import { cn } from '@lib/utils';

type Doc = 'terms' | 'privacy' | null;

/** First-launch clearance: neutral birth-year check + acceptance of Terms and Privacy Policy. */
export function AgeGate() {
  const { save, update } = useSave();
  const thisYear = new Date().getFullYear();
  const years = useMemo(() => Array.from({ length: 101 }, (_, i) => thisYear - i), [thisYear]);
  const [year, setYear] = useState('');
  const [agree, setAgree] = useState(false);
  const [doc, setDoc] = useState<Doc>(null);
  const isUpdate = save.legal.version !== null && save.legal.version !== LEGAL_VERSION;

  if (save.legal.underage) {
    return (
      <div className="mx-auto grid min-h-[100dvh] w-full max-w-xl place-items-center px-4 py-10">
        <Panel label="ACCESS // RESTRICTED" className="hud-rise w-full">
          <ShieldX className="size-8" strokeWidth={1.5} />
          <h1 className="mt-4 text-2xl font-light tracking-tight">Nova Siege is for players {MIN_AGE} and older.</h1>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
            Thanks for your interest, pilot. Come back when you are old enough to fly. Parents and guardians can read the age rating below.
          </p>
          <div className="mt-6 border-t border-foreground/15 pt-5">
            <AgeRating />
          </div>
        </Panel>
      </div>
    );
  }

  const age = year ? thisYear - Number(year) : null;
  const canSubmit = age !== null && agree;

  const submit = () => {
    if (age === null) return;
    if (age < MIN_AGE) {
      audio.sfx('error');
      update((s) => ({ ...s, legal: { version: null, acceptedAt: null, underage: true } }));
      return;
    }
    audio.sfx('claim');
    update((s) => ({ ...s, legal: { version: LEGAL_VERSION, acceptedAt: new Date().toISOString(), underage: false } }));
  };

  return (
    <div className="mx-auto grid min-h-[100dvh] w-full max-w-2xl place-items-center px-4 py-10">
      <Panel label="PILOT // CLEARANCE" active className="hud-rise w-full">
        <div className="flex items-start gap-4">
          <IdBadge code={`${MIN_AGE}+`} className="hidden sm:flex" />
          <div className="min-w-0">
            <div className="text-xs font-bold tracking-[0.2em] text-muted-foreground">{isUpdate ? 'POLICIES UPDATED' : 'BEFORE YOU LAUNCH'}</div>
            <h1 className="hud-text-glow mt-2 text-3xl font-light tracking-tight sm:text-4xl">Welcome to Nova Siege</h1>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              {isUpdate
                ? `Our Terms of Use and Privacy Policy changed on ${EFFECTIVE_DATE}. Please review and accept them to keep playing.`
                : `Free to play, no ads, no purchases. Players must be ${MIN_AGE} or older.`}
            </p>
          </div>
        </div>

        <label className="mt-6 block">
          <span className="text-xs font-bold uppercase tracking-[0.12em]">Your birth year</span>
          <select
            value={year}
            onChange={(e) => setYear(e.target.value)}
            className="hud-chamfer hud-chamfer-xs mt-2 block min-h-11 w-full bg-foreground/10 px-3 text-base text-foreground outline-none focus-visible:bg-foreground/20 sm:w-56"
          >
            <option value="" className="bg-background">Select year</option>
            {years.map((y) => (
              <option key={y} value={y} className="bg-background">
                {y}
              </option>
            ))}
          </select>
        </label>

        <div className="mt-5 flex flex-wrap gap-2">
          {(['terms', 'privacy'] as const).map((d) => (
            <button
              key={d}
              type="button"
              aria-expanded={doc === d}
              onClick={() => setDoc(doc === d ? null : d)}
              className={cn(
                'hud-chamfer hud-chamfer-xs min-h-11 px-3 text-xs font-bold uppercase tracking-[0.12em] transition-colors',
                doc === d ? 'bg-foreground text-[hsl(var(--ink))]' : 'bg-foreground/10 hover:bg-foreground/20',
              )}
            >
              {doc === d ? 'Hide' : 'Read'} {d === 'terms' ? 'Terms of Use' : 'Privacy Policy'}
            </button>
          ))}
        </div>
        {doc && (
          <div className="mt-4 max-h-72 overflow-y-auto border border-foreground/20 p-4">
            <LegalDocument sections={doc === 'terms' ? TERMS : PRIVACY} compact />
          </div>
        )}

        <label className="mt-5 flex cursor-pointer items-start gap-3">
          <input
            type="checkbox"
            checked={agree}
            onChange={(e) => setAgree(e.target.checked)}
            className="mt-0.5 size-5 shrink-0 cursor-pointer accent-[hsl(var(--foreground))]"
          />
          <span className="text-sm leading-relaxed">
            I have read and agree to the Terms of Use and Privacy Policy. If I am under 18, my parent or guardian agrees too.
          </span>
        </label>

        <HudButton size="lg" className="mt-6 w-full" disabled={!canSubmit} onClick={submit}>
          <ShieldCheck className="size-5" /> Accept and continue
        </HudButton>
        <p className="mt-3 text-[11px] text-muted-foreground">Effective {EFFECTIVE_DATE}. Your answer is stored only on this device.</p>
      </Panel>
    </div>
  );
}
