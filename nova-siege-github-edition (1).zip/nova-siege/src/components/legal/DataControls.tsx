/** GitHub Pages edition of the privacy data controls: everything lives on this device. */
import { useState } from 'react';
import { ListX, Trash2 } from 'lucide-react';
import { eraseProgress } from '@generated/data/progress';
import { useSave } from '@generated/hooks/useSave';
import { audio } from '@generated/audio/arcadeAudio';
import { Panel } from '@generated/components/hud/Panel';
import { HudButton } from '@generated/components/hud/HudButton';
import { clearRuns } from '@generated/data/localRanking';

export function DataControls() {
  const { update } = useSave();
  const [cleared, setCleared] = useState(false);
  const [confirmErase, setConfirmErase] = useState(false);
  const [erased, setErased] = useState(false);

  const clearBoard = () => {
    clearRuns();
    setCleared(true);
    audio.sfx('claim');
  };

  const erase = () => {
    if (!confirmErase) {
      setConfirmErase(true);
      return;
    }
    update(eraseProgress);
    clearRuns();
    setConfirmErase(false);
    setErased(true);
    audio.sfx('bomb');
  };

  return (
    <Panel label="DATA // CONTROLS" active>
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <div className="min-w-0">
          <h3 className="text-sm font-bold uppercase tracking-[0.08em]">Local leaderboard</h3>
          <p className="mt-1 text-xs leading-relaxed text-muted-foreground">Deletes every run recorded in this browser's ranking.</p>
          <HudButton variant="outline" size="sm" className="mt-3" onClick={clearBoard}>
            <ListX className="size-4" /> Clear ranking
          </HudButton>
          {cleared && (
            <p aria-live="polite" className="mt-2 text-xs text-foreground/85">
              Ranking cleared.
            </p>
          )}
        </div>
        <div className="min-w-0">
          <h3 className="text-sm font-bold uppercase tracking-[0.08em]">Local progress</h3>
          <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
            Erases coins, crystals, ships, upgrades, perks, pass progress and the ranking on this device. This cannot be undone.
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            <HudButton variant={confirmErase ? 'primary' : 'outline'} size="sm" onClick={erase}>
              <Trash2 className="size-4" /> {confirmErase ? 'Tap again to erase' : 'Erase progress'}
            </HudButton>
            {confirmErase && (
              <HudButton variant="outline" size="sm" onClick={() => setConfirmErase(false)}>
                Cancel
              </HudButton>
            )}
          </div>
          {erased && (
            <p aria-live="polite" className="mt-2 text-xs text-foreground/85">
              Progress erased. You are starting fresh.
            </p>
          )}
        </div>
      </div>
    </Panel>
  );
}
