import { useEffect, useRef, useState } from 'react';
import { Check, Copy } from 'lucide-react';
import { audio } from '@generated/audio/arcadeAudio';
import { copyText } from '@generated/components/donate/clipboard';
import { cn } from '@lib/utils';

interface Props {
  label: string;
  value: string;
  /** what the copy button announces, e.g. "phone number" */
  what: string;
  mono?: boolean;
}

/** Read-only detail row with a working copy button and inline confirmation. */
export function CopyField({ label, value, what, mono = true }: Props) {
  const [state, setState] = useState<'idle' | 'ok' | 'fail'>('idle');
  const timer = useRef<number | null>(null);

  useEffect(() => () => {
    if (timer.current) window.clearTimeout(timer.current);
  }, []);

  const copy = async () => {
    const ok = await copyText(value);
    setState(ok ? 'ok' : 'fail');
    audio.sfx(ok ? 'claim' : 'error');
    if (timer.current) window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setState('idle'), 2200);
  };

  return (
    <div className="min-w-0">
      <div className="text-[11px] font-bold uppercase tracking-[0.14em] text-muted-foreground">{label}</div>
      <div className="mt-1 flex items-stretch gap-2">
        <div
          className={cn(
            'hud-chamfer hud-chamfer-xs flex min-h-11 min-w-0 flex-1 items-center bg-foreground/[0.06] px-3 text-sm font-bold',
            mono && 'tabular-nums tracking-[0.08em]',
          )}
        >
          <span className="min-w-0 break-all">{value}</span>
        </div>
        <button
          type="button"
          onClick={copy}
          aria-label={`Copy ${what}`}
          className={cn(
            'hud-chamfer hud-chamfer-xs inline-flex min-h-11 min-w-11 shrink-0 items-center justify-center gap-1.5 px-3 text-[11px] font-bold uppercase tracking-[0.12em] transition-colors',
            state === 'ok'
              ? 'bg-[hsl(var(--gold))] text-[hsl(var(--ink))]'
              : 'bg-foreground/10 text-foreground hover:bg-[hsl(var(--gold)/0.2)] hover:text-[hsl(var(--gold))]',
          )}
        >
          {state === 'ok' ? <Check className="size-4" /> : <Copy className="size-4" />}
          <span className="hidden sm:inline">{state === 'ok' ? 'Copied' : 'Copy'}</span>
        </button>
      </div>
      <p aria-live="polite" className="sr-only">
        {state === 'ok' ? `${what} copied` : state === 'fail' ? `Could not copy ${what}` : ''}
      </p>
      {state === 'fail' && <p className="mt-1 text-[11px] text-destructive">Copy blocked by the browser. Press and hold the number to copy it.</p>}
    </div>
  );
}
