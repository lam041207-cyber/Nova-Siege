import { useId, useState } from 'react';
import { ArrowUpRight, ChevronDown, CircleAlert, Lock, ShieldCheck } from 'lucide-react';
import { CURRENCIES, DONATE, buildCheckoutUrl, checkoutReady, formatAmount, type CurrencyCode } from '@generated/data/donate';
import { audio } from '@generated/audio/arcadeAudio';
import { Panel } from '@generated/components/hud/Panel';
import { HudButton } from '@generated/components/hud/HudButton';
import { BrandMark } from '@generated/components/donate/BrandMark';
import { AmountPicker, EMPTY_AMOUNT, resolveAmount, type AmountState } from '@generated/components/donate/AmountPicker';

const isCurrency = (v: string): v is CurrencyCode => CURRENCIES.some((c) => c.code === v);

/** International donations: the game only builds a link to a hosted checkout; card details are entered on the provider's page. */
export function VisaPanel() {
  const selectId = useId();
  const [currency, setCurrency] = useState<CurrencyCode>('USD');
  const [amount, setAmount] = useState<AmountState>({ preset: 3, custom: '' });
  const [notice, setNotice] = useState(false);
  const ready = checkoutReady();
  const resolved = resolveAmount(amount, currency);
  const cfg = DONATE.international;

  const changeCurrency = (v: string) => {
    if (!isCurrency(v)) return;
    setCurrency(v);
    setAmount(v === 'VND' ? EMPTY_AMOUNT : { preset: 3, custom: '' });
  };

  const donate = () => {
    if (resolved.error) {
      audio.sfx('error');
      return;
    }
    const url = buildCheckoutUrl(resolved.value, currency);
    if (!url) {
      audio.sfx('error');
      setNotice(true);
      return;
    }
    audio.sfx('buy');
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <Panel label="INTL-01 // HOSTED CHECKOUT" tone="gold" innerClassName="grid grid-cols-1 gap-8 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
      <div className="flex min-w-0 flex-col gap-4">
        <div className="flex items-center gap-3">
          <BrandMark id="visa" name="Visa" />
          <div className="min-w-0">
            <h3 className="text-lg font-bold uppercase tracking-[0.04em]">{cfg.method}</h3>
            <p className="text-[11px] text-muted-foreground">{ready && cfg.providerName ? `Secured by ${cfg.providerName}` : 'For supporters outside Vietnam'}</p>
          </div>
        </div>
        <p className="max-w-[52ch] text-sm leading-relaxed text-foreground/85">
          Donate from anywhere with a Visa debit or credit card. You will be sent to a secure checkout page run by a payment provider, where you enter your card details and confirm.
        </p>
        <ul className="flex flex-col gap-2 text-xs leading-relaxed text-muted-foreground">
          <li className="flex gap-2"><Lock className="mt-0.5 size-3.5 shrink-0 text-[hsl(var(--gold))]" /> Nova Siege never asks for, sees or stores your card number, CVV or expiry date.</li>
          <li className="flex gap-2"><ShieldCheck className="mt-0.5 size-3.5 shrink-0 text-[hsl(var(--gold))]" /> Check for a padlock and the provider&apos;s address before paying.</li>
        </ul>
        <div
          className={`mt-auto inline-flex w-fit items-center gap-2 border px-2.5 py-1 text-[11px] font-bold uppercase tracking-[0.14em] ${ready ? 'border-[hsl(var(--gold))] text-[hsl(var(--gold))]' : 'border-foreground/25 text-muted-foreground'}`}
        >
          <span className={ready ? 'hud-blink' : ''}>●</span> {ready ? 'Checkout online' : 'Checkout coming soon'}
        </div>
      </div>

      <div className="flex min-w-0 flex-col gap-4">
        <div>
          <label htmlFor={selectId} className="block text-[11px] font-bold uppercase tracking-[0.14em] text-muted-foreground">Currency</label>
          <div className="hud-chamfer hud-chamfer-xs relative mt-1 w-full bg-foreground/[0.06] focus-within:bg-[hsl(var(--gold)/0.12)] sm:w-72">
            <select
              id={selectId}
              value={currency}
              onChange={(e) => changeCurrency(e.target.value)}
              className="min-h-11 w-full cursor-pointer appearance-none bg-transparent py-2 pl-3 pr-10 text-sm font-bold text-foreground outline-none [&>option]:bg-background"
            >
              {CURRENCIES.map((c) => (
                <option key={c.code} value={c.code}>{c.label}</option>
              ))}
            </select>
            <ChevronDown aria-hidden className="pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-[hsl(var(--gold))]" />
          </div>
        </div>
        <AmountPicker currency={currency} value={amount} onChange={setAmount} />
        <HudButton variant="gold" size="lg" onClick={donate} disabled={!!resolved.error} className="w-full">
          <ArrowUpRight className="size-5" />
          Donate with Visa{resolved.value !== null ? ` · ${formatAmount(resolved.value, currency)}` : ''}
        </HudButton>
        {notice && !ready && (
          <output className="hud-rise flex gap-3 border-l-2 border-[hsl(var(--gold))] bg-[hsl(var(--gold)/0.07)] p-4">
            <CircleAlert className="mt-0.5 size-4 shrink-0 text-[hsl(var(--gold))]" />
            <div className="text-xs leading-relaxed text-foreground/85">
              <div className="font-bold uppercase tracking-[0.12em] text-[hsl(var(--gold))]">Card checkout is not connected yet</div>
              No payment was started and nothing was charged. The developer is still setting up a secure card provider. Thank you for wanting to help — please check back soon, or use a Vietnam method above if you can.
            </div>
          </output>
        )}
      </div>
    </Panel>
  );
}
