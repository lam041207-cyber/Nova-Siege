import { Rocket, Sparkles, Wrench } from 'lucide-react';

const POINTS = [
  { icon: Wrench, title: 'Game development and maintenance', note: 'Bug fixes, performance and keeping the game online.' },
  { icon: Rocket, title: 'New ships, bosses, and future updates', note: 'Fresh hulls, harder sieges and new seasons.' },
  { icon: Sparkles, title: 'Improving the player experience', note: 'Smoother controls, clearer menus, better sound.' },
] as const;

/** Transparency block: where voluntary support goes, plus the thank-you note. */
export function SupportHelps() {
  return (
    <section className="mt-16" aria-labelledby="helps-head">
      <div className="text-xs font-bold tracking-[0.2em] text-[hsl(var(--gold))]">{'03 // TRANSPARENCY'}</div>
      <h2 id="helps-head" className="mt-1 text-2xl font-light uppercase tracking-tight sm:text-3xl">How your support helps</h2>
      <ul className="mt-6 grid grid-cols-1 gap-px bg-foreground/15 md:grid-cols-3">
        {POINTS.map((p, i) => (
          <li key={p.title} className="donate-lift flex min-w-0 gap-4 bg-background p-5">
            <span className="font-[family-name:var(--font-display)] text-2xl leading-none text-[hsl(var(--gold))]">{String(i + 1).padStart(2, '0')}</span>
            <span className="min-w-0">
              <span className="flex items-center gap-2 text-sm font-bold uppercase tracking-[0.04em]">
                <p.icon className="size-4 shrink-0 text-[hsl(var(--gold))]" strokeWidth={1.75} />
                {p.title}
              </span>
              <span className="mt-1 block text-xs text-muted-foreground">{p.note}</span>
            </span>
          </li>
        ))}
      </ul>
      <p className="gold-text-glow mt-8 text-center text-lg font-light text-[hsl(var(--gold))] sm:text-xl">
        Thank you for supporting an independent game developer.
      </p>
    </section>
  );
}
