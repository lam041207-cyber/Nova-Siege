import { useState } from 'react';
import { ChevronLeft, ExternalLink, Info, ShieldCheck } from 'lucide-react';
import { SupportHelps } from '@generated/components/donate/SupportHelps';
import { DONATE } from '@generated/data/donate';
import { audio } from '@generated/audio/arcadeAudio';
import { MIN_AGE } from '@generated/data/legal';
import { LocalMethodCard } from '@generated/components/donate/LocalMethodCard';
import { VisaPanel } from '@generated/components/donate/VisaPanel';
import { AmountPicker, EMPTY_AMOUNT, resolveAmount, type AmountState } from '@generated/components/donate/AmountPicker';

const FLOW = [
  ['01', 'Pick an amount', 'Any amount helps. It is optional.'],
  ['02', 'Pay outside the game', 'In your wallet, bank app or a secure checkout.'],
  ['03', 'Fuel the next update', 'New ships, bosses and seasons.'],
] as const;

function SectionHead({ id, index, code, title, note }: { id: string; index: string; code: string; title: string; note: string }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-x-6 gap-y-2 border-b border-foreground/15 pb-4">
      <div className="min-w-0">
        <div className="text-xs font-bold tracking-[0.2em] text-[hsl(var(--gold))]">{`${index} // ${code}`}</div>
        <h2 id={id} className="mt-1 text-2xl font-light uppercase tracking-tight sm:text-3xl">{title}</h2>
      </div>
      <p className="max-w-sm text-xs text-muted-foreground">{note}</p>
    </div>
  );
}

export function DonateScreen({ onBack }: { onBack: () => void }) {
  const [vnd, setVnd] = useState<AmountState>(EMPTY_AMOUNT);
  const vndValue = resolveAmount(vnd, 'VND').value;

  return (
    <div className="mx-auto w-full max-w-6xl px-4 pb-20 pt-4 sm:px-6 sm:pt-6">
      <header className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => { audio.sfx('click'); onBack(); }}
          className="hud-chamfer hud-chamfer-xs inline-flex min-h-11 items-center gap-1 bg-foreground/10 px-3 text-xs font-bold tracking-[0.14em] transition-colors hover:bg-foreground/20"
        >
          <ChevronLeft className="size-4" /> BASE
        </button>
        <span className="text-[11px] font-bold tracking-[0.2em] text-muted-foreground">
          CHANNEL // OPEN <span className="hud-blink text-[hsl(var(--gold))]">●</span>
        </span>
      </header>

      <section className="hud-rise mt-10 grid grid-cols-1 gap-8 lg:grid-cols-[minmax(0,1.25fr)_minmax(0,1fr)] lg:items-end">
        <div className="min-w-0">
          <div className="text-xs font-bold tracking-[0.2em] text-[hsl(var(--gold))]">COMMAND // SUPPORT</div>
          <h1 className="mt-3 text-4xl font-light uppercase leading-[0.95] tracking-tight sm:text-6xl">
            <span className="hud-text-glow">Support the</span>
            <br />
            <span className="gold-text-glow font-bold text-[hsl(var(--gold))]">developer</span>
          </h1>
          <p className="mt-5 max-w-lg text-sm leading-relaxed text-foreground/80">
            Help keep Nova Siege alive. Your voluntary support helps fund new ships, updates, and future game development.
          </p>
          <p className="mt-5 flex max-w-lg gap-3 border-l-2 border-[hsl(var(--gold))] pl-4 text-xs leading-relaxed text-foreground/85">
            <ShieldCheck className="mt-0.5 size-4 shrink-0 text-[hsl(var(--gold))]" />
            <span>
              <span className="font-bold uppercase tracking-[0.1em] text-[hsl(var(--gold))]">Donations are completely optional. </span>
              Nova Siege is free to play, and no payment is required to access the game. Donations are voluntary contributions to support independent game development and do not provide in-game benefits.
            </span>
          </p>
        </div>
        <ol className="grid grid-cols-1 gap-px bg-foreground/15 sm:grid-cols-3 lg:grid-cols-1">
          {FLOW.map(([n, t, d]) => (
            <li key={n} className="flex gap-4 bg-background px-4 py-3">
              <span className="font-[family-name:var(--font-display)] text-2xl leading-none text-[hsl(var(--gold))]">{n}</span>
              <span className="min-w-0">
                <span className="block text-sm font-bold uppercase tracking-[0.06em]">{t}</span>
                <span className="block text-[11px] text-muted-foreground">{d}</span>
              </span>
            </li>
          ))}
        </ol>
      </section>

      <aside className="mt-10 flex gap-3 border border-[hsl(var(--gold)/0.5)] bg-[hsl(var(--gold)/0.06)] p-4 text-xs leading-relaxed text-foreground/85">
        <ExternalLink className="mt-0.5 size-4 shrink-0 text-[hsl(var(--gold))]" />
        <p>
          <span className="font-bold uppercase tracking-[0.1em] text-[hsl(var(--gold))]">Payments happen outside the game. </span>
          Payments are completed outside Nova Siege. The game does not process, verify, or refund donations. Please check the recipient&apos;s name and payment details before confirming your transfer.
        </p>
      </aside>

      <section className="mt-14" aria-labelledby="vn-head">
        <SectionHead id="vn-head" index="01" code="VIETNAM // LOCAL PAYMENTS" title="MoMo · ZaloPay · Bank" note="Copy the number, or scan a QR code once it is added, then send any amount in VND." />
        <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-start sm:gap-6">
          <div className="shrink-0 pt-1 text-[11px] font-bold uppercase tracking-[0.14em] text-muted-foreground sm:w-40">
            Amount // VND
            <span className="mt-1 block font-normal normal-case tracking-normal">Optional — shown as a reminder in the steps.</span>
          </div>
          <div className="min-w-0 flex-1 sm:max-w-xl">
            <AmountPicker currency="VND" value={vnd} onChange={setVnd} />
          </div>
        </div>
        <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {DONATE.local.map((m) => (
            <LocalMethodCard key={m.id} method={m} amount={vndValue} />
          ))}
        </div>
      </section>

      <section className="mt-16" aria-labelledby="intl-head">
        <SectionHead id="intl-head" index="02" code="INTERNATIONAL // VISA" title="Card donations" note="Choose $1, $3, $5, $10 or your own amount in USD, EUR or VND." />
        <div className="mt-8">
          <VisaPanel />
        </div>
      </section>

      <SupportHelps />

      <footer className="mt-14 flex gap-3 border-t border-foreground/15 pt-5 text-[11px] leading-relaxed text-muted-foreground">
        <Info className="mt-0.5 size-3.5 shrink-0" />
        <p className="max-w-3xl">
          Donations do not unlock ships, skins, coins, crystals, upgrades or any other advantage, and the game stays free for everyone.
          If you are under 18, ask a parent or guardian before donating. Players must be {MIN_AGE}+ to play.
        </p>
      </footer>
    </div>
  );
}
