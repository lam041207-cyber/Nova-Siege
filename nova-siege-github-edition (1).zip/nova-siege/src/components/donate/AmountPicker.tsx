import { useId } from 'react';
import { DONATE, formatAmount, parseAmount, type CurrencyCode } from '@generated/data/donate';
import { audio } from '@generated/audio/arcadeAudio';
import { cn } from '@lib/utils';

/** null preset + empty custom = "any amount" (donation amount is optional). */
export interface AmountState {
  preset: number | null;
  custom: string;
}

export const EMPTY_AMOUNT: AmountState = { preset: null, custom: '' };

/** Resolves the chosen amount: number, null for "any amount", or an error for a bad custom entry. */
export function resolveAmount(a: AmountState, currency: CurrencyCode): { value: number | null; error?: string } {
  if (a.preset !== null) return { value: a.preset };
  if (!a.custom.trim()) return { value: null };
  const r = parseAmount(a.custom, currency);
  return 'error' in r ? { value: null, error: r.error } : { value: r.value };
}

interface Props {
  currency: CurrencyCode;
  value: AmountState;
  onChange: (v: AmountState) => void;
  allowAny?: boolean;
}

export function AmountPicker({ currency, value, onChange, allowAny = true }: Props) {
  const inputId = useId();
  const presets = DONATE.amounts.presets[currency];
  const { error } = resolveAmount(value, currency);
  const anyOn = value.preset === null && !value.custom.trim();

  const chip = (active: boolean) =>
    cn(
      'hud-chamfer hud-chamfer-xs min-h-11 px-3 text-sm font-bold tabular-nums transition-colors',
      active
        ? 'bg-[hsl(var(--gold))] text-[hsl(var(--ink))]'
        : 'bg-foreground/[0.07] text-foreground hover:bg-[hsl(var(--gold)/0.18)] hover:text-[hsl(var(--gold))]',
    );

  return (
    <div className="min-w-0">
      <fieldset aria-label="Donation amount" className="m-0 flex min-w-0 flex-wrap gap-2 border-0 p-0">
        {allowAny && (
          <button type="button" aria-pressed={anyOn} onClick={() => { audio.sfx('click'); onChange(EMPTY_AMOUNT); }} className={chip(anyOn)}>
            Any
          </button>
        )}
        {presets.map((p) => (
          <button
            key={p}
            type="button"
            aria-pressed={value.preset === p}
            onClick={() => { audio.sfx('click'); onChange({ preset: p, custom: '' }); }}
            className={chip(value.preset === p)}
          >
            {formatAmount(p, currency)}
          </button>
        ))}
      </fieldset>
      <label htmlFor={inputId} className="mt-3 block text-[11px] font-bold uppercase tracking-[0.14em] text-muted-foreground">
        Custom amount ({currency})
      </label>
      <div
        className={cn(
          'hud-chamfer hud-chamfer-xs mt-1 flex min-h-11 items-center gap-2 bg-foreground/[0.06] px-3 ring-inset focus-within:ring-1',
          error ? 'ring-1 ring-destructive' : 'focus-within:ring-[hsl(var(--gold))]',
        )}
      >
        <span aria-hidden className="text-sm font-bold text-[hsl(var(--gold))]">{currency === 'VND' ? '₫' : currency === 'USD' ? '$' : '€'}</span>
        <input
          id={inputId}
          inputMode={currency === 'VND' ? 'numeric' : 'decimal'}
          autoComplete="off"
          placeholder={currency === 'VND' ? 'e.g. 30.000' : 'e.g. 7'}
          value={value.custom}
          onChange={(e) => onChange({ preset: null, custom: e.target.value.slice(0, 14) })}
          aria-invalid={!!error}
          aria-describedby={error ? `${inputId}-err` : undefined}
          className="min-w-0 flex-1 bg-transparent py-2 text-base font-bold tabular-nums outline-none placeholder:font-normal placeholder:text-muted-foreground/60"
        />
      </div>
      {error && <p id={`${inputId}-err`} className="mt-1 text-[11px] text-destructive">{error}</p>}
    </div>
  );
}
