import { useState } from 'react';
import { cn } from '@lib/utils';

export type BrandId = 'momo' | 'zalopay' | 'bank' | 'visa';

/** Badge colours per provider (tokens live in theme-tokens.css). */
const FRAME: Record<BrandId, string> = {
  momo: 'bg-[hsl(var(--brand-momo))]',
  zalopay: 'bg-[hsl(var(--brand-zalopay))]',
  bank: 'bg-[hsl(var(--brand-mb))]',
  visa: 'bg-[hsl(var(--brand-visa))]',
};

function Wordmark({ id }: { id: BrandId }) {
  switch (id) {
    case 'momo':
      return <span className="text-lg font-bold lowercase tracking-tight">mo<span className="opacity-80">mo</span></span>;
    case 'zalopay':
      return (
        <span className="text-[15px] font-bold tracking-tight">
          Zalo<span className="font-normal">Pay</span>
        </span>
      );
    case 'bank':
      return (
        <span className="flex items-center gap-1 text-lg font-bold tracking-tight">
          MB
          <span aria-hidden className="size-2 rotate-45 bg-[hsl(var(--brand-mb-accent))]" />
        </span>
      );
    case 'visa':
      return (
        <span className="text-xl font-bold italic tracking-[0.04em]">
          VIS<span className="text-[hsl(var(--brand-visa-accent))]">A</span>
        </span>
      );
  }
}

/**
 * Provider badge. Shows the official logo file when one is configured in data/donate.ts,
 * otherwise a clean wordmark tile in the provider's colour.
 */
export function BrandMark({ id, name, logo, className }: { id: BrandId; name: string; logo?: string; className?: string }) {
  const [broken, setBroken] = useState(false);
  const showLogo = !!logo && !broken;
  return (
    <div
      className={cn(
        'hud-chamfer hud-chamfer-xs flex h-12 min-w-[76px] shrink-0 items-center justify-center px-3 text-[hsl(var(--brand-ink))]',
        showLogo ? 'bg-[hsl(var(--brand-ink))]' : FRAME[id],
        className,
      )}
    >
      {showLogo ? (
        <img src={logo} alt={`${name} logo`} className="max-h-9 max-w-[96px] object-contain" onError={() => setBroken(true)} />
      ) : (
        <>
          <span className="sr-only">{`${name} logo`}</span>
          <span aria-hidden>
            <Wordmark id={id} />
          </span>
        </>
      )}
    </div>
  );
}
