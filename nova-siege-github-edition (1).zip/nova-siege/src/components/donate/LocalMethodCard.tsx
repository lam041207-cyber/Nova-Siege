import { useState } from 'react';
import { ArrowUpRight, HeartHandshake, UserCheck } from 'lucide-react';
import { DONATE, formatAmount, isSafeUrl, type LocalMethod } from '@generated/data/donate';
import { audio } from '@generated/audio/arcadeAudio';
import { Panel } from '@generated/components/hud/Panel';
import { HudButton } from '@generated/components/hud/HudButton';
import { BrandMark } from '@generated/components/donate/BrandMark';
import { CopyField } from '@generated/components/donate/CopyField';
import { QrSlot } from '@generated/components/donate/QrSlot';
import { copyText } from '@generated/components/donate/clipboard';

const CODE: Record<LocalMethod['id'], string> = { momo: 'VN-01 // E-WALLET', zalopay: 'VN-02 // E-WALLET', bank: 'VN-03 // NAPAS 24/7' };
const BUTTON: Record<LocalMethod['id'], string> = { momo: 'Donate with MoMo', zalopay: 'Donate with ZaloPay', bank: 'Donate via Bank Transfer' };

/** Recipient name, shown prominently so players can match it in their app before confirming. */
function Recipient({ name }: { name: string }) {
  if (!name) return null;
  return (
    <div className="hud-chamfer hud-chamfer-xs flex min-w-0 items-center gap-2 bg-[hsl(var(--gold)/0.1)] px-3 py-2">
      <UserCheck className="size-4 shrink-0 text-[hsl(var(--gold))]" strokeWidth={1.75} />
      <div className="min-w-0">
        <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-muted-foreground">Recipient</div>
        <div className="truncate text-sm font-bold tracking-[0.08em] text-[hsl(var(--gold))]">{name}</div>
      </div>
    </div>
  );
}

export function LocalMethodCard({ method, amount }: { method: LocalMethod; amount: number | null }) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const target = method.kind === 'wallet' ? method.phone : method.accountNumber;
  const hasLink = isSafeUrl(method.payUrl);

  const donate = async () => {
    audio.sfx('buy');
    if (hasLink) {
      window.open(method.payUrl, '_blank', 'noopener,noreferrer');
      return;
    }
    setCopied(await copyText(target));
    setOpen(true);
  };

  return (
    <div className="donate-lift min-w-0">
      <Panel label={CODE[method.id]} className="h-full" innerClassName="flex h-full flex-col gap-5">
        <div className="flex items-center gap-3">
          <BrandMark id={method.id} name={method.provider} logo={method.logo} />
          <div className="min-w-0">
            <h3 className="truncate text-lg font-bold uppercase tracking-[0.04em]">{method.provider}</h3>
            <p className="truncate text-[11px] text-muted-foreground">{method.kind === 'wallet' ? 'Transfer by phone number' : method.bankName}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-[minmax(0,1fr)_auto] lg:grid-cols-1 xl:grid-cols-[minmax(0,1fr)_auto]">
          <div className="flex min-w-0 flex-col gap-3">
            {method.kind === 'wallet' ? (
              <>
                <Recipient name={method.recipientName} />
                <CopyField label="Phone number" value={method.phone} what={`${method.provider} phone number`} />
              </>
            ) : (
              <>
                <div className="text-[11px] text-muted-foreground">
                  BANK <span className="ml-1 font-bold tracking-[0.08em] text-foreground">{method.provider}</span>
                </div>
                <Recipient name={method.accountHolder} />
                <CopyField label="Account number" value={method.accountNumber} what="account number" />
                <CopyField label="Account holder" value={method.accountHolder} what="account holder name" />
              </>
            )}
          </div>
          <QrSlot src={method.qrImage} provider={method.provider} className="justify-self-center" />
        </div>

        {open && (
          <div className="hud-rise border-l-2 border-[hsl(var(--gold))] bg-[hsl(var(--gold)/0.07)] p-4">
            <div className="text-[11px] font-bold uppercase tracking-[0.14em] text-[hsl(var(--gold))]">
              {copied ? `${method.kind === 'wallet' ? 'Number' : 'Account number'} copied // finish in your app` : 'Finish in your app'}
            </div>
            <ol className="mt-2 flex flex-col gap-1.5">
              {method.steps.map((s, i) => (
                <li key={s} className="flex gap-2 text-xs leading-relaxed text-foreground/85">
                  <span className="font-bold tabular-nums text-[hsl(var(--gold))]">{String(i + 1).padStart(2, '0')}</span>
                  <span className="min-w-0">{s}</span>
                </li>
              ))}
            </ol>
            {amount !== null && (
              <p className="mt-3 text-xs text-muted-foreground">
                Suggested amount <span className="font-bold text-foreground">{formatAmount(amount, 'VND')}</span>
              </p>
            )}
            <div className="mt-3">
              <CopyField label="Transfer message (optional)" value={DONATE.transferNote} what="transfer message" />
            </div>
          </div>
        )}

        <HudButton variant="gold" onClick={donate} className="mt-auto w-full">
          {hasLink ? <ArrowUpRight className="size-4" /> : <HeartHandshake className="size-4" />}
          {BUTTON[method.id]}
        </HudButton>
      </Panel>
    </div>
  );
}
