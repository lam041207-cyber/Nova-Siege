import { useState } from 'react';
import { QrCode } from 'lucide-react';
import { cn } from '@lib/utils';

/** Shows the real QR image when configured; otherwise an honest "not added yet" frame. Never draws a fake code. */
export function QrSlot({ src, provider, className }: { src: string; provider: string; className?: string }) {
  const [broken, setBroken] = useState(false);
  const ready = !!src && !broken;

  return (
    <figure className={cn('flex flex-col items-center gap-2', className)}>
      <div className="relative size-[140px] p-2 [--qr-size:124px]">
        {/* corner brackets */}
        {['left-0 top-0 border-l-2 border-t-2', 'right-0 top-0 border-r-2 border-t-2', 'bottom-0 left-0 border-b-2 border-l-2', 'bottom-0 right-0 border-b-2 border-r-2'].map((c) => (
          <span key={c} aria-hidden className={cn('absolute size-5 border-[hsl(var(--gold))]', c)} />
        ))}
        {ready ? (
          <img
            src={src}
            alt={`${provider} donation QR code`}
            className="size-full bg-[hsl(var(--brand-ink))] object-contain p-1"
            onError={() => setBroken(true)}
          />
        ) : (
          <div className="relative flex size-full flex-col items-center justify-center gap-1.5 overflow-hidden border border-dashed border-foreground/25 bg-foreground/[0.03] text-center">
            <span aria-hidden className="qr-scan absolute inset-x-1 top-0 h-px bg-[hsl(var(--gold)/0.7)] shadow-[0_0_8px_hsl(var(--gold))]" />
            <QrCode className="size-8 text-foreground/35" strokeWidth={1.25} />
            <span className="px-2 text-[10px] font-bold uppercase leading-tight tracking-[0.12em] text-muted-foreground">QR not added yet</span>
          </div>
        )}
      </div>
      <figcaption className="text-center text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
        {ready ? `Scan in ${provider}` : 'Use the details instead'}
      </figcaption>
    </figure>
  );
}
