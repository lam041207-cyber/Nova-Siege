import { Bomb, Flame, Pause } from 'lucide-react';
import type { HudSnapshot, PowerKind } from '@generated/engine/types';
import { CoinAmount, Meter } from '@generated/components/hud/Meter';
import { cn } from '@lib/utils';

const POWER_LABEL: Record<PowerKind, string> = { rapid: 'RAPID', triple: 'TRIPLE', magnet: 'MAGNET', shield: 'SHIELD', repair: 'REPAIR' };

export function GameHud({ hud, onPause, onBomb }: { hud: HudSnapshot; onPause: () => void; onBomb: () => void }) {
  const lowHp = hud.hp / hud.maxHp < 0.3;
  return (
    <div className="pointer-events-none absolute inset-0 select-none">
      {/* top bar */}
      <div className="flex items-start justify-between gap-3 p-3 sm:p-4">
        <div className="hud-bloom w-40 min-w-0 sm:w-56">
          <div className="mb-1 flex justify-between text-[10px] font-bold tracking-[0.14em] sm:text-[11px]">
            <span>HULL</span>
            <span className={cn('tabular-nums', lowHp && 'hud-blink text-destructive')}>
              {Math.ceil(hud.hp)}/{hud.maxHp}
            </span>
          </div>
          <Meter value={hud.hp} max={hud.maxHp} danger={lowHp} label="Hull" />
          <div className="mb-1 mt-2 flex justify-between text-[10px] font-bold tracking-[0.14em] text-muted-foreground sm:text-[11px]">
            <span>SHIELD</span>
            <span className="tabular-nums">{Math.ceil(hud.shield)}</span>
          </div>
          <Meter value={hud.shield} max={hud.maxShield} className="h-1.5" label="Shield" />
        </div>

        <div className="flex items-start gap-3">
          <div className="hud-bloom text-right">
            <div className="text-[10px] font-bold tracking-[0.14em] text-muted-foreground sm:text-[11px]">WAVE // KILLS</div>
            <div className="text-lg font-bold tabular-nums sm:text-2xl">
              {String(hud.wave).padStart(2, '0')}
              <span className="text-muted-foreground"> // </span>
              {hud.kills}
            </div>
            <CoinAmount value={hud.coins} className="justify-end text-sm font-bold" />
          </div>
          <button
            type="button"
            onClick={onPause}
            aria-label="Pause game"
            className="hud-chamfer hud-chamfer-xs pointer-events-auto grid size-11 place-items-center bg-foreground text-[hsl(var(--ink))] transition-colors hover:bg-[hsl(var(--foreground-dim))]"
          >
            <Pause className="size-5" strokeWidth={2.5} />
          </button>
        </div>
      </div>

      {/* boss bar */}
      {hud.boss && (
        <div className="hud-rise absolute inset-x-0 top-[104px] mx-auto w-[min(92%,560px)] sm:top-6">
          <div className="mb-1 flex justify-between gap-2 text-[10px] font-bold tracking-[0.14em] sm:text-xs">
            <span className="truncate">{hud.boss.name}</span>
            <span className={cn(hud.boss.phase === 2 && 'text-destructive')}>PHASE {hud.boss.phase}</span>
          </div>
          <Meter value={hud.boss.hp} max={hud.boss.maxHp} className="h-3" danger={hud.boss.phase === 2} label="Boss health" />
        </div>
      )}

      {/* banner */}
      {hud.banner && (
        <div key={hud.banner.title} className="hud-rise absolute inset-x-0 top-[38%] text-center">
          <div
            className={cn(
              'hud-text-glow font-[family-name:var(--font-display)] text-5xl tracking-[0.08em] sm:text-7xl',
              hud.banner.danger && 'hud-blink text-destructive',
            )}
          >
            {hud.banner.title}
          </div>
          <div className="mt-3 text-xs font-bold tracking-[0.24em] text-muted-foreground sm:text-sm">{hud.banner.sub}</div>
        </div>
      )}

      {/* bomb */}
      <div className="absolute bottom-4 right-3 flex flex-col items-end gap-2 sm:right-4">
        {hud.revives > 0 && (
          <div className="hud-bloom flex items-center gap-1 text-[10px] font-bold tracking-[0.14em]">
            <Flame className="size-3.5" /> PHOENIX READY
          </div>
        )}
        <button
          type="button"
          onClick={onBomb}
          disabled={hud.bombs <= 0}
          aria-label={`Drop bomb, ${hud.bombs} left`}
          className="group hud-bloom pointer-events-auto disabled:opacity-35"
        >
          <span className="hud-chamfer hud-chamfer-sm block bg-foreground p-px">
            <span className="hud-chamfer hud-chamfer-sm hud-grid flex min-h-14 min-w-[104px] items-center justify-center gap-2 px-3 transition-colors group-hover:bg-[hsl(var(--surface-hover))] group-active:bg-foreground group-active:text-[hsl(var(--ink))]">
              <Bomb className="size-5" />
              <span className="text-left leading-tight">
                <span className="block text-lg font-bold tabular-nums">x{hud.bombs}</span>
                <span className="block text-[9px] font-bold tracking-[0.14em] text-muted-foreground">SPACE</span>
              </span>
            </span>
          </span>
        </button>
      </div>

      {/* powers */}
      {hud.powers.length > 0 && (
        <div className="absolute bottom-4 left-3 flex flex-col gap-2 sm:left-4">
          {hud.powers.map((p) => (
            <div key={p.kind} className="hud-bloom w-32">
              <div className="mb-1 text-[10px] font-bold tracking-[0.14em]">
                {POWER_LABEL[p.kind]} // {p.remaining.toFixed(1)}s
              </div>
              <Meter value={p.remaining} max={p.total} className="h-1.5" label={POWER_LABEL[p.kind]} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
