import { Zap, Flame, Crosshair, HeartPulse, Bomb, Sparkles, Target, Droplet, Coins, type LucideIcon } from 'lucide-react';
import type { RunPerkDef, RunPerkId } from '@generated/data/config';

const ICON: Record<RunPerkId, LucideIcon> = {
  overcharge: Zap,
  hyper: Flame,
  spread: Crosshair,
  nanites: HeartPulse,
  munitions: Bomb,
  chain: Sparkles,
  crit: Target,
  siphon: Droplet,
  greed: Coins,
};

export function PerkPicker({ perks, onPick }: { perks: RunPerkDef[]; onPick: (id: RunPerkId) => void }) {
  return (
    <div className="absolute inset-0 z-20 grid place-items-center overflow-y-auto bg-background/85 p-4" role="dialog" aria-modal="true" aria-label="Choose a perk">
      <div className="hud-rise w-full max-w-3xl">
        <div className="text-center">
          <div className="text-xs font-bold tracking-[0.24em] text-muted-foreground">BOSS SALVAGE // CHOOSE ONE</div>
          <h2 className="hud-text-glow mt-2 font-[family-name:var(--font-display)] text-4xl sm:text-5xl">upgrade</h2>
        </div>
        <ul className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
          {perks.map((p, i) => {
            const Icon = ICON[p.id];
            return (
              <li key={p.id} className="card-in" style={{ animationDelay: `${i * 110}ms` }}>
                <button
                  type="button"
                  onClick={() => onPick(p.id)}
                  aria-label={`Choose perk: ${p.name}. ${p.desc}`}
                  className="group hud-bloom block w-full text-left outline-none focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-foreground"
                >
                  <span className="hud-chamfer block bg-foreground/80 p-px transition-colors group-hover:bg-foreground">
                    <span className="hud-chamfer hud-grid flex min-h-[150px] flex-col gap-3 p-5 transition-colors group-hover:bg-[hsl(var(--surface-hover))]">
                      <Icon className="size-8 transition-transform duration-200 group-hover:scale-110" strokeWidth={1.5} />
                      <span className="text-lg font-bold uppercase tracking-tight">{p.name}</span>
                      <span className="text-sm text-muted-foreground">{p.desc}</span>
                      <span className="mt-auto text-[11px] font-bold tracking-[0.18em] opacity-0 transition-opacity group-hover:opacity-100 group-focus-visible:opacity-100">
                        INSTALL //
                      </span>
                    </span>
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
