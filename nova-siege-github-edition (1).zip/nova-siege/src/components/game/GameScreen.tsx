import { useEffect, useRef, useState, type PointerEvent } from 'react';
import { ASSETS, computeStats, getShip, type RunPerkId } from '@generated/data/config';
import { Game } from '@generated/engine/Game';
import { readPalette, render } from '@generated/engine/draw';
import type { GameEvent, HudSnapshot, RunSummary } from '@generated/engine/types';
import { audio, type SfxName } from '@generated/audio/arcadeAudio';
import { useSave } from '@generated/hooks/useSave';
import { GameHud } from '@generated/components/game/GameHud';
import { PauseOverlay } from '@generated/components/game/PauseOverlay';
import { PerkPicker } from '@generated/components/game/PerkPicker';

function loadImage(src: string): HTMLImageElement {
  const img = new Image();
  img.decoding = 'async';
  img.src = src;
  return img;
}

const EVENT_SFX: Partial<Record<GameEvent, SfxName>> = {
  shoot: 'shoot', hit: 'hit', explode: 'explode', bigExplode: 'bigExplode', chain: 'chain', coin: 'coin', power: 'power',
  playerHit: 'playerHit', shieldHit: 'shieldHit', bossWarn: 'bossWarn', bossSpawn: 'bossSpawn', bossDown: 'bossDown',
  bomb: 'bomb', waveStart: 'waveStart', perkOffer: 'perkOffer', perkPick: 'perkPick', revive: 'revive', death: 'death',
};

function onGameEvent(e: GameEvent) {
  const s = EVENT_SFX[e];
  if (s) audio.sfx(s);
  if (e === 'bossWarn') audio.music('boss');
  if (e === 'bossDown') audio.music('combat', true);
  if (e === 'death') audio.music(null);
}

export function GameScreen({ onOver }: { onOver: (s: RunSummary) => void }) {
  const { save } = useSave();
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const onOverRef = useRef(onOver);
  onOverRef.current = onOver;
  const [hud, setHud] = useState<HudSnapshot | null>(null);
  const [paused, setPaused] = useState(false);

  const shipId = save.selectedShip;
  const upgrades = save.upgrades;
  const perks = save.perks;

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const ship = getShip(shipId);
    const game = new Game({
      stats: computeStats(ship, upgrades, perks),
      shipImage: loadImage(ship.image),
      bossImages: ASSETS.bosses.map(loadImage),
      onOver: (s) => onOverRef.current(s),
      onEvent: onGameEvent,
    });
    gameRef.current = game;
    audio.music('combat');
    const palette = readPalette();
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const resize = () => {
      const rect = wrap.getBoundingClientRect();
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      canvas.width = Math.round(rect.width * dpr);
      canvas.height = Math.round(rect.height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      game.resize(rect.width, rect.height);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);

    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      game.update(dt);
      render(game, ctx, palette, reduced);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    const hudTimer = window.setInterval(() => setHud(game.snapshot()), 90);

    const setPause = (v: boolean) => {
      if (game.finished || !game.player.alive) return;
      game.paused = v;
      setPaused(v);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key === 'p' || e.key === 'P') setPause(!game.paused);
      if (e.code === 'Space' || e.key === 'b' || e.key === 'B') {
        e.preventDefault();
        game.useBomb();
      }
    };
    const onVis = () => {
      if (document.hidden) setPause(true);
    };
    window.addEventListener('keydown', onKey);
    document.addEventListener('visibilitychange', onVis);

    return () => {
      cancelAnimationFrame(raf);
      window.clearInterval(hudTimer);
      ro.disconnect();
      window.removeEventListener('keydown', onKey);
      document.removeEventListener('visibilitychange', onVis);
      gameRef.current = null;
    };
  }, [shipId, upgrades, perks]);

  const handlePointer = (e: PointerEvent<HTMLCanvasElement>) => {
    const game = gameRef.current;
    if (!game || game.paused) return;
    if (e.type === 'pointerdown' && e.button === 2) {
      game.useBomb();
      return;
    }
    const rect = e.currentTarget.getBoundingClientRect();
    const lift = e.pointerType === 'touch' ? 70 : 0;
    game.setTarget(e.clientX - rect.left, e.clientY - rect.top - lift);
  };

  const togglePause = (v: boolean) => {
    const game = gameRef.current;
    if (!game || game.finished) return;
    game.paused = v;
    setPaused(v);
    audio.sfx('click');
  };

  const pickPerk = (id: RunPerkId) => {
    gameRef.current?.choosePerk(id);
    setHud(gameRef.current?.snapshot() ?? null);
  };

  return (
    <div ref={wrapRef} className="fixed inset-0 overflow-hidden bg-background">
      <canvas
        ref={canvasRef}
        aria-label="Battle area. Move your mouse or drag to steer; the ship fires automatically. Space or right-click drops a bomb."
        className="block h-full w-full cursor-none touch-none"
        onPointerMove={handlePointer}
        onPointerDown={handlePointer}
        onContextMenu={(e) => e.preventDefault()}
      />
      {hud && <GameHud hud={hud} onPause={() => togglePause(true)} onBomb={() => gameRef.current?.useBomb()} />}
      {hud?.perkOffer && !paused && <PerkPicker perks={hud.perkOffer} onPick={pickPerk} />}
      {paused && (
        <PauseOverlay
          wave={hud?.wave ?? 1}
          coins={hud?.coins ?? 0}
          runPerks={hud?.runPerks ?? []}
          onResume={() => togglePause(false)}
          onAbandon={() => gameRef.current?.abandon()}
        />
      )}
    </div>
  );
}
