import { BarChart3, Home, RotateCcw, Wrench } from 'lucide-react';
import type { RunSummary } from '@generated/engine/types';
import { Panel } from '@generated/components/hud/Panel';
import { HudButton } from '@generated/components/hud/HudButton';
import { CoinAmount, CrystalAmount } from '@generated/components/hud/Meter';

export type SyncState = 'syncing' | 'synced' | 'failed';

interface Props {
  run: RunSummary;
  newBest: boolean;
  sync: SyncState;
  onFarm: () => void;
  onHangar: () => void;
  onMenu: () => void;
  onRanks: () => void;
}

const SYNC_LABEL: Record<SyncState, string> = {
  syncing: 'SAVING RUN…',
  synced: 'RUN SAVED TO LOCAL RANKING',
  failed: 'COULD NOT SAVE RUN',
};

export function ResultsScreen({ run, newBest, sync, onFarm, onHangar, onMenu, onRanks }: Props) {
  const mins = Math.floor(run.durationSec / 60);
  const secs = String(run.durationSec % 60).padStart(2, '0');
  const rows: [string, string][] = [
    ['WAVE REACHED', String(run.wave).padStart(2, '0')],
    ['HOSTILES DOWN', run.kills.toLocaleString('en-US')],
    ['BOSSES DOWN', String(run.bosses)],
    ['FLIGHT TIME', `${mins}:${secs}`],
  ];

  return (
    <div className="mx-auto grid min-h-[100dvh] w-full max-w-xl place-items-center px-4 py-10">
      <Panel label={`MISSION REPORT // WAVE ${run.wave}`} active className="hud-rise w-full">
        <div className="text-xs font-bold tracking-[0.2em] text-muted-foreground">SHIP LOST // RETURNING TO BASE</div>
        {newBest && (
          <div className="hud-chamfer hud-chamfer-xs mt-3 inline-block bg-foreground px-2 py-1 text-[11px] font-bold tracking-[0.14em] text-[hsl(var(--ink))]">
            NEW BEST WAVE
          </div>
        )}
        <div className="mt-6 text-xs text-muted-foreground">SALVAGE RECOVERED</div>
        <div className="hud-text-glow flex flex-wrap items-baseline gap-x-6 gap-y-1">
          <CoinAmount value={run.coins} className="text-5xl font-light sm:text-6xl" />
          {run.crystals > 0 && <CrystalAmount value={run.crystals} className="text-2xl font-bold" />}
        </div>
        <div className="mt-2 text-sm">
          <span className="text-muted-foreground">BATTLE PASS </span>
          <span className="font-bold">+{run.xp} XP</span>
        </div>
        <dl className="mt-6 grid grid-cols-2 gap-4 border-t border-foreground/15 pt-5">
          {rows.map(([k, v]) => (
            <div key={k}>
              <dt className="text-[11px] text-muted-foreground">{k}</dt>
              <dd className="text-xl font-bold tabular-nums">{v}</dd>
            </div>
          ))}
        </dl>
        <div className="mt-5 text-[11px] font-bold tracking-[0.14em] text-muted-foreground" role="status">
          <span className={sync === 'syncing' ? 'hud-blink' : undefined}>{SYNC_LABEL[sync]}</span>
        </div>
        <div className="mt-6 flex flex-col gap-3">
          <HudButton size="lg" onClick={onFarm}>
            <RotateCcw className="size-5" /> Farm again
          </HudButton>
          <div className="grid grid-cols-3 gap-3">
            <HudButton variant="outline" size="sm" onClick={onHangar}>
              <Wrench className="size-4" /> Hangar
            </HudButton>
            <HudButton variant="outline" size="sm" onClick={onRanks}>
              <BarChart3 className="size-4" /> Ranks
            </HudButton>
            <HudButton variant="outline" size="sm" onClick={onMenu}>
              <Home className="size-4" /> Base
            </HudButton>
          </div>
        </div>
      </Panel>
    </div>
  );
}
