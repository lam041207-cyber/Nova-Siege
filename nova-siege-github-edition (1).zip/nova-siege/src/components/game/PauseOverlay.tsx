import { Play, Flag } from 'lucide-react';
import { RUN_PERKS } from '@generated/data/config';
import { Panel } from '@generated/components/hud/Panel';
import { HudButton } from '@generated/components/hud/HudButton';
import { CoinAmount } from '@generated/components/hud/Meter';
import { SoundToggles } from '@generated/components/hud/SoundToggles';

interface Props {
  wave: number;
  coins: number;
  runPerks: string[];
  onResume: () => void;
  onAbandon: () => void;
}

export function PauseOverlay({ wave, coins, runPerks, onResume, onAbandon }: Props) {
  const names = runPerks.map((id) => RUN_PERKS.find((p) => p.id === id)?.name ?? id);
  return (
    <div className="absolute inset-0 z-30 grid place-items-center overflow-y-auto bg-background/80 p-4" role="dialog" aria-modal="true" aria-label="Paused">
      <Panel label="SYSTEM // PAUSED" active className="hud-rise w-full max-w-sm">
        <div className="text-2xl font-bold">Holding position</div>
        <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
          <div>
            <dt className="text-xs text-muted-foreground">WAVE</dt>
            <dd className="text-xl font-bold tabular-nums">{String(wave).padStart(2, '0')}</dd>
          </div>
          <div>
            <dt className="text-xs text-muted-foreground">SALVAGE</dt>
            <dd className="text-xl font-bold">
              <CoinAmount value={coins} />
            </dd>
          </div>
        </dl>
        {names.length > 0 && (
          <div className="mt-4">
            <div className="text-xs text-muted-foreground">RUN PERKS</div>
            <div className="mt-1 flex flex-wrap gap-1.5">
              {names.map((n, i) => (
                <span key={`${n}-${i}`} className="hud-chamfer hud-chamfer-xs bg-foreground/15 px-2 py-0.5 text-[11px] font-bold uppercase">
                  {n}
                </span>
              ))}
            </div>
          </div>
        )}
        <div className="mt-4">
          <SoundToggles />
        </div>
        <p className="mt-4 text-xs text-muted-foreground">Retreating keeps every coin collected so far.</p>
        <div className="mt-5 flex flex-col gap-3">
          <HudButton onClick={onResume}>
            <Play className="size-4" /> Resume
          </HudButton>
          <HudButton variant="outline" onClick={onAbandon}>
            <Flag className="size-4" /> Retreat to base
          </HudButton>
        </div>
      </Panel>
    </div>
  );
}
