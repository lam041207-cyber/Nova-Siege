import { Check, Lock, Rocket } from 'lucide-react';
import { PASS_TIERS, PASS_TIERS_COUNT, PASS_XP_PER_TIER, getShip } from '@generated/data/config';
import { claimAllTiers, claimTier, passTier } from '@generated/data/progress';
import { useSave } from '@generated/hooks/useSave';
import { Panel } from '@generated/components/hud/Panel';
import { HudButton } from '@generated/components/hud/HudButton';
import { CoinAmount, CrystalAmount, Meter } from '@generated/components/hud/Meter';
import { audio } from '@generated/audio/arcadeAudio';
import { ScreenShell } from '@generated/components/menu/ScreenShell';
import { cn } from '@lib/utils';

export function BattlePass({ onBack }: { onBack: () => void }) {
  const { save, update } = useSave();
  const tier = passTier(save);
  const maxed = tier >= PASS_TIERS_COUNT;
  const into = maxed ? PASS_XP_PER_TIER : save.passXp - tier * PASS_XP_PER_TIER;
  const claimable = PASS_TIERS.filter((t) => t.tier <= tier && !save.passClaimed.includes(t.tier)).length;

  return (
    <ScreenShell
      section="EVENT // SEASON 01 // VOID RIFT"
      title="Battle Pass"
      subtitle="Every run earns XP from waves cleared, kills and bosses. Climb 30 tiers for salvage and two exclusive ships."
      onBack={onBack}
    >
      <Panel label="SEASON PROGRESS" active>
        <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <div className="text-xs text-muted-foreground">CURRENT TIER</div>
            <div className="hud-text-glow font-[family-name:var(--font-display)] text-6xl leading-none sm:text-7xl">
              {String(tier).padStart(2, '0')}
              <span className="text-2xl text-muted-foreground">/30</span>
            </div>
          </div>
          <div className="min-w-0 flex-1 sm:max-w-md">
            <div className="mb-1 flex justify-between text-xs">
              <span className="text-muted-foreground">{maxed ? 'SEASON COMPLETE' : `NEXT // TIER ${tier + 1}`}</span>
              <span className="font-bold tabular-nums">
                {into}/{PASS_XP_PER_TIER} XP
              </span>
            </div>
            <Meter value={into} max={PASS_XP_PER_TIER} className="h-3" label="Tier progress" />
          </div>
          <HudButton
            disabled={!claimable}
            onClick={() => {
              audio.sfx('claim');
              update(claimAllTiers);
            }}
          >
            Claim all{claimable ? ` (${claimable})` : ''}
          </HudButton>
        </div>
      </Panel>

      <ol className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {PASS_TIERS.map((t) => {
          const reached = t.tier <= tier;
          const claimed = save.passClaimed.includes(t.tier);
          const ship = t.shipId ? getShip(t.shipId) : null;
          const big = t.tier % 5 === 0;
          return (
            <li key={t.tier} className={cn('min-w-0', big && 'hud-bloom')}>
              <div className={cn('hud-chamfer hud-chamfer-sm h-full p-px', reached ? 'bg-foreground' : 'bg-foreground/30')}>
                <div className={cn('hud-chamfer hud-chamfer-sm hud-grid flex h-full flex-col gap-2 p-3', !reached && 'opacity-70')}>
                  <div className="flex items-center justify-between text-[11px] font-bold tracking-[0.14em]">
                    <span>T{String(t.tier).padStart(2, '0')}</span>
                    {claimed ? <Check className="size-4" aria-label="Claimed" /> : !reached && <Lock className="size-3.5 text-muted-foreground" aria-label="Locked" />}
                  </div>
                  {ship ? (
                    <div className="flex flex-1 flex-col items-center">
                      <img src={ship.image} alt={`${ship.name} ship`} className="size-16 object-contain mix-blend-screen" />
                      <div className="mt-1 flex items-center gap-1 text-xs font-bold uppercase">
                        <Rocket className="size-3.5" /> {ship.name}
                      </div>
                    </div>
                  ) : (
                    <div className={cn('flex flex-1 items-center font-bold', big ? 'text-xl' : 'text-base')}>
                      <CoinAmount value={t.amount} />
                    </div>
                  )}
                  {t.crystals > 0 && <CrystalAmount value={t.crystals} className="text-xs font-bold text-muted-foreground" />}
                  <HudButton
                    size="sm"
                    variant={reached && !claimed ? 'primary' : 'outline'}
                    disabled={!reached || claimed}
                    onClick={() => {
                      audio.sfx('claim');
                      update((s) => claimTier(s, t.tier));
                    }}
                    className="w-full"
                  >
                    {claimed ? 'Claimed' : reached ? 'Claim' : 'Locked'}
                  </HudButton>
                </div>
              </div>
            </li>
          );
        })}
      </ol>
    </ScreenShell>
  );
}
