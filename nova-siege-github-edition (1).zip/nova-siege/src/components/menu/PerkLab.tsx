import { ArrowUp, Bomb, Sparkles, Target, Clover, Skull, Flame, type LucideIcon } from 'lucide-react';
import { PERKS, upgradeCost, type PerkId } from '@generated/data/config';
import { buyPerk } from '@generated/data/progress';
import { useSave } from '@generated/hooks/useSave';
import { audio } from '@generated/audio/arcadeAudio';
import { Panel } from '@generated/components/hud/Panel';
import { HudButton } from '@generated/components/hud/HudButton';
import { CoinAmount, Pips } from '@generated/components/hud/Meter';

const ICON: Record<PerkId, LucideIcon> = {
  bombBay: Bomb,
  chainReaction: Sparkles,
  critCore: Target,
  luckyDrop: Clover,
  bossBreaker: Skull,
  phoenix: Flame,
};

export function PerkLab() {
  const { save, update } = useSave();
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {PERKS.map((p) => {
        const Icon = ICON[p.id];
        const level = save.perks[p.id];
        const maxed = level >= p.max;
        const cost = upgradeCost(p, level);
        const afford = save.coins >= cost;
        return (
          <Panel key={p.id} label={`PERK // ${p.code}`} active={level > 0}>
            <div className="flex items-start gap-3">
              <span className="hud-chamfer hud-chamfer-xs grid size-11 shrink-0 place-items-center bg-foreground text-[hsl(var(--ink))]">
                <Icon className="size-5" />
              </span>
              <div className="min-w-0">
                <div className="text-lg font-medium leading-tight">{p.name}</div>
                <div className="mt-0.5 text-xs text-muted-foreground">{p.desc}</div>
              </div>
            </div>
            <div className="mt-4 flex items-center justify-between gap-2">
              <Pips level={level} max={p.max} />
              <span className="text-[11px] tabular-nums text-muted-foreground">
                LV {level}/{p.max}
              </span>
            </div>
            <div className="mt-2 text-sm">
              <span className="text-muted-foreground">NOW </span>
              <span className="font-bold">{p.effect(level)}</span>
              {!maxed && (
                <>
                  <span className="text-muted-foreground"> // NEXT </span>
                  <span className="font-bold">{p.effect(level + 1)}</span>
                </>
              )}
            </div>
            <HudButton
              size="sm"
              variant={afford && !maxed ? 'primary' : 'outline'}
              className="mt-4 w-full"
              disabled={maxed || !afford}
              onClick={() => {
                audio.sfx('buy');
                update((s) => buyPerk(s, p.id));
              }}
            >
              {maxed ? (
                'Installed'
              ) : (
                <>
                  <ArrowUp className="size-4" /> {level ? 'Upgrade' : 'Unlock'} <CoinAmount value={cost} />
                </>
              )}
            </HudButton>
          </Panel>
        );
      })}
    </div>
  );
}
