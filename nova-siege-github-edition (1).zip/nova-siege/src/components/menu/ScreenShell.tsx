import type { ReactNode } from 'react';
import { ChevronLeft } from 'lucide-react';
import { useSave } from '@generated/hooks/useSave';
import { CoinAmount, CrystalAmount } from '@generated/components/hud/Meter';

interface Props {
  section: string;
  title: string;
  subtitle?: string;
  onBack: () => void;
  children: ReactNode;
}

export function ScreenShell({ section, title, subtitle, onBack, children }: Props) {
  const { save } = useSave();
  return (
    <div className="mx-auto w-full max-w-6xl px-4 pb-16 pt-4 sm:px-6 sm:pt-6">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <button
          type="button"
          onClick={onBack}
          className="hud-chamfer hud-chamfer-xs inline-flex min-h-11 items-center gap-1 bg-foreground/10 px-3 text-xs font-bold tracking-[0.14em] transition-colors hover:bg-foreground/20"
        >
          <ChevronLeft className="size-4" /> BASE
        </button>
        <div className="flex items-center gap-2">
          <div className="hud-chamfer hud-chamfer-xs bg-foreground/10 px-3 py-2 text-sm font-bold" title="Crystals">
            <CrystalAmount value={save.crystals} />
          </div>
          <div className="hud-bloom hud-chamfer hud-chamfer-xs bg-foreground px-3 py-2 text-sm font-bold text-[hsl(var(--ink))]" title="Coins">
            <CoinAmount value={save.coins} />
          </div>
        </div>
      </header>
      <div className="hud-rise mt-8 sm:mt-10">
        <div className="text-xs font-bold tracking-[0.2em] text-muted-foreground">{section}</div>
        <h1 className="hud-text-glow mt-2 text-3xl font-light tracking-tight sm:text-5xl">{title}</h1>
        {subtitle && <p className="mt-3 max-w-xl text-sm text-muted-foreground">{subtitle}</p>}
      </div>
      <div className="mt-8 sm:mt-10">{children}</div>
    </div>
  );
}
