import { Crosshair, Rocket, Wrench, Trophy, Gift, Sparkles, BarChart3, Download, Heart } from 'lucide-react';
import { ASSETS, getShip } from '@generated/data/config';
import { passTier, pendingPass, pendingRewards } from '@generated/data/progress';
import { useSave } from '@generated/hooks/useSave';
import { audio } from '@generated/audio/arcadeAudio';
import { Panel, Connector, IdBadge } from '@generated/components/hud/Panel';
import { HudButton } from '@generated/components/hud/HudButton';
import { CoinAmount, CrystalAmount, Stars } from '@generated/components/hud/Meter';
import { SoundToggles } from '@generated/components/hud/SoundToggles';
import { RARITY_TEXT } from '@generated/components/hud/rarity';
import type { Screen } from '@generated/data/screens';
import { MIN_AGE, type LegalTab } from '@generated/data/legal';
import { cn } from '@lib/utils';

export function MainMenu({ go, onLaunch, onLegal }: { go: (s: Screen) => void; onLaunch: () => void; onLegal: (tab: LegalTab) => void }) {
  const { save } = useSave();
  const ship = getShip(save.selectedShip);

  const nav: { id: Screen; label: string; code: string; icon: typeof Wrench; badge?: number; hot?: boolean }[] = [
    { id: 'warp', label: 'Warp Gate', code: '4★ + 5★ SHIPS', icon: Sparkles, hot: true },
    { id: 'hangar', label: 'Hangar', code: 'UPGRADES', icon: Wrench },
    { id: 'shop', label: 'Store', code: 'SHIPS + PERKS', icon: Rocket },
    { id: 'leaderboard', label: 'Leaderboard', code: 'LOCAL RANK', icon: BarChart3 },
    { id: 'pass', label: 'Battle Pass', code: `TIER ${passTier(save)}/30`, icon: Trophy, badge: pendingPass(save) },
    { id: 'rewards', label: 'Rewards', code: 'DAILY + ACHIEVE', icon: Gift, badge: pendingRewards(save) },
  ];

  const open = (s: Screen) => {
    audio.sfx('click');
    go(s);
  };

  return (
    <div className="relative mx-auto grid min-h-[100dvh] w-full max-w-7xl grid-cols-1 gap-8 px-4 py-6 sm:px-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.15fr)] lg:items-center lg:gap-10 lg:py-10">
      <div className="hud-rise relative z-10 order-2 flex min-w-0 flex-col gap-6 lg:order-1">
        <div className="flex items-start gap-4">
          <IdBadge code="NS01" className="hidden sm:flex" />
          <div className="min-w-0">
            <div className="text-xs font-bold tracking-[0.2em] text-muted-foreground">SECTOR 7 // DEEP VOID // READY</div>
            <h1 className="hud-text-glow mt-2 font-[family-name:var(--font-display)] text-5xl leading-none tracking-[0.02em] sm:text-7xl">nova siege</h1>
            <p className="mt-4 max-w-md text-sm text-muted-foreground">
              Endless hostile waves. A boss every fifth wave. Farm salvage, warp in legendary ships, climb the global ranks.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <HudButton
            size="lg"
            onClick={() => {
              audio.sfx('waveStart');
              onLaunch();
            }}
            className="w-full sm:w-auto"
          >
            <Crosshair className="size-5" /> Launch mission
          </HudButton>
          <HudButton variant="outline" onClick={() => open('download')} aria-label="Download and install">
            <Download className="size-4" /> Download
          </HudButton>
          <HudButton variant="gold-outline" onClick={() => open('donate')} aria-label="Support the developer">
            <Heart className="size-4" /> Support
          </HudButton>
          <SoundToggles compact />
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {nav.map((n) => (
            <button
              key={n.id}
              type="button"
              onClick={() => open(n.id)}
              className="group hud-bloom relative min-w-0 text-left outline-none focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-foreground"
            >
              <span className={cn('hud-chamfer hud-chamfer-sm block p-px transition-colors', n.hot ? 'bg-[hsl(var(--rare-5))]' : 'bg-foreground/80 group-hover:bg-foreground')}>
                <span className="hud-chamfer hud-chamfer-sm hud-grid flex min-h-[76px] items-center gap-3 px-3 py-3 transition-colors group-hover:bg-[hsl(var(--surface-hover))]">
                  <n.icon className={cn('size-5 shrink-0', n.hot && RARITY_TEXT[5])} strokeWidth={1.75} />
                  <span className="min-w-0">
                    <span className="block truncate text-sm font-bold uppercase tracking-[0.06em]">{n.label}</span>
                    <span className="block truncate text-[11px] text-muted-foreground">{n.code}</span>
                  </span>
                </span>
              </span>
              {!!n.badge && (
                <span className="hud-chamfer hud-chamfer-xs absolute -right-1 -top-2 bg-destructive px-1.5 py-0.5 text-[11px] font-bold text-foreground">{n.badge}</span>
              )}
            </button>
          ))}
        </div>

        <Panel label="PILOT // RECORD">
          <dl className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {[
              ['COINS', <CoinAmount key="c" value={save.coins} />],
              ['CRYSTALS', <CrystalAmount key="k" value={save.crystals} />],
              ['BEST WAVE', String(save.bestWave).padStart(2, '0')],
              ['KILLS', save.totalKills.toLocaleString('en-US')],
            ].map(([k, v]) => (
              <div key={String(k)} className="min-w-0">
                <dt className="text-[11px] text-muted-foreground">{k}</dt>
                <dd className="truncate text-lg font-bold tabular-nums">{v}</dd>
              </div>
            ))}
          </dl>
        </Panel>

        <nav aria-label="Legal" className="flex flex-wrap items-center gap-x-1 gap-y-1 text-[11px] font-bold uppercase tracking-[0.12em] text-muted-foreground">
          {([
            ['terms', 'Terms of Use'],
            ['privacy', 'Privacy Policy'],
            ['age', `Age ${MIN_AGE}+`],
          ] as const).map(([tab, label], i) => (
            <span key={tab} className="flex items-center gap-1">
              {i > 0 && <span aria-hidden>{'//'}</span>}
              <button
                type="button"
                onClick={() => {
                  audio.sfx('click');
                  onLegal(tab);
                }}
                className="inline-flex min-h-11 items-center px-1 underline-offset-4 transition-colors hover:text-foreground hover:underline"
              >
                {label}
              </button>
            </span>
          ))}
          <span aria-hidden className="px-1">{'//'}</span>
          <span className="px-1">{'Free to play // No ads'}</span>
        </nav>
      </div>

      <div className="relative order-1 min-w-0 lg:order-2">
        <div className="hud-bloom relative">
          <div className="hud-chamfer bg-foreground/70 p-px">
            <div className="hud-chamfer relative aspect-[16/10] overflow-hidden bg-background">
              <img src={ASSETS.keyArt} alt="Wireframe starfighter charging a colossal alien mothership" className="h-full w-full object-cover mix-blend-screen" />
              <div className="absolute left-3 top-3 text-[10px] font-bold tracking-[0.2em] text-muted-foreground sm:text-xs">
                FEED // LIVE <span className="hud-blink">●</span>
              </div>
            </div>
          </div>
        </div>
        <Connector className="-bottom-10 left-[18%] hidden h-10 w-px lg:flex" vertical />
        <div className="hud-float absolute -bottom-6 right-2 w-48 sm:-bottom-8 sm:right-6 sm:w-60">
          <Panel label="ACTIVE SHIP" active innerClassName="p-3 pt-4 sm:p-3 sm:pt-4">
            <div className="flex items-center gap-3">
              <img src={ship.image} alt={`${ship.name} ship`} className="size-14 shrink-0 object-contain mix-blend-screen" />
              <div className="min-w-0">
                <Stars count={ship.rarity} className={RARITY_TEXT[ship.rarity]} />
                <div className="truncate text-sm font-bold uppercase">{ship.name}</div>
                <div className="text-[11px] text-muted-foreground">{ship.code}</div>
              </div>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}
