import { ArrowUp, Crosshair } from 'lucide-react';
import { UPGRADES, computeStats, getShip, upgradeCost } from '@generated/data/config';
import { buyUpgrade } from '@generated/data/progress';
import { useSave } from '@generated/hooks/useSave';
import { Panel } from '@generated/components/hud/Panel';
import { HudButton } from '@generated/components/hud/HudButton';
import { CoinAmount, Pips } from '@generated/components/hud/Meter';
import { ScreenShell } from '@generated/components/menu/ScreenShell';
import { audio } from '@generated/audio/arcadeAudio';

export function Hangar({ onBack, onLaunch }: { onBack: () => void; onLaunch: () => void }) {
  const { save, update } = useSave();
  const ship = getShip(save.selectedShip);
  const stats = computeStats(ship, save.upgrades, save.perks);

  const readouts: [string, string][] = [
    ['HULL', String(stats.maxHp)],
    ['SHIELD', String(stats.maxShield)],
    ['DAMAGE', stats.damage.toFixed(1)],
    ['FIRE RATE', `${stats.fireRate.toFixed(1)}/s`],
    ['STREAMS', String(stats.streams)],
    ['AGILITY', `${Math.round(stats.agility * 100)}%`],
    ['YIELD', `x${stats.coinMult.toFixed(1)}`],
    ['TRACTOR', `${stats.magnet}px`],
  ];

  return (
    <ScreenShell
      section="BASE // HANGAR"
      title="Refit your ship"
      subtitle="Upgrades apply to every ship you fly. Farm salvage in battle, then spend it here."
      onBack={onBack}
    >
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[minmax(0,340px)_minmax(0,1fr)]">
        <Panel label={`${ship.code} // ${ship.name}`} active className="lg:sticky lg:top-6 lg:self-start">
          <img src={ship.image} alt={`${ship.name} ship`} className="hud-float mx-auto aspect-square w-48 object-contain mix-blend-screen" />
          <dl className="mt-2 grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
            {readouts.map(([k, v]) => (
              <div key={k} className="flex justify-between gap-2 border-b border-foreground/15 pb-1">
                <dt className="text-muted-foreground">{k}</dt>
                <dd className="font-bold tabular-nums">{v}</dd>
              </div>
            ))}
          </dl>
          <HudButton className="mt-5 w-full" onClick={onLaunch}>
            <Crosshair className="size-4" /> Launch
          </HudButton>
        </Panel>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
          {UPGRADES.map((u) => {
            const level = save.upgrades[u.id];
            const maxed = level >= u.max;
            const cost = upgradeCost(u, level);
            const afford = save.coins >= cost;
            return (
              <Panel key={u.id} label={u.code}>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-lg font-medium">{u.name}</div>
                    <div className="text-xs text-muted-foreground">{u.desc}</div>
                  </div>
                  <div className="shrink-0 text-right text-xs tabular-nums text-muted-foreground">
                    LV {level}/{u.max}
                  </div>
                </div>
                <div className="mt-3">
                  <Pips level={level} max={u.max} />
                </div>
                <div className="mt-3 text-sm">
                  <span className="text-muted-foreground">NOW </span>
                  <span className="font-bold">{u.effect(level)}</span>
                  {!maxed && (
                    <>
                      <span className="text-muted-foreground"> // NEXT </span>
                      <span className="font-bold">{u.effect(level + 1)}</span>
                    </>
                  )}
                </div>
                <HudButton
                  size="sm"
                  variant={afford && !maxed ? 'primary' : 'outline'}
                  className="mt-4 w-full"
                  disabled={maxed || !afford}
                  onClick={() => {
                    audio.sfx('buy');
                    update((s) => buyUpgrade(s, u.id));
                  }}
                >
                  {maxed ? (
                    'Maxed out'
                  ) : (
                    <>
                      <ArrowUp className="size-4" /> Upgrade <CoinAmount value={cost} />
                    </>
                  )}
                </HudButton>
              </Panel>
            );
          })}
        </div>
      </div>
    </ScreenShell>
  );
}
