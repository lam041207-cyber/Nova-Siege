import { useRef, useState, type ChangeEvent } from 'react';
import { Apple, Copy, Download, Monitor, Smartphone, Upload } from 'lucide-react';
import { normalizeSave, type SaveData } from '@generated/data/progress';
import { useSave } from '@generated/hooks/useSave';
import { audio } from '@generated/audio/arcadeAudio';
import { ScreenShell } from '@generated/components/menu/ScreenShell';
import { Panel } from '@generated/components/hud/Panel';
import { HudButton } from '@generated/components/hud/HudButton';
import { CoinAmount, CrystalAmount } from '@generated/components/hud/Meter';
import { SourceExport } from '@generated/components/menu/SourceExport';

const INSTALL_STEPS = [
  { icon: Apple, title: 'iPhone & iPad', steps: ['Open the game link in Safari', 'Tap the Share button', 'Choose "Add to Home Screen", then "Add"'] },
  { icon: Smartphone, title: 'Android', steps: ['Open the game link in Chrome', 'Tap the ⋮ menu (top right)', 'Choose "Add to Home screen"'] },
  { icon: Monitor, title: 'Windows, Mac & Linux', steps: ['Open the game link in Chrome or Edge', 'Open the ⋮ menu > "Cast, save and share"', 'Choose "Create shortcut" and tick "Open as window"'] },
];

type Msg = { kind: 'ok' | 'error'; text: string } | null;

export function DownloadScreen({ onBack }: { onBack: () => void }) {
  const { save, update } = useSave();
  const fileRef = useRef<HTMLInputElement>(null);
  const [copied, setCopied] = useState(false);
  const [msg, setMsg] = useState<Msg>(null);
  const [pending, setPending] = useState<SaveData | null>(null);

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href.split('#')[0]);
      setCopied(true);
      audio.sfx('claim');
      window.setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      console.error('Copy link failed', e);
      setMsg({ kind: 'error', text: 'Could not copy automatically. Copy the address from your browser bar instead.' });
    }
  };

  const downloadSave = () => {
    try {
      const rest = { ...save, legal: undefined };
      const blob = new Blob([JSON.stringify({ game: 'nova-siege', version: 1, exportedAt: new Date().toISOString(), save: rest }, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `nova-siege-save-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      audio.sfx('buy');
      setMsg({ kind: 'ok', text: 'Save file downloaded. Keep it somewhere safe.' });
    } catch (e) {
      console.error('Save export failed', e);
      setMsg({ kind: 'error', text: 'Could not create the save file. Please try again.' });
    }
  };

  const pickFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    try {
      if (file.size > 500_000) throw new Error('File too large');
      const parsed: unknown = JSON.parse(await file.text());
      const wrapper = parsed && typeof parsed === 'object' ? (parsed as Record<string, unknown>) : null;
      if (!wrapper || wrapper.game !== 'nova-siege') throw new Error('Not a Nova Siege save');
      setPending(normalizeSave(wrapper.save));
      setMsg(null);
      audio.sfx('click');
    } catch (err) {
      console.error('Save import failed', err);
      setPending(null);
      setMsg({ kind: 'error', text: 'That file is not a valid Nova Siege save file.' });
      audio.sfx('error');
    }
  };

  const confirmRestore = () => {
    if (!pending) return;
    update((s) => ({ ...pending, legal: s.legal, settings: s.settings }));
    setPending(null);
    setMsg({ kind: 'ok', text: 'Progress restored. Welcome back, pilot.' });
    audio.sfx('claim');
  };

  return (
    <ScreenShell section="COMMAND // DOWNLOAD" title="Install & backup" subtitle="Put Nova Siege on your home screen like an app, and carry your progress between devices with a save file." onBack={onBack}>
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)]">
        <Panel label="INSTALL // HOME SCREEN">
          <p className="max-w-[60ch] text-sm leading-relaxed text-foreground/85">
            Nova Siege runs in your browser, so there is nothing to install from a store. Add it to your home screen or desktop to launch it full-screen with one tap. An internet connection is needed the first time it loads.
          </p>
          <HudButton className="mt-4" onClick={copyLink}>
            <Copy className="size-4" /> {copied ? 'Link copied' : 'Copy game link'}
          </HudButton>
          <ol className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-3 lg:grid-cols-1 xl:grid-cols-3">
            {INSTALL_STEPS.map((p) => (
              <li key={p.title} className="min-w-0 border-t border-foreground/15 pt-4">
                <div className="flex items-center gap-2 text-sm font-bold uppercase tracking-[0.06em]">
                  <p.icon className="size-4 shrink-0" strokeWidth={1.75} /> {p.title}
                </div>
                <ol className="mt-2 flex flex-col gap-1.5">
                  {p.steps.map((s, i) => (
                    <li key={s} className="flex gap-2 text-xs leading-relaxed text-muted-foreground">
                      <span className="font-bold text-foreground tabular-nums">{String(i + 1).padStart(2, '0')}</span>
                      <span className="min-w-0">{s}</span>
                    </li>
                  ))}
                </ol>
              </li>
            ))}
          </ol>
        </Panel>

        <Panel label="SAVE // BACKUP" active>
          <p className="text-sm leading-relaxed text-foreground/85">
            Progress lives on this device only. Download a save file to back it up, then restore it on another phone, computer or browser.
          </p>
          <dl className="mt-4 grid grid-cols-3 gap-3 border-y border-foreground/15 py-3 text-xs">
            <div className="min-w-0"><dt className="text-muted-foreground">COINS</dt><dd className="truncate font-bold"><CoinAmount value={save.coins} /></dd></div>
            <div className="min-w-0"><dt className="text-muted-foreground">CRYSTALS</dt><dd className="truncate font-bold"><CrystalAmount value={save.crystals} /></dd></div>
            <div className="min-w-0"><dt className="text-muted-foreground">SHIPS</dt><dd className="font-bold">{save.ownedShips.length}</dd></div>
          </dl>
          <div className="mt-4 flex flex-wrap gap-2">
            <HudButton onClick={downloadSave}>
              <Download className="size-4" /> Download save
            </HudButton>
            <HudButton variant="outline" onClick={() => fileRef.current?.click()}>
              <Upload className="size-4" /> Restore from file
            </HudButton>
            <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={pickFile} aria-label="Choose a save file" />
          </div>

          {pending && (
            <div className="mt-5 border border-foreground/30 p-4">
              <div className="text-xs font-bold uppercase tracking-[0.12em]">Replace current progress?</div>
              <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                The file has best wave {pending.bestWave}, {pending.ownedShips.length} ships and {pending.coins.toLocaleString('en-US')} coins. Your current progress on this device will be overwritten.
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <HudButton size="sm" onClick={confirmRestore}>Restore</HudButton>
                <HudButton size="sm" variant="outline" onClick={() => setPending(null)}>Cancel</HudButton>
              </div>
            </div>
          )}
          {msg && (
            <p aria-live="polite" className={msg.kind === 'error' ? 'mt-4 text-xs text-destructive' : 'mt-4 text-xs text-foreground/85'}>
              {msg.text}
            </p>
          )}
        </Panel>
      </div>
      <SourceExport />
    </ScreenShell>
  );
}
