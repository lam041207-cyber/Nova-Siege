import { Check, Lock, Sparkles } from 'lucide-react';
import { SHIPS } from '@generated/data/config';
import { buyShip, selectShip } from '@generated/data/progress';
import { useSave } from '@generated/hooks/useSave';
import { audio } from '@generated/audio/arcadeAudio';
import { Panel } from '@generated/components/hud/Panel';
import { HudButton } from '@generated/components/hud/HudButton';
import { CoinAmount, Meter, Stars } from '@generated/components/hud/Meter';
import { RARITY_TEXT } from '@generated/components/hud/rarity';
import { cn } from '@lib/utils';

const MAX = { hp: 240, damage: 25, fireRate: 9, speed: 1.4 };

export function ShipList({ onWarp }: { onWarp: () => void }) {
  const { save, update } = useSave();

  return (
    <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
      {SHIPS.map((ship) => {
        const owned = save.ownedShips.includes(ship.id);
        const equipped = save.selectedShip === ship.id;
        const afford = save.coins >= ship.cost;
        const bars: [string, number, number][] = [
          ['HULL', ship.hp, MAX.hp],
          ['DAMAGE', ship.damage, MAX.damage],
          ['FIRE RATE', ship.fireRate, MAX.fireRate],
          ['AGILITY', ship.speed, MAX.speed],
        ];
        return (
          <Panel key={ship.id} label={`${ship.code}${equipped ? ' // EQUIPPED' : ''}`} active={equipped || ship.rarity === 5}>
            <div className="grid grid-cols-[96px_minmax(0,1fr)] gap-4 sm:grid-cols-[132px_minmax(0,1fr)]">
              <div className="relative">
                <img
                  src={ship.image}
                  alt={`${ship.name} ship`}
                  className={cn('aspect-square w-full object-contain mix-blend-screen', !owned && 'opacity-60 grayscale')}
                />
                {!owned && <Lock className="absolute right-1 top-1 size-4 text-muted-foreground" aria-hidden />}
              </div>
              <div className="min-w-0">
                <Stars count={ship.rarity} className={RARITY_TEXT[ship.rarity]} />
                <div className="text-2xl font-bold uppercase tracking-tight">{ship.name}</div>
                <p className="mt-1 text-xs text-muted-foreground">{ship.tagline}</p>
                <div className="mt-3 space-y-2">
                  {bars.map(([k, v, m]) => (
                    <div key={k} className="grid grid-cols-[76px_minmax(0,1fr)] items-center gap-2 text-[11px]">
                      <span className="text-muted-foreground">{k}</span>
                      <Meter value={v} max={m} className="h-1.5" label={k} />
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="mt-4 border-t border-foreground/15 pt-3 text-xs">
              <span className="text-muted-foreground">SPECIAL // </span>
              <span className="font-bold">{ship.specialLabel}</span>
            </div>
            <div className="mt-4">
              {equipped ? (
                <HudButton variant="outline" className="w-full" disabled>
                  <Check className="size-4" /> Equipped
                </HudButton>
              ) : owned ? (
                <HudButton
                  className="w-full"
                  onClick={() => {
                    audio.sfx('click');
                    update((s) => selectShip(s, ship.id));
                  }}
                >
                  Equip ship
                </HudButton>
              ) : ship.gachaOnly ? (
                <HudButton variant="outline" className="w-full" onClick={onWarp}>
                  <Sparkles className="size-4" /> Warp Gate exclusive
                </HudButton>
              ) : (
                <div className="flex flex-col gap-2">
                  <HudButton
                    className="w-full"
                    disabled={!afford}
                    onClick={() => {
                      audio.sfx('buy');
                      update((s) => buyShip(s, ship.id));
                    }}
                  >
                    Buy <CoinAmount value={ship.cost} />
                  </HudButton>
                  {ship.passTier && <div className="text-center text-[11px] text-muted-foreground">or unlock free at Battle Pass tier {ship.passTier}</div>}
                </div>
              )}
            </div>
          </Panel>
        );
      })}
    </div>
  );
}
