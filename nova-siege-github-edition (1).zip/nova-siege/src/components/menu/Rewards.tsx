import { Check, Gift } from 'lucide-react';
import { ACHIEVEMENTS, DAILY_CRYSTALS, DAILY_REWARDS } from '@generated/data/config';
import { audio } from '@generated/audio/arcadeAudio';
import { claimAchievement, claimDaily, dailyStatus, metricValue } from '@generated/data/progress';
import { useSave } from '@generated/hooks/useSave';
import { Panel } from '@generated/components/hud/Panel';
import { HudButton } from '@generated/components/hud/HudButton';
import { CoinAmount, CrystalAmount, Meter } from '@generated/components/hud/Meter';
import { ScreenShell } from '@generated/components/menu/ScreenShell';
import { cn } from '@lib/utils';

export function Rewards({ onBack }: { onBack: () => void }) {
  const { save, update } = useSave();
  const daily = dailyStatus(save);

  return (
    <ScreenShell
      section="BASE // REWARDS"
      title="Supply drops"
      subtitle="Check in every day to keep your streak alive. Missing a day resets the 7-day cycle."
      onBack={onBack}
    >
      <Panel label={`DAILY // STREAK ${daily.streak}`} active>
        <ol className="grid grid-cols-4 gap-2 sm:grid-cols-7">
          {DAILY_REWARDS.map((amount, i) => {
            const claimed = i < daily.claimedInCycle;
            const next = daily.canClaim && i === daily.claimedInCycle;
            return (
              <li
                key={`day-${i + 1}`}
                className={cn(
                  'hud-chamfer hud-chamfer-xs flex min-w-0 flex-col items-center gap-1 px-1 py-3 text-center',
                  next ? 'bg-foreground text-[hsl(var(--ink))]' : claimed ? 'bg-foreground/15' : 'bg-foreground/5',
                  i === 6 && 'col-span-2 sm:col-span-1',
                )}
              >
                <span className="text-[10px] font-bold tracking-[0.14em]">DAY {i + 1}</span>
                {claimed ? <Check className="size-5" aria-label="Claimed" /> : <Gift className="size-5" strokeWidth={1.75} aria-hidden />}
                <CoinAmount value={amount} className="text-xs font-bold" />
                <CrystalAmount value={DAILY_CRYSTALS[i] ?? 0} className="text-[11px]" />
              </li>
            );
          })}
        </ol>
        <HudButton className="mt-5 w-full sm:w-auto" disabled={!daily.canClaim} onClick={() => {
            audio.sfx('claim');
            update(claimDaily);
          }}>
          {daily.canClaim ? 'Claim today’s drop' : 'Come back tomorrow'}
        </HudButton>
      </Panel>

      <h2 className="mt-12 text-xl font-bold tracking-tight sm:text-2xl">Achievements</h2>
      <p className="mt-1 text-xs text-muted-foreground">
        {save.achievementsClaimed.length}/{ACHIEVEMENTS.length} COMPLETED
      </p>
      <ul className="mt-5 grid grid-cols-1 gap-3 md:grid-cols-2">
        {ACHIEVEMENTS.map((a) => {
          const value = metricValue(save, a);
          const done = value >= a.target;
          const claimed = save.achievementsClaimed.includes(a.id);
          return (
            <li key={a.id} className="hud-chamfer hud-chamfer-sm min-w-0 bg-foreground/40 p-px">
              <div className="hud-chamfer hud-chamfer-sm hud-grid flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="truncate font-bold uppercase">{a.name}</span>
                    <span className="flex shrink-0 gap-2 text-xs text-muted-foreground">
                      <CoinAmount value={a.reward} />
                      <CrystalAmount value={a.crystals} />
                    </span>
                  </div>
                  <div className="text-xs text-muted-foreground">{a.desc}</div>
                  <div className="mt-2 flex items-center gap-2">
                    <Meter value={Math.min(value, a.target)} max={a.target} className="h-1.5" label={a.name} />
                    <span className="shrink-0 text-[11px] tabular-nums text-muted-foreground">
                      {Math.min(value, a.target).toLocaleString('en-US')}/{a.target.toLocaleString('en-US')}
                    </span>
                  </div>
                </div>
                <HudButton
                  size="sm"
                  variant={done && !claimed ? 'primary' : 'outline'}
                  disabled={!done || claimed}
                  onClick={() => {
                    audio.sfx('claim');
                    update((s) => claimAchievement(s, a.id));
                  }}
                  className="sm:w-28"
                >
                  {claimed ? 'Claimed' : done ? 'Claim' : 'Locked'}
                </HudButton>
              </div>
            </li>
          );
        })}
      </ul>
    </ScreenShell>
  );
}
