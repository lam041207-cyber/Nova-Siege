/** GitHub Pages edition of the leaderboard: ranks this device's best runs, stored in the browser. */
import { useMemo, useState } from 'react';
import { Crown, Save, Skull, Waves } from 'lucide-react';
import { getShip, type ShipId } from '@generated/data/config';
import type { RunSummary } from '@generated/engine/types';
import { useSave } from '@generated/hooks/useSave';
import { audio } from '@generated/audio/arcadeAudio';
import { ScreenShell } from '@generated/components/menu/ScreenShell';
import { Panel } from '@generated/components/hud/Panel';
import { HudButton } from '@generated/components/hud/HudButton';
import { readRuns, recordRun, renameRuns } from '@generated/data/localRanking';
import { cn } from '@lib/utils';

type Category = 'wave' | 'kills';

/** Records a finished run in the local ranking. Same call shape as the online edition. */
export async function syncScore(save: { selectedShip: string; callsign: string }, run?: RunSummary): Promise<void> {
  if (run) recordRun(run, save.callsign, save.selectedShip);
}

export function Leaderboard({ onBack }: { onBack: () => void }) {
  const { save, update } = useSave();
  const [cat, setCat] = useState<Category>('wave');
  const [name, setName] = useState(save.callsign);
  const [version, setVersion] = useState(0);
  const [msg, setMsg] = useState<string | null>(null);

  // `version` bumps re-read storage after a rename
  const rows = useMemo(() => {
    const runs = version >= 0 ? readRuns() : [];
    return cat === 'wave'
      ? runs.sort((a, b) => b.wave - a.wave || b.kills - a.kills).slice(0, 50)
      : runs.sort((a, b) => b.kills - a.kills || b.wave - a.wave).slice(0, 50);
  }, [cat, version]);

  const best = rows[0];

  const saveName = () => {
    const callsign = name.trim().slice(0, 16);
    update((s) => ({ ...s, callsign }));
    renameRuns(callsign);
    setVersion((v) => v + 1);
    audio.sfx('claim');
    setMsg('Callsign updated');
  };

  const tabs: { id: Category; label: string; icon: typeof Waves }[] = [
    { id: 'wave', label: 'Highest wave', icon: Waves },
    { id: 'kills', label: 'Most kills', icon: Skull },
  ];

  return (
    <ScreenShell section="LOCAL // RANKING" title="Leaderboard" subtitle="Your top 50 runs on this device, ranked by highest wave and most kills in a single run." onBack={onBack}>
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,320px)]">
        <div className="min-w-0">
          <div role="tablist" aria-label="Ranking category" className="mb-5 flex flex-wrap gap-2">
            {tabs.map((t) => (
              <button
                key={t.id}
                type="button"
                role="tab"
                aria-selected={cat === t.id}
                onClick={() => {
                  audio.sfx('click');
                  setCat(t.id);
                }}
                className={cn(
                  'hud-chamfer hud-chamfer-xs inline-flex min-h-11 items-center gap-2 px-4 text-xs font-bold uppercase tracking-[0.14em] transition-colors',
                  cat === t.id ? 'bg-foreground text-[hsl(var(--ink))]' : 'bg-foreground/10 hover:bg-foreground/20',
                )}
              >
                <t.icon className="size-4" /> {t.label}
              </button>
            ))}
          </div>

          <Panel label={cat === 'wave' ? 'TOP RUNS // WAVE' : 'TOP RUNS // KILLS'} innerClassName="p-2 sm:p-3">
            {!rows.length ? (
              <div className="p-8 text-center text-sm text-muted-foreground">No runs recorded yet. Finish a mission to claim the top spot.</div>
            ) : (
              <ol className="divide-y divide-foreground/10">
                {rows.map((r, i) => {
                  const rank = i + 1;
                  const ship = getShip(r.ship as ShipId);
                  const value = cat === 'wave' ? r.wave : r.kills;
                  return (
                    <li key={r.id} className="flex min-h-12 items-center gap-3 px-2 py-2">
                      <span
                        className={cn(
                          'hud-chamfer hud-chamfer-xs grid h-8 w-10 shrink-0 place-items-center text-xs font-bold tabular-nums',
                          rank === 1 ? 'bg-[hsl(var(--rare-5))] text-[hsl(var(--ink))]' : rank <= 3 ? 'bg-foreground text-[hsl(var(--ink))]' : 'bg-foreground/10',
                        )}
                      >
                        {rank === 1 ? <Crown className="size-4" aria-label="Rank 1" /> : rank}
                      </span>
                      <img src={ship.image} alt="" className="size-8 shrink-0 object-contain mix-blend-screen" />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-bold">{r.callsign}</span>
                        <span className="block text-[10px] uppercase text-muted-foreground">
                          {ship.name} · {new Date(r.at).toLocaleDateString()}
                        </span>
                      </span>
                      <span className="shrink-0 text-right text-lg font-bold tabular-nums">{value.toLocaleString('en-US')}</span>
                    </li>
                  );
                })}
              </ol>
            )}
          </Panel>
        </div>

        <div className="flex flex-col gap-5">
          <Panel label="PERSONAL BEST" active>
            <div className="hud-text-glow font-[family-name:var(--font-display)] text-6xl leading-none">
              {best ? (cat === 'wave' ? best.wave : best.kills).toLocaleString('en-US') : '--'}
            </div>
            <div className="mt-2 text-xs text-muted-foreground">
              {best ? `${cat === 'wave' ? 'waves' : 'kills'} in one run · ${rows.length} runs ranked` : 'Finish a run to get ranked'}
            </div>
          </Panel>
          <Panel label="CALLSIGN">
            <label htmlFor="callsign" className="text-xs text-muted-foreground">
              Name shown on your runs
            </label>
            <input
              id="callsign"
              value={name}
              maxLength={16}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your callsign"
              className="hud-chamfer hud-chamfer-xs mt-2 min-h-11 w-full bg-foreground/10 px-3 text-base outline-none placeholder:text-muted-foreground focus:bg-foreground/15 sm:text-sm"
            />
            <HudButton size="sm" className="mt-3 w-full" disabled={!name.trim()} onClick={saveName}>
              <Save className="size-4" /> Save callsign
            </HudButton>
            {msg && <p className="mt-2 text-xs text-muted-foreground" aria-live="polite">{msg}</p>}
          </Panel>
        </div>
      </div>
    </ScreenShell>
  );
}
