import { useState } from 'react';
import { Rocket, Sparkles } from 'lucide-react';
import { audio } from '@generated/audio/arcadeAudio';
import { ScreenShell } from '@generated/components/menu/ScreenShell';
import { ShipList } from '@generated/components/menu/Shipyard';
import { PerkLab } from '@generated/components/menu/PerkLab';
import { cn } from '@lib/utils';

type Tab = 'ships' | 'perks';

export function Store({ onBack, onWarp }: { onBack: () => void; onWarp: () => void }) {
  const [tab, setTab] = useState<Tab>('ships');
  const tabs: { id: Tab; label: string; icon: typeof Rocket }[] = [
    { id: 'ships', label: 'Ships', icon: Rocket },
    { id: 'perks', label: 'Perk Lab', icon: Sparkles },
  ];
  return (
    <ScreenShell
      section="BASE // STORE"
      title="Armory and shipyard"
      subtitle="Buy new hulls with coins, or install permanent perks like screen-clearing bombs, chain explosions and a one-time revive."
      onBack={onBack}
    >
      <div role="tablist" aria-label="Store sections" className="mb-8 flex gap-2">
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            role="tab"
            aria-selected={tab === t.id}
            onClick={() => {
              audio.sfx('click');
              setTab(t.id);
            }}
            className={cn(
              'hud-chamfer hud-chamfer-xs inline-flex min-h-11 items-center gap-2 px-4 text-xs font-bold uppercase tracking-[0.14em] transition-colors',
              tab === t.id ? 'bg-foreground text-[hsl(var(--ink))]' : 'bg-foreground/10 hover:bg-foreground/20',
            )}
          >
            <t.icon className="size-4" /> {t.label}
          </button>
        ))}
      </div>
      {tab === 'ships' ? <ShipList onWarp={onWarp} /> : <PerkLab />}
    </ScreenShell>
  );
}
