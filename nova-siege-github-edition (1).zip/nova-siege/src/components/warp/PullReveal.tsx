import { useEffect } from 'react';
import { Diamond } from 'lucide-react';
import { getShip } from '@generated/data/config';
import type { PullResult } from '@generated/data/gacha';
import { audio } from '@generated/audio/arcadeAudio';
import { HudButton } from '@generated/components/hud/HudButton';
import { CoinAmount, CrystalAmount } from '@generated/components/hud/Meter';
import { RARITY_BG, RARITY_GLOW, RARITY_LABEL, RARITY_TEXT } from '@generated/components/hud/rarity';
import { cn } from '@lib/utils';

const STEP_MS = 260;

function ResultCard({ r, index, big, instant }: { r: PullResult; index: number; big: boolean; instant: boolean }) {
  const ship = r.shipId ? getShip(r.shipId) : null;
  const delay = instant ? 0 : index * STEP_MS;
  return (
    <div className={cn('relative min-w-0', !instant && 'card-in')} style={{ animationDelay: `${delay}ms` }}>
      {r.rarity >= 4 && <div aria-hidden className={cn('rays pointer-events-none absolute -inset-[40%]', r.rarity === 4 && 'rays-4')} />}
      <div className={cn('relative', RARITY_GLOW[r.rarity])}>
        <div className={cn('hud-chamfer p-[2px]', RARITY_BG[r.rarity])}>
          <div className={cn('hud-chamfer hud-grid flex flex-col items-center text-center', big ? 'gap-3 p-6' : 'gap-1.5 p-3')}>
            <div className={cn('flex gap-0.5', RARITY_TEXT[r.rarity])} aria-label={`${r.rarity} star`}>
              {Array.from({ length: r.rarity }, (_, k) => (
                <svg
                  key={`st${k}`}
                  viewBox="0 0 24 24"
                  aria-hidden
                  className={cn('fill-current', big ? 'size-7' : 'size-4', !instant && 'star-pop')}
                  style={{ animationDelay: `${delay + 320 + k * 110}ms` }}
                >
                  <path d="M12 2l2.9 6.6 7.1.6-5.4 4.7 1.6 7L12 17.3 5.8 20.9l1.6-7L2 9.2l7.1-.6z" />
                </svg>
              ))}
            </div>
            {ship ? (
              <img src={ship.image} alt={`${ship.name} ship`} className={cn('object-contain mix-blend-screen', big ? 'size-48 sm:size-56' : 'size-20')} />
            ) : (
              <div className={cn('grid place-items-center', big ? 'size-48' : 'size-20')}>
                <Diamond className={cn(big ? 'size-20' : 'size-9')} strokeWidth={1.25} />
              </div>
            )}
            <div className={cn('text-[10px] font-bold tracking-[0.2em]', RARITY_TEXT[r.rarity])}>{RARITY_LABEL[r.rarity]}</div>
            <div className={cn('font-bold uppercase leading-tight', big ? 'text-3xl' : 'truncate text-sm')}>{ship ? ship.name : 'Salvage cache'}</div>
            {ship && r.isNew && (
              <span className={cn('hud-chamfer hud-chamfer-xs px-2 py-0.5 text-[10px] font-bold tracking-[0.14em] text-[hsl(var(--ink))]', RARITY_BG[r.rarity])}>NEW SHIP</span>
            )}
            {(!ship || !r.isNew) && (
              <div className={cn('flex flex-wrap justify-center gap-x-2 text-muted-foreground', big ? 'text-sm' : 'text-[11px]')}>
                {ship && <span>DUPLICATE //</span>}
                {r.coins > 0 && <CoinAmount value={r.coins} />}
                {r.crystals > 0 && <CrystalAmount value={r.crystals} />}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

interface Props {
  results: PullResult[];
  instant: boolean;
  onSkip: () => void;
  onDone: () => void;
}

export function PullReveal({ results, instant, onSkip, onDone }: Props) {
  const single = results.length === 1;

  useEffect(() => {
    if (instant) return;
    const timers: ReturnType<typeof setTimeout>[] = [];
    results.forEach((r, i) => {
      const base = i * STEP_MS;
      timers.push(setTimeout(() => audio.sfx(r.rarity === 5 ? 'reveal5' : r.rarity === 4 ? 'reveal4' : 'flip'), base));
      for (let k = 0; k < r.rarity; k++) timers.push(setTimeout(() => audio.sfx('star', k), base + 320 + k * 110));
    });
    return () => timers.forEach(clearTimeout);
  }, [results, instant]);

  return (
    <div className="hud-rise flex flex-col items-center gap-8">
      <div className={cn(single ? 'w-full max-w-xs' : 'grid w-full grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5')}>
        {results.map((r, i) => (
          <ResultCard key={`${i}-${r.rarity}-${r.shipId ?? 'c'}`} r={r} index={i} big={single} instant={instant} />
        ))}
      </div>
      <div className="flex gap-3">
        {!instant && !single && (
          <HudButton variant="outline" onClick={onSkip}>
            Skip
          </HudButton>
        )}
        <HudButton onClick={onDone}>Continue</HudButton>
      </div>
    </div>
  );
}
