import { useEffect, useRef, useState } from 'react';
import { Sparkles } from 'lucide-react';
import { ASSETS, GACHA_4, GACHA_5, PITY_4, PITY_5, RATE_4, RATE_5, getShip, type Rarity } from '@generated/data/config';
import { pullCost, warp, type PullResult } from '@generated/data/gacha';
import { useSave } from '@generated/hooks/useSave';
import { audio } from '@generated/audio/arcadeAudio';
import { ScreenShell } from '@generated/components/menu/ScreenShell';
import { Panel } from '@generated/components/hud/Panel';
import { HudButton } from '@generated/components/hud/HudButton';
import { CrystalAmount, Stars } from '@generated/components/hud/Meter';
import { RARITY_BG, RARITY_TEXT } from '@generated/components/hud/rarity';
import { PullReveal } from '@generated/components/warp/PullReveal';
import { cn } from '@lib/utils';

type Phase = 'idle' | 'charging' | 'flash' | 'reveal';

export function WarpGate({ onBack }: { onBack: () => void }) {
  const { save, update } = useSave();
  const [phase, setPhase] = useState<Phase>('idle');
  const [results, setResults] = useState<PullResult[]>([]);
  const [instant, setInstant] = useState(false);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);

  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  const top: Rarity = results.reduce<Rarity>((m, r) => (r.rarity > m ? r.rarity : m), 3);

  const pull = (count: 1 | 10) => {
    if (phase !== 'idle') return;
    const res = warp(save, count);
    if (!res) {
      audio.sfx('error');
      return;
    }
    update(() => res.save);
    setResults(res.results);
    setInstant(false);
    setPhase('charging');
    audio.sfx('charge');
    timers.current = [
      setTimeout(() => setPhase('flash'), 1900),
      setTimeout(() => setPhase('reveal'), 2300),
    ];
  };

  const featured = [...GACHA_5, ...GACHA_4].map(getShip);

  return (
    <ScreenShell
      section="EVENT // WARP GATE"
      title="Open the rift"
      subtitle="Spend crystals to pull rare ships from the void. Earn crystals from bosses, daily drops, the Battle Pass and achievements."
      onBack={onBack}
    >
      {phase === 'reveal' ? (
        <PullReveal results={results} instant={instant} onSkip={() => setInstant(true)} onDone={() => setPhase('idle')} />
      ) : (
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)] lg:items-center">
          {/* portal */}
          <div className={cn('relative mx-auto aspect-square w-full max-w-[520px]', phase === 'charging' && 'warp-charging')}>
            <div className="warp-core absolute inset-0">
              <div className="warp-spin absolute inset-[6%] rounded-full border border-foreground/25" />
              <div className="warp-spin-rev absolute inset-[14%] rounded-full border border-dashed border-foreground/40" />
              <img src={ASSETS.warpGate} alt="Wireframe warp gate portal" className="warp-spin absolute inset-[10%] size-[80%] rounded-full object-cover mix-blend-screen" />
              <div className={cn('warp-glow absolute inset-[30%] rounded-full opacity-0 blur-2xl', phase === 'charging' ? RARITY_BG[top] : 'bg-foreground')} />
            </div>
            {phase === 'charging' && (
              <div aria-hidden className={cn('beam-up absolute bottom-1/2 left-1/2 h-[60vh] w-3 -translate-x-1/2 blur-[2px]', RARITY_BG[top])} />
            )}
            <div className="absolute inset-x-0 bottom-0 text-center text-[11px] font-bold tracking-[0.24em] text-muted-foreground">
              {phase === 'charging' ? <span className="hud-blink">RIFT CHARGING //</span> : 'GATE STABLE // AWAITING INPUT'}
            </div>
          </div>

          {/* controls */}
          <div className="flex min-w-0 flex-col gap-5">
            <Panel label="PULL" active>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">YOUR CRYSTALS</span>
                <CrystalAmount value={save.crystals} className="text-2xl font-bold" />
              </div>
              <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
                <HudButton variant="outline" disabled={phase !== 'idle' || save.crystals < pullCost(1)} onClick={() => pull(1)}>
                  <Sparkles className="size-4" /> Warp x1 <CrystalAmount value={pullCost(1)} />
                </HudButton>
                <HudButton disabled={phase !== 'idle' || save.crystals < pullCost(10)} onClick={() => pull(10)}>
                  <Sparkles className="size-4" /> Warp x10 <CrystalAmount value={pullCost(10)} />
                </HudButton>
              </div>
              <dl className="mt-5 grid grid-cols-2 gap-3 border-t border-foreground/15 pt-4 text-xs">
                <div>
                  <dt className="text-muted-foreground">5★ GUARANTEED IN</dt>
                  <dd className={cn('text-lg font-bold tabular-nums', RARITY_TEXT[5])}>{Math.max(1, PITY_5 - save.gacha.pity5)} pulls</dd>
                </div>
                <div>
                  <dt className="text-muted-foreground">4★+ GUARANTEED IN</dt>
                  <dd className={cn('text-lg font-bold tabular-nums', RARITY_TEXT[4])}>{Math.max(1, PITY_4 - save.gacha.pity4)} pulls</dd>
                </div>
              </dl>
              <p className="mt-3 text-[11px] text-muted-foreground">
                Rates: 5★ {(RATE_5 * 100).toFixed(0)}% · 4★ {(RATE_4 * 100).toFixed(0)}% · 3★ salvage {((1 - RATE_5 - RATE_4) * 100).toFixed(0)}%. Duplicate ships convert to coins and crystals.
              </p>
            </Panel>

            <div>
              <div className="mb-3 text-xs font-bold tracking-[0.2em] text-muted-foreground">FEATURED IN THE RIFT</div>
              <ul className="grid grid-cols-2 gap-3">
                {featured.map((s) => (
                  <li key={s.id} className="hud-chamfer hud-chamfer-sm bg-foreground/30 p-px">
                    <div className="hud-chamfer hud-chamfer-sm hud-grid flex items-center gap-2 p-2">
                      <img src={s.image} alt={`${s.name} ship`} className="size-12 shrink-0 object-contain mix-blend-screen" />
                      <div className="min-w-0">
                        <Stars count={s.rarity} className={RARITY_TEXT[s.rarity]} />
                        <div className="truncate text-xs font-bold uppercase">{s.name}</div>
                        <div className="text-[10px] text-muted-foreground">{save.ownedShips.includes(s.id) ? 'OWNED' : 'NOT OWNED'}</div>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {phase === 'flash' && <div aria-hidden className={cn('warp-flash pointer-events-none fixed inset-0 z-50', RARITY_BG[top])} />}
    </ScreenShell>
  );
}
