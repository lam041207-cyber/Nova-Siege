import { Diamond, Gem, Star } from 'lucide-react';
import { cn } from '@lib/utils';

/** Chamfered progress meter. */
export function Meter({ value, max, className, danger, label }: { value: number; max: number; className?: string; danger?: boolean; label?: string }) {
  const pct = max > 0 ? Math.max(0, Math.min(100, (value / max) * 100)) : 0;
  return (
    <div
      role="progressbar"
      aria-label={label}
      aria-valuenow={Math.round(value)}
      aria-valuemin={0}
      aria-valuemax={Math.round(max)}
      className={cn('hud-chamfer hud-chamfer-xs h-2.5 w-full bg-foreground/15', className)}
    >
      <div
        className={cn('h-full transition-[width] duration-200 ease-out', danger ? 'bg-destructive' : 'bg-foreground')}
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}

/** Level pips, one square per level. */
export function Pips({ level, max }: { level: number; max: number }) {
  return (
    <div className="flex flex-wrap gap-1" aria-label={`Level ${level} of ${max}`}>
      {Array.from({ length: max }, (_, i) => (
        <span
          key={i}
          className={cn('h-2 w-3 border border-foreground/60', i < level && 'border-foreground bg-foreground shadow-[0_0_6px_hsl(var(--foreground)/0.6)]')}
        />
      ))}
    </div>
  );
}

export function CrystalAmount({ value, className }: { value: number; className?: string }) {
  return (
    <span className={cn('inline-flex items-center gap-1.5 tabular-nums', className)}>
      <Gem className="size-[0.9em] shrink-0" strokeWidth={2.2} aria-hidden />
      {Math.round(value).toLocaleString('en-US')}
    </span>
  );
}

export function Stars({ count, className }: { count: number; className?: string }) {
  return (
    <span className={cn('inline-flex items-center gap-0.5', className)} aria-label={`${count} star`}>
      {Array.from({ length: count }, (_, i) => (
        <Star key={`s${i}`} className="size-3.5 fill-current" strokeWidth={1.5} aria-hidden />
      ))}
    </span>
  );
}

export function CoinAmount({ value, className }: { value: number; className?: string }) {
  return (
    <span className={cn('inline-flex items-center gap-1.5 tabular-nums', className)}>
      <Diamond className="size-[0.9em] shrink-0" strokeWidth={2.2} aria-hidden />
      {Math.round(value).toLocaleString('en-US')}
    </span>
  );
}
