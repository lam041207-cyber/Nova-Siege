import type { ButtonHTMLAttributes } from 'react';
import { cn } from '@lib/utils';

interface HudButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'outline' | 'gold' | 'gold-outline';
  size?: 'sm' | 'md' | 'lg';
}

const PAD = {
  sm: 'min-h-10 px-3 py-2 text-xs',
  md: 'min-h-11 px-5 py-3 text-sm',
  lg: 'min-h-14 px-8 py-4 text-base sm:text-lg',
};

/** Chamfered action button: solid white primary or white outline secondary. */
export function HudButton({ variant = 'primary', size = 'md', className, children, type = 'button', ...props }: HudButtonProps) {
  const inner = cn(
    'hud-chamfer hud-chamfer-sm flex w-full items-center justify-center gap-2 font-bold uppercase tracking-[0.12em] transition-colors duration-150',
    PAD[size],
  );
  return (
    <button
      type={type}
      className={cn(
        'group hud-bloom relative inline-flex min-w-0 select-none outline-none transition-transform duration-150 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40 disabled:active:scale-100 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-foreground',
        className,
      )}
      {...props}
    >
      {variant === 'primary' ? (
        <span className={cn(inner, 'bg-foreground text-[hsl(var(--ink))] group-hover:bg-[hsl(var(--foreground-dim))] group-disabled:bg-foreground')}>
          {children}
        </span>
      ) : variant === 'gold' ? (
        <span className={cn(inner, 'bg-[hsl(var(--gold))] text-[hsl(var(--ink))] group-hover:bg-[hsl(var(--gold-dim))] group-disabled:bg-[hsl(var(--gold))]')}>
          {children}
        </span>
      ) : variant === 'gold-outline' ? (
        <span className="hud-chamfer hud-chamfer-sm block w-full bg-[hsl(var(--gold))] p-px">
          <span className={cn(inner, 'bg-background text-[hsl(var(--gold))] group-hover:bg-[hsl(var(--gold)/0.12)] group-disabled:bg-background')}>
            {children}
          </span>
        </span>
      ) : (
        <span className="hud-chamfer hud-chamfer-sm block w-full bg-foreground p-px">
          <span className={cn(inner, 'bg-background text-foreground group-hover:bg-[hsl(var(--surface-hover))] group-disabled:bg-background')}>
            {children}
          </span>
        </span>
      )}
    </button>
  );
}
