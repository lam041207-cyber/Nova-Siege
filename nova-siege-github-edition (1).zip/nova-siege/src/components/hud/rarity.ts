import type { Rarity } from '@generated/data/config';

export const RARITY_TEXT: Record<Rarity, string> = {
  3: 'text-foreground',
  4: 'text-[hsl(var(--rare-4))]',
  5: 'text-[hsl(var(--rare-5))]',
};

export const RARITY_BG: Record<Rarity, string> = {
  3: 'bg-foreground',
  4: 'bg-[hsl(var(--rare-4))]',
  5: 'bg-[hsl(var(--rare-5))]',
};

export const RARITY_GLOW: Record<Rarity, string> = {
  3: 'drop-shadow-[0_0_10px_hsl(var(--rare-3)/0.45)]',
  4: 'drop-shadow-[0_0_16px_hsl(var(--rare-4)/0.75)]',
  5: 'drop-shadow-[0_0_22px_hsl(var(--rare-5)/0.85)]',
};

export const RARITY_LABEL: Record<Rarity, string> = { 3: 'RARE', 4: 'EPIC', 5: 'LEGENDARY' };
