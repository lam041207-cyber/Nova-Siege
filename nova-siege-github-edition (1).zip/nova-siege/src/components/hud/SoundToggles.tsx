import { Music, Volume2, VolumeX } from 'lucide-react';
import { useSave } from '@generated/hooks/useSave';
import { cn } from '@lib/utils';

/** Music + sound-effect switches, saved with progress. */
export function SoundToggles({ compact }: { compact?: boolean }) {
  const { save, update } = useSave();
  const { music, sfx } = save.settings;
  const item = (on: boolean) =>
    cn(
      'hud-chamfer hud-chamfer-xs inline-flex min-h-11 items-center gap-1.5 px-3 text-[11px] font-bold tracking-[0.14em] transition-colors',
      on ? 'bg-foreground text-[hsl(var(--ink))] hover:bg-[hsl(var(--foreground-dim))]' : 'bg-foreground/10 text-muted-foreground hover:bg-foreground/20',
    );
  return (
    <div className="flex gap-2">
      <button
        type="button"
        aria-pressed={music}
        aria-label="Music"
        className={item(music)}
        onClick={() => update((s) => ({ ...s, settings: { ...s.settings, music: !s.settings.music } }))}
      >
        <Music className="size-4" />
        {!compact && (music ? 'MUSIC ON' : 'MUSIC OFF')}
      </button>
      <button
        type="button"
        aria-pressed={sfx}
        aria-label="Sound effects"
        className={item(sfx)}
        onClick={() => update((s) => ({ ...s, settings: { ...s.settings, sfx: !s.settings.sfx } }))}
      >
        {sfx ? <Volume2 className="size-4" /> : <VolumeX className="size-4" />}
        {!compact && (sfx ? 'SFX ON' : 'SFX OFF')}
      </button>
    </div>
  );
}
