import type { ReactNode } from 'react';
import { cn } from '@lib/utils';

interface PanelProps {
  label?: string;
  children: ReactNode;
  className?: string;
  innerClassName?: string;
  /** brighter edge + glow, for the focal panel */
  active?: boolean;
  /** gold edge + label, used by the Support page */
  tone?: 'white' | 'gold';
}

/** Notched chamfer panel: doubled white edge, cut corners, top tab-notch label, soft bloom. */
export function Panel({ label, children, className, innerClassName, active, tone = 'white' }: PanelProps) {
  const gold = tone === 'gold';
  return (
    <div className={cn('relative min-w-0', gold ? 'hud-bloom-gold' : active ? 'hud-bloom-strong' : 'hud-bloom', label && 'pt-3', className)}>
      {label && (
        <span
          className={cn(
            'hud-chamfer hud-chamfer-xs absolute left-5 top-0 z-10 px-2.5 py-[3px] text-[11px] font-bold uppercase leading-none tracking-[0.14em] text-[hsl(var(--ink))]',
            gold ? 'bg-[hsl(var(--gold))]' : 'bg-foreground',
          )}
        >
          {label}
        </span>
      )}
      <div className={cn('hud-chamfer h-full p-px', gold ? 'bg-[hsl(var(--gold))]' : active ? 'bg-foreground' : 'bg-foreground/85')}>
        <div className="hud-chamfer hud-grid h-full p-[3px]">
          <div className={cn('hud-chamfer h-full p-px', gold ? 'bg-[hsl(var(--gold)/0.3)]' : 'bg-foreground/25')}>
            <div className={cn('hud-chamfer hud-grid h-full p-4 sm:p-5', label && 'pt-5', innerClassName)}>{children}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

/** Thin white callout line tipped with a node dot. */
export function Connector({ className, vertical }: { className?: string; vertical?: boolean }) {
  return (
    <div aria-hidden className={cn('pointer-events-none absolute flex items-center', vertical && 'flex-col', className)}>
      <span className="size-1.5 shrink-0 rounded-full bg-foreground shadow-[0_0_8px_hsl(var(--foreground)/0.8)]" />
      <span className={cn('bg-foreground/70', vertical ? 'w-px flex-1' : 'h-px flex-1')} />
      <span className="size-1.5 shrink-0 rounded-full bg-foreground shadow-[0_0_8px_hsl(var(--foreground)/0.8)]" />
    </div>
  );
}

/** Vertical glowing ID badge, the one rounded element. */
export function IdBadge({ code, className }: { code: string; className?: string }) {
  return (
    <div
      aria-hidden
      className={cn(
        'flex flex-col items-center rounded-[var(--radius-badge)] border-2 border-foreground px-1.5 py-2 font-[family-name:var(--font-display)] text-xl leading-[1.05] shadow-[0_0_18px_hsl(var(--foreground)/0.7)]',
        className,
      )}
    >
      {code.split('').map((ch, i) => (
        <span key={`${ch}-${i}`}>{ch}</span>
      ))}
    </div>
  );
}
