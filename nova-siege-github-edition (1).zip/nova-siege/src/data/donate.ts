/**
 * NOVA SIEGE // DONATION SETTINGS
 * ------------------------------------------------------------------
 * Every payment detail shown on the Support page lives in this file.
 * Nothing here is sent to a server, and the game never handles money:
 * players complete every donation in their own app or on a hosted checkout page.
 *
 * QR CODES
 *   Leave `qrImage` empty ('') until you have your real QR image. The page shows a
 *   "QR not added yet" frame instead. To add one:
 *     - GitHub Pages edition: put the file in `public/donate/` (e.g. `public/donate/momo-qr.png`)
 *       and set `qrImage: './donate/momo-qr.png'`.
 *     - Or paste any https:// image address.
 *
 * LOGOS
 *   Leave `logo` empty to use the built-in wordmark badge, or point it at an official logo file
 *   the same way as a QR image.
 *
 * INTERNATIONAL CHECKOUT
 *   Leave `checkoutUrl` empty until you have a hosted checkout or donation page from a payment
 *   provider (for example a Ko-fi, Buy Me a Coffee or PayPal donation page, or a Stripe/Lemon Squeezy
 *   payment link). The card form must live on THEIR page — never add card fields to this game.
 */

export type CurrencyCode = 'USD' | 'EUR' | 'VND';

export interface WalletMethod {
  id: 'momo' | 'zalopay';
  kind: 'wallet';
  provider: string;
  phone: string;
  /** Optional recipient name shown under the number. */
  recipientName: string;
  qrImage: string;
  logo: string;
  /** Optional official payment link from the provider. Empty = button shows manual steps. */
  payUrl: string;
  steps: string[];
}

export interface BankMethod {
  id: 'bank';
  kind: 'bank';
  provider: string;
  bankName: string;
  accountNumber: string;
  accountHolder: string;
  qrImage: string;
  logo: string;
  payUrl: string;
  steps: string[];
}

export type LocalMethod = WalletMethod | BankMethod;

export const DONATE = {
  /** Suggested transfer message so you can recognise donations in your history. */
  transferNote: 'NOVA SIEGE DONATE',

  local: [
    {
      id: 'momo',
      kind: 'wallet',
      provider: 'MoMo',
      phone: '0932723431',
      recipientName: 'NGUYEN BAO LAM',
      qrImage: '',
      logo: '',
      payUrl: '',
      steps: ['Open the MoMo app', 'Choose "Chuyển tiền" (Transfer) and paste the phone number', 'Enter any amount, add the message, confirm'],
    },
    {
      id: 'zalopay',
      kind: 'wallet',
      provider: 'ZaloPay',
      phone: '0932723431',
      recipientName: 'NGUYEN BAO LAM',
      qrImage: '',
      logo: '',
      payUrl: '',
      steps: ['Open the ZaloPay app', 'Choose "Chuyển tiền" (Transfer) and paste the phone number', 'Enter any amount, add the message, confirm'],
    },
    {
      id: 'bank',
      kind: 'bank',
      provider: 'MB Bank',
      bankName: 'MB Bank (Military Commercial Joint Stock Bank)',
      accountNumber: '0932723431',
      accountHolder: 'NGUYEN BAO LAM',
      qrImage: '',
      logo: '',
      payUrl: '',
      steps: ['Open your banking app', 'Choose MB Bank, paste the account number and check the holder name', 'Enter any amount, add the message, confirm'],
    },
  ] satisfies LocalMethod[] as LocalMethod[],

  international: {
    method: 'Visa Debit / Credit',
    /** Display name of the provider once connected, e.g. 'Ko-fi'. */
    providerName: '',
    /** Hosted checkout page (must start with https://). Empty = not configured yet. */
    checkoutUrl: '',
    /** Add the chosen amount and currency to the checkout address as query parameters. */
    passAmount: true,
    amountParam: 'amount',
    currencyParam: 'currency',
  },

  amounts: {
    presets: {
      USD: [1, 3, 5, 10],
      EUR: [1, 3, 5, 10],
      VND: [20_000, 50_000, 100_000, 200_000],
    } satisfies Record<CurrencyCode, number[]>,
    min: { USD: 1, EUR: 1, VND: 10_000 } satisfies Record<CurrencyCode, number>,
    max: { USD: 1_000, EUR: 1_000, VND: 25_000_000 } satisfies Record<CurrencyCode, number>,
  },
};

export const CURRENCIES: { code: CurrencyCode; label: string }[] = [
  { code: 'USD', label: 'USD — US dollar' },
  { code: 'EUR', label: 'EUR — Euro' },
  { code: 'VND', label: 'VND — Vietnamese đồng' },
];

export function formatAmount(value: number, currency: CurrencyCode): string {
  if (currency === 'VND') return `${value.toLocaleString('vi-VN')} ₫`;
  const symbol = currency === 'USD' ? '$' : '€';
  return `${symbol}${value.toLocaleString('en-US', { maximumFractionDigits: 2 })}`;
}

/** Parses a typed amount ("50.000", "5,5", "12") into a number, or returns an error message. */
export function parseAmount(raw: string, currency: CurrencyCode): { value: number } | { error: string } {
  const cleaned = currency === 'VND' ? raw.replace(/[.,\s₫]/g, '') : raw.replace(/[\s$€]/g, '').replace(',', '.');
  if (!cleaned) return { error: 'Enter an amount, or pick one above.' };
  if (!/^\d+(\.\d{1,2})?$/.test(cleaned)) return { error: currency === 'VND' ? 'Use whole numbers only.' : 'Use numbers with up to 2 decimals.' };
  const value = Number(cleaned);
  const min = DONATE.amounts.min[currency];
  const max = DONATE.amounts.max[currency];
  if (value < min) return { error: `Minimum is ${formatAmount(min, currency)}.` };
  if (value > max) return { error: `Maximum is ${formatAmount(max, currency)}.` };
  return { value };
}

/** True only for a real https address — blocks javascript: and plain http links. */
export function isSafeUrl(url: string): boolean {
  try {
    return new URL(url).protocol === 'https:';
  } catch {
    return false;
  }
}

export function checkoutReady(): boolean {
  return isSafeUrl(DONATE.international.checkoutUrl);
}

export function buildCheckoutUrl(amount: number | null, currency: CurrencyCode): string | null {
  const cfg = DONATE.international;
  if (!isSafeUrl(cfg.checkoutUrl)) return null;
  const url = new URL(cfg.checkoutUrl);
  if (cfg.passAmount && amount !== null) {
    url.searchParams.set(cfg.amountParam, String(amount));
    url.searchParams.set(cfg.currencyParam, currency);
  }
  return url.toString();
}
