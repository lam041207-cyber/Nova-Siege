import {
  ACHIEVEMENTS,
  DAILY_CRYSTALS,
  DAILY_REWARDS,
  PASS_TIERS,
  PASS_TIERS_COUNT,
  PASS_XP_PER_TIER,
  PERKS,
  SHIPS,
  UPGRADES,
  upgradeCost,
  type AchievementDef,
  type PerkId,
  type PerkLevels,
  type ShipId,
  type UpgradeId,
  type UpgradeLevels,
} from '@generated/data/config';
import type { RunSummary } from '@generated/engine/types';

export interface SaveData {
  coins: number;
  crystals: number;
  totalCoinsEarned: number;
  upgrades: UpgradeLevels;
  perks: PerkLevels;
  ownedShips: ShipId[];
  selectedShip: ShipId;
  bestWave: number;
  bestRunKills: number;
  totalKills: number;
  totalBosses: number;
  runs: number;
  passXp: number;
  passClaimed: number[];
  daily: { streak: number; lastClaim: string | null };
  achievementsClaimed: string[];
  gacha: { pulls: number; pity5: number; pity4: number };
  settings: { music: boolean; sfx: boolean };
  callsign: string;
  legal: { version: string | null; acceptedAt: string | null; underage: boolean };
}

const ZERO_UPGRADES: UpgradeLevels = { damage: 0, fireRate: 0, multishot: 0, hull: 0, shield: 0, thrusters: 0, coinBonus: 0, magnet: 0 };
const ZERO_PERKS: PerkLevels = { bombBay: 0, chainReaction: 0, critCore: 0, phoenix: 0, luckyDrop: 0, bossBreaker: 0 };

export const DEFAULT_SAVE: SaveData = {
  coins: 0,
  crystals: 100,
  totalCoinsEarned: 0,
  upgrades: ZERO_UPGRADES,
  perks: ZERO_PERKS,
  ownedShips: ['wisp'],
  selectedShip: 'wisp',
  bestWave: 0,
  bestRunKills: 0,
  totalKills: 0,
  totalBosses: 0,
  runs: 0,
  passXp: 0,
  passClaimed: [],
  daily: { streak: 0, lastClaim: null },
  achievementsClaimed: [],
  gacha: { pulls: 0, pity5: 0, pity4: 0 },
  settings: { music: true, sfx: true },
  callsign: '',
  legal: { version: null, acceptedAt: null, underage: false },
};

/** Wipe gameplay progress but keep policy acceptance and sound settings. */
export function eraseProgress(s: SaveData): SaveData {
  return { ...DEFAULT_SAVE, settings: s.settings, legal: s.legal };
}

const num = (v: unknown, d = 0) => (typeof v === 'number' && Number.isFinite(v) ? v : d);
const obj = (v: unknown) => (v && typeof v === 'object' ? (v as Record<string, unknown>) : {});
const isShip = (v: unknown): v is ShipId => SHIPS.some((s) => s.id === v);

export function normalizeSave(raw: unknown): SaveData {
  if (!raw || typeof raw !== 'object') return DEFAULT_SAVE;
  const r = raw as Record<string, unknown>;
  const up = obj(r.upgrades);
  const upgrades = { ...ZERO_UPGRADES };
  for (const def of UPGRADES) upgrades[def.id] = Math.min(def.max, num(up[def.id]));
  const pk = obj(r.perks);
  const perks = { ...ZERO_PERKS };
  for (const def of PERKS) perks[def.id] = Math.min(def.max, num(pk[def.id]));
  const owned = Array.isArray(r.ownedShips) ? r.ownedShips.filter(isShip) : [];
  if (!owned.includes('wisp')) owned.unshift('wisp');
  const daily = obj(r.daily);
  const gacha = obj(r.gacha);
  const settings = obj(r.settings);
  return {
    coins: num(r.coins),
    crystals: num(r.crystals, DEFAULT_SAVE.crystals),
    totalCoinsEarned: num(r.totalCoinsEarned),
    upgrades,
    perks,
    ownedShips: owned,
    selectedShip: isShip(r.selectedShip) && owned.includes(r.selectedShip) ? r.selectedShip : 'wisp',
    bestWave: num(r.bestWave),
    bestRunKills: num(r.bestRunKills),
    totalKills: num(r.totalKills),
    totalBosses: num(r.totalBosses),
    runs: num(r.runs),
    passXp: num(r.passXp),
    passClaimed: Array.isArray(r.passClaimed) ? r.passClaimed.filter((n): n is number => typeof n === 'number') : [],
    daily: { streak: num(daily.streak), lastClaim: typeof daily.lastClaim === 'string' ? daily.lastClaim : null },
    achievementsClaimed: Array.isArray(r.achievementsClaimed) ? r.achievementsClaimed.filter((s): s is string => typeof s === 'string') : [],
    gacha: { pulls: num(gacha.pulls), pity5: num(gacha.pity5), pity4: num(gacha.pity4) },
    settings: { music: settings.music !== false, sfx: settings.sfx !== false },
    callsign: typeof r.callsign === 'string' ? r.callsign.slice(0, 16) : '',
    legal: {
      version: typeof obj(r.legal).version === 'string' ? (obj(r.legal).version as string) : null,
      acceptedAt: typeof obj(r.legal).acceptedAt === 'string' ? (obj(r.legal).acceptedAt as string) : null,
      underage: obj(r.legal).underage === true,
    },
  };
}

export const earn = (s: SaveData, coins: number, crystals = 0): SaveData => ({
  ...s,
  coins: s.coins + coins,
  crystals: s.crystals + crystals,
  totalCoinsEarned: s.totalCoinsEarned + coins,
});

export function applyRun(s: SaveData, run: RunSummary): SaveData {
  const next = earn(s, run.coins, run.crystals);
  return {
    ...next,
    bestWave: Math.max(s.bestWave, run.wave),
    bestRunKills: Math.max(s.bestRunKills, run.kills),
    totalKills: s.totalKills + run.kills,
    totalBosses: s.totalBosses + run.bosses,
    runs: s.runs + 1,
    passXp: s.passXp + run.xp,
  };
}

export function buyUpgrade(s: SaveData, id: UpgradeId): SaveData {
  const def = UPGRADES.find((u) => u.id === id);
  if (!def) return s;
  const level = s.upgrades[id];
  const cost = upgradeCost(def, level);
  if (level >= def.max || s.coins < cost) return s;
  return { ...s, coins: s.coins - cost, upgrades: { ...s.upgrades, [id]: level + 1 } };
}

export function buyPerk(s: SaveData, id: PerkId): SaveData {
  const def = PERKS.find((p) => p.id === id);
  if (!def) return s;
  const level = s.perks[id];
  const cost = upgradeCost(def, level);
  if (level >= def.max || s.coins < cost) return s;
  return { ...s, coins: s.coins - cost, perks: { ...s.perks, [id]: level + 1 } };
}

export function buyShip(s: SaveData, id: ShipId): SaveData {
  const ship = SHIPS.find((x) => x.id === id);
  if (!ship || ship.gachaOnly || s.ownedShips.includes(id) || s.coins < ship.cost) return s;
  return { ...s, coins: s.coins - ship.cost, ownedShips: [...s.ownedShips, id], selectedShip: id };
}

export function selectShip(s: SaveData, id: ShipId): SaveData {
  return s.ownedShips.includes(id) ? { ...s, selectedShip: id } : s;
}

export function todayKey(d: Date = new Date()): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function yesterdayKey(): string {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return todayKey(d);
}

export function dailyStatus(s: SaveData) {
  const claimedToday = s.daily.lastClaim === todayKey();
  const continuing = s.daily.lastClaim === yesterdayKey();
  const streak = claimedToday || continuing ? s.daily.streak : 0;
  const claimedInCycle = claimedToday ? ((streak - 1) % 7) + 1 : streak % 7;
  return { claimedToday, streak, claimedInCycle, canClaim: !claimedToday };
}

export function claimDaily(s: SaveData): SaveData {
  const st = dailyStatus(s);
  if (!st.canClaim) return s;
  const coins = DAILY_REWARDS[st.claimedInCycle] ?? DAILY_REWARDS[0]!;
  const crystals = DAILY_CRYSTALS[st.claimedInCycle] ?? DAILY_CRYSTALS[0]!;
  return { ...earn(s, coins, crystals), daily: { streak: st.streak + 1, lastClaim: todayKey() } };
}

export function passTier(s: SaveData): number {
  return Math.min(PASS_TIERS_COUNT, Math.floor(s.passXp / PASS_XP_PER_TIER));
}

export function claimTier(s: SaveData, tier: number): SaveData {
  const reward = PASS_TIERS.find((t) => t.tier === tier);
  if (!reward || tier > passTier(s) || s.passClaimed.includes(tier)) return s;
  const claimed = { ...s, passClaimed: [...s.passClaimed, tier], crystals: s.crystals + reward.crystals };
  if (reward.kind === 'ship' && reward.shipId && !s.ownedShips.includes(reward.shipId)) {
    return { ...claimed, ownedShips: [...s.ownedShips, reward.shipId] };
  }
  return earn(claimed, reward.amount);
}

export function claimAllTiers(s: SaveData): SaveData {
  let next = s;
  for (const t of PASS_TIERS) next = claimTier(next, t.tier);
  return next;
}

export function metricValue(s: SaveData, a: AchievementDef): number {
  switch (a.metric) {
    case 'kills':
      return s.totalKills;
    case 'bosses':
      return s.totalBosses;
    case 'bestWave':
      return s.bestWave;
    case 'totalCoins':
      return s.totalCoinsEarned;
    case 'runs':
      return s.runs;
    case 'ships':
      return s.ownedShips.length;
    case 'pulls':
      return s.gacha.pulls;
  }
}

export function claimAchievement(s: SaveData, id: string): SaveData {
  const a = ACHIEVEMENTS.find((x) => x.id === id);
  if (!a || s.achievementsClaimed.includes(id) || metricValue(s, a) < a.target) return s;
  return { ...earn(s, a.reward, a.crystals), achievementsClaimed: [...s.achievementsClaimed, id] };
}

export function pendingRewards(s: SaveData): number {
  const ach = ACHIEVEMENTS.filter((a) => !s.achievementsClaimed.includes(a.id) && metricValue(s, a) >= a.target).length;
  return ach + (dailyStatus(s).canClaim ? 1 : 0);
}

export function pendingPass(s: SaveData): number {
  const tier = passTier(s);
  return PASS_TIERS.filter((t) => t.tier <= tier && !s.passClaimed.includes(t.tier)).length;
}
