/** Terms of Use, Privacy Policy and age rating for Nova Siege. Bump LEGAL_VERSION when the text changes materially. */

export const LEGAL_VERSION = '2026-11-08.2';
export const EFFECTIVE_DATE = 'November 8, 2026';
export const MIN_AGE = 13;
export const CREATOR = 'Bảo Lâm Nguyễn';

export type LegalTab = 'terms' | 'privacy' | 'age';

export interface LegalSection {
  title: string;
  body: string[];
  list?: string[];
}

export const TERMS: LegalSection[] = [
  {
    title: '1. Acceptance',
    body: [
      'These Terms of Use ("Terms") apply to Nova Siege (the "Game"). By playing the Game you agree to these Terms and to the Privacy Policy. If you do not agree, do not play.',
    ],
  },
  {
    title: '2. Age requirement',
    body: [
      `You must be at least ${MIN_AGE} years old to play. If you are under 18, or under the age of digital consent where you live, you may only play with the permission of a parent or legal guardian who has read these Terms.`,
      `Players who indicate they are under ${MIN_AGE} are blocked from playing on that device.`,
    ],
  },
  {
    title: '3. Free to play',
    body: ['The Game is completely free. There are no in-game purchases, subscriptions, real-money payments or advertisements.'],
    list: [
      'The Support page lets you send an optional donation to the developer. Donations are voluntary gifts, are completed outside the Game (in MoMo, ZaloPay, your bank app or a payment provider\'s hosted checkout), unlock nothing in the Game and are handled under that service\'s own terms. Players under 18 must ask a parent or guardian first.',
      'Coins, crystals, ships, perks and Battle Pass rewards are virtual items earned only by playing.',
      'Virtual items have no real-world monetary value and cannot be bought, sold, traded, transferred or exchanged for money or anything of value.',
      'Virtual items may be changed, rebalanced or removed in updates.',
    ],
  },
  {
    title: '4. Warp Gate (chance-based rewards)',
    body: [
      'The Warp Gate gives random rewards in exchange for in-game crystals only. Crystals cannot be purchased with real money.',
      'Current odds and guarantees are shown in the Warp Gate before every pull. Odds may change in updates; the odds displayed at the time of a pull apply to that pull.',
    ],
  },
  {
    title: '5. Your progress',
    body: [
      'Your progress is saved in your browser on your device. Clearing browser data, using private browsing, or switching device or browser can permanently erase it. Lost progress cannot be restored.',
    ],
  },
  {
    title: '6. Leaderboard and callsigns',
    body: ['Your callsign and scores appear on the leaderboard stored in your own browser. They are not uploaded anywhere, but anyone using your device or seeing your screenshots can see them.'],
    list: [
      'Do not use callsigns that are offensive, hateful, sexual, threatening, impersonate someone else, or include personal information such as your real full name, phone number or address.',
      'Scores that appear cheated, modified or impossible may be removed without notice.',
      'Callsigns that break these rules may be renamed or removed, and leaderboards may be reset at any time.',
    ],
  },
  {
    title: '7. Acceptable use',
    body: ['You agree not to:'],
    list: [
      'cheat, edit save data, or use bots, scripts or tools to automate play or alter results;',
      'exploit bugs to gain an advantage (please report them instead);',
      'attack, overload, probe or disrupt the Game or the website that hosts it;',
      'copy, resell or redistribute the Game or its art, music or code without permission.',
    ],
  },
  {
    title: '8. Ownership',
    body: [
      `The Game, including its code, artwork, music and sound, belongs to its creator, ${CREATOR}. You receive a personal, non-commercial, revocable permission to play it. All other rights are reserved.`,
    ],
  },
  {
    title: '9. Changes and availability',
    body: [
      'The Game may be updated, changed, paused or shut down at any time without notice. These Terms may be updated; the effective date above will change and you will be asked to accept the new version before playing again.',
    ],
  },
  {
    title: '10. Disclaimer and limitation of liability',
    body: [
      'The Game is provided "as is" and "as available", without warranties of any kind. To the fullest extent permitted by law, the creator is not liable for lost progress, interruptions, or any indirect or consequential damages arising from use of the Game. Nothing in these Terms limits rights you have under consumer laws that cannot be waived.',
    ],
  },
  {
    title: '11. Contact',
    body: [`Questions or requests about these Terms can be sent to the Game's creator, ${CREATOR}, through the page or channel where you found the Game.`],
  },
];

export const PRIVACY: LegalSection[] = [
  {
    title: '1. Summary',
    body: ['Nova Siege is designed to collect nothing about you.'],
    list: [
      'No account sign-up, no email address, no payment details.',
      "Optional donations happen in your own wallet or bank app, or on a payment provider's checkout page, under their privacy policy. The Game never receives card or bank details.",
      'No advertising, no analytics, no tracking, no selling or renting of data.',
      'The Game has no server and does not upload your progress or scores.',
    ],
  },
  {
    title: '2. Stored only on your device',
    body: [
      "Your progress (coins, crystals, ships, upgrades, perks, Battle Pass, rewards, Warp Gate history), sound settings, callsign, local leaderboard runs and your acceptance of these policies are stored in your browser's local storage. This data never leaves your device unless you export a save file yourself.",
    ],
  },
  {
    title: '3. Save files',
    body: [
      'When you choose Download save, the Game creates a file on your device containing your progress. You decide where to keep or share it. Restoring a file only reads it inside your browser.',
    ],
  },
  {
    title: '4. Hosting and service providers',
    body: [
      'The Game is published as static files on GitHub Pages. GitHub may process technical information such as your IP address and browser details when your browser loads the site, under the GitHub Privacy Statement. Fonts are loaded from Google Fonts, which can also see your IP address when your browser requests them.',
    ],
  },
  {
    title: '5. Retention',
    body: ['Local data stays on your device until you erase it with the controls below or clear your browser data.'],
  },
  {
    title: '6. Children',
    body: [`The Game is not intended for children under ${MIN_AGE}. It does not collect personal information from anyone, including children.`],
  },
  {
    title: '7. Your choices',
    body: ['You can clear the local leaderboard and erase your local progress at any time with the controls below.'],
  },
  {
    title: '8. Changes and contact',
    body: [
      `If this policy changes, the effective date will be updated and you will be asked to accept it again. Contact: ${CREATOR}, through the page or channel where you found the Game.`,
    ],
  },
];

export const AGE_RATING = {
  label: `${MIN_AGE}+`,
  descriptors: [
    { title: 'Fantasy violence', text: 'Abstract spaceships and wireframe creatures explode when shot. No blood, gore or human characters.' },
    { title: 'Chance-based rewards', text: 'The Warp Gate gives random ships and items for in-game crystals. No real money can be spent.' },
    { title: 'Local leaderboard', text: "Runs are ranked on the player's own device only. There is no online play, chat or messaging between players." },
    { title: 'Flashing effects', text: 'Explosions, bombs and boss attacks create bright flashes and screen shake. Reduced-motion settings on your device turn off screen shake.' },
    { title: 'No purchases or ads', text: 'Everything is earned by playing. An optional Support page shows how to donate to the developer outside the game; donations unlock nothing.' },
  ],
  parents: `Nova Siege requires players to be ${MIN_AGE} or older. Teens should play with a parent or guardian's permission. Everything, including progress and the leaderboard, is stored on the device and can be erased at any time from the Privacy Policy page.`,
};
