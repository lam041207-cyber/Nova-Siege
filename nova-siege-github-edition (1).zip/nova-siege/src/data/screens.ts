export type Screen = 'menu' | 'hangar' | 'shop' | 'pass' | 'rewards' | 'warp' | 'leaderboard' | 'legal' | 'download' | 'donate' | 'play' | 'results';
