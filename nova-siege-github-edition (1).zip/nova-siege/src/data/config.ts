export const ASSETS = {
  keyArt:
    './images/key-art.jpg',
  warpGate:
    './images/warp-gate.jpg',
  bosses: [
    './images/boss-1.jpg',
    './images/boss-2.jpg',
    './images/boss-3.jpg',
  ],
};

export const BOSS_NAMES = ['HIVE QUEEN // MANDIBLE', 'IRON EYE // ORBITAL', 'LEVIATHAN // DREADNOUGHT'];

export type ShipId = 'wisp' | 'bastion' | 'needle' | 'sovereign' | 'tempest' | 'warden' | 'seraph' | 'eclipse';
export type ShipSpecial = 'none' | 'sideguns' | 'pierce' | 'missiles' | 'volatile' | 'aegis' | 'seraph' | 'nova';
export type Rarity = 3 | 4 | 5;

export interface ShipDef {
  id: ShipId;
  name: string;
  code: string;
  tagline: string;
  image: string;
  rarity: Rarity;
  /** coin price in the store; 0 with gachaOnly means warp-gate exclusive */
  cost: number;
  gachaOnly?: boolean;
  passTier?: number;
  hp: number;
  damage: number;
  fireRate: number;
  speed: number;
  bonusStreams?: number;
  special: ShipSpecial;
  specialLabel: string;
}

export const SHIPS: ShipDef[] = [
  {
    id: 'wisp', name: 'Wisp', code: 'VX-01', rarity: 3, cost: 0,
    tagline: 'Balanced interceptor. Reliable in every sector.',
    image: './images/ship-wisp.jpg',
    hp: 100, damage: 10, fireRate: 6, speed: 1, special: 'none', specialLabel: 'Standard pulse cannon',
  },
  {
    id: 'bastion', name: 'Bastion', code: 'HG-07', rarity: 3, cost: 2500,
    tagline: 'Armored gunship with twin wing cannons.',
    image: './images/ship-bastion.jpg',
    hp: 170, damage: 12, fireRate: 5, speed: 0.85, special: 'sideguns', specialLabel: 'Wing cannons fire angled shots',
  },
  {
    id: 'needle', name: 'Needle', code: 'ST-13', rarity: 4, cost: 6000, passTier: 15,
    tagline: 'Stealth striker. Rounds pierce through hulls.',
    image: './images/ship-needle.jpg',
    hp: 85, damage: 20, fireRate: 7, speed: 1.3, special: 'pierce', specialLabel: 'Piercing rounds hit 3 targets',
  },
  {
    id: 'sovereign', name: 'Sovereign', code: 'FL-99', rarity: 5, cost: 15000, passTier: 30,
    tagline: 'Legendary flagship with homing missile pods.',
    image: './images/ship-sovereign.jpg',
    hp: 210, damage: 18, fireRate: 6, speed: 1.05, special: 'missiles', specialLabel: 'Auto-launches homing missiles',
  },
  {
    id: 'tempest', name: 'Tempest', code: 'SR-44', rarity: 4, cost: 0, gachaOnly: true,
    tagline: 'Storm-class raider. Every kill detonates.',
    image: './images/ship-tempest.jpg',
    hp: 120, damage: 16, fireRate: 7.5, speed: 1.2, special: 'volatile', specialLabel: 'Kills always trigger chain explosions',
  },
  {
    id: 'warden', name: 'Warden', code: 'GD-52', rarity: 4, cost: 0, gachaOnly: true,
    tagline: 'Guardian frame wrapped in hex shield plates.',
    image: './images/ship-warden.jpg',
    hp: 230, damage: 14, fireRate: 6, speed: 0.95, bonusStreams: 1, special: 'aegis', specialLabel: 'Double shield, 3x faster recharge',
  },
  {
    id: 'seraph', name: 'Seraph', code: 'AX-77', rarity: 5, cost: 0, gachaOnly: true,
    tagline: 'Six-winged legend. Piercing light and seeker swarms.',
    image: './images/ship-seraph.jpg',
    hp: 190, damage: 24, fireRate: 8, speed: 1.25, bonusStreams: 1, special: 'seraph', specialLabel: 'Piercing rounds plus homing seekers',
  },
  {
    id: 'eclipse', name: 'Eclipse', code: 'NX-00', rarity: 5, cost: 0, gachaOnly: true,
    tagline: 'A ring around a captured singularity.',
    image: './images/ship-eclipse.jpg',
    hp: 220, damage: 22, fireRate: 9, speed: 1.1, bonusStreams: 2, special: 'nova', specialLabel: 'Fires a radial nova burst every 2s',
  },
];

export function getShip(id: ShipId): ShipDef {
  return SHIPS.find((s) => s.id === id) ?? SHIPS[0]!;
}

export type UpgradeId = 'damage' | 'fireRate' | 'multishot' | 'hull' | 'shield' | 'thrusters' | 'coinBonus' | 'magnet';

export interface UpgradeDef {
  id: UpgradeId;
  name: string;
  code: string;
  desc: string;
  max: number;
  baseCost: number;
  growth: number;
  effect: (level: number) => string;
}

export const UPGRADES: UpgradeDef[] = [
  { id: 'damage', name: 'Pulse Damage', code: 'DMG', desc: 'Harder hitting rounds', max: 10, baseCost: 120, growth: 1.55, effect: (l) => `+${l * 15}% damage` },
  { id: 'fireRate', name: 'Fire Rate', code: 'ROF', desc: 'Faster trigger cycle', max: 10, baseCost: 150, growth: 1.55, effect: (l) => `+${l * 8}% fire rate` },
  { id: 'multishot', name: 'Multi Barrel', code: 'MLT', desc: 'Extra parallel streams', max: 4, baseCost: 600, growth: 2.4, effect: (l) => `${l + 1} stream${l ? 's' : ''}` },
  { id: 'hull', name: 'Hull Plating', code: 'HUL', desc: 'More structural HP', max: 10, baseCost: 100, growth: 1.5, effect: (l) => `+${l * 20} HP` },
  { id: 'shield', name: 'Shield Matrix', code: 'SHD', desc: 'Regenerating barrier', max: 10, baseCost: 140, growth: 1.55, effect: (l) => `${20 + l * 15} shield` },
  { id: 'thrusters', name: 'Thrusters', code: 'THR', desc: 'Snappier tracking', max: 8, baseCost: 110, growth: 1.5, effect: (l) => `+${l * 10}% agility` },
  { id: 'coinBonus', name: 'Salvage Yield', code: 'YLD', desc: 'More coins per kill', max: 10, baseCost: 200, growth: 1.6, effect: (l) => `+${l * 10}% coins` },
  { id: 'magnet', name: 'Tractor Beam', code: 'MAG', desc: 'Wider pickup radius', max: 8, baseCost: 90, growth: 1.5, effect: (l) => `${70 + l * 25}px radius` },
];

export function upgradeCost(def: { baseCost: number; growth: number }, level: number): number {
  return Math.round(def.baseCost * Math.pow(def.growth, level));
}

export type UpgradeLevels = Record<UpgradeId, number>;

/* ---------- Store perks (permanent, bought with coins) ---------- */
export type PerkId = 'bombBay' | 'chainReaction' | 'critCore' | 'phoenix' | 'luckyDrop' | 'bossBreaker';
export type PerkLevels = Record<PerkId, number>;

export interface PerkDef {
  id: PerkId;
  name: string;
  code: string;
  desc: string;
  max: number;
  baseCost: number;
  growth: number;
  effect: (level: number) => string;
}

export const PERKS: PerkDef[] = [
  { id: 'bombBay', name: 'Bomb Bay', code: 'BMB', desc: 'Extra screen-clearing bombs each run', max: 3, baseCost: 900, growth: 2.2, effect: (l) => `${1 + l} bomb${l ? 's' : ''} per run` },
  { id: 'chainReaction', name: 'Chain Reaction', code: 'CHN', desc: 'Destroyed enemies explode and hit nearby hostiles', max: 5, baseCost: 1200, growth: 1.9, effect: (l) => (l ? `${50 + l * 18}px blast` : 'Locked') },
  { id: 'critCore', name: 'Crit Core', code: 'CRT', desc: 'Chance for 2.5x critical hits', max: 5, baseCost: 1000, growth: 1.8, effect: (l) => `${l * 5}% crit chance` },
  { id: 'luckyDrop', name: 'Lucky Salvage', code: 'LCK', desc: 'Power-ups drop more often', max: 4, baseCost: 800, growth: 1.9, effect: (l) => `+${l * 25}% drop rate` },
  { id: 'bossBreaker', name: 'Boss Breaker', code: 'BBK', desc: 'Bonus damage against bosses', max: 5, baseCost: 1500, growth: 1.8, effect: (l) => `+${l * 15}% vs bosses` },
  { id: 'phoenix', name: 'Phoenix Protocol', code: 'PHX', desc: 'Revive once per run at half hull', max: 1, baseCost: 6000, growth: 1, effect: (l) => (l ? '1 revive per run' : 'Locked') },
];

/* ---------- Run perks (picked after each boss) ---------- */
export type RunPerkId = 'overcharge' | 'hyper' | 'spread' | 'nanites' | 'munitions' | 'chain' | 'crit' | 'siphon' | 'greed';

export interface RunPerkDef {
  id: RunPerkId;
  name: string;
  desc: string;
}

export const RUN_PERKS: RunPerkDef[] = [
  { id: 'overcharge', name: 'Overcharge', desc: '+25% damage for this run' },
  { id: 'hyper', name: 'Hyper Cycle', desc: '+20% fire rate for this run' },
  { id: 'spread', name: 'Spread Array', desc: '+1 bullet stream' },
  { id: 'nanites', name: 'Nanite Hull', desc: 'Full repair and +25 max HP' },
  { id: 'munitions', name: 'Munitions Cache', desc: '+2 bombs' },
  { id: 'chain', name: 'Volatile Rounds', desc: '+1 chain explosion level' },
  { id: 'crit', name: 'Targeting AI', desc: '+10% critical hit chance' },
  { id: 'siphon', name: 'Siphon', desc: 'Heal 1 HP per kill' },
  { id: 'greed', name: 'Greed Engine', desc: '+30% coins and wider tractor beam' },
];

export interface PlayerStats {
  maxHp: number;
  maxShield: number;
  shieldRegen: number;
  damage: number;
  fireRate: number;
  agility: number;
  streams: number;
  coinMult: number;
  magnet: number;
  special: ShipSpecial;
  bombs: number;
  chain: number;
  crit: number;
  dropMult: number;
  bossMult: number;
  revives: number;
  siphon: number;
}

export function computeStats(ship: ShipDef, u: UpgradeLevels, p: PerkLevels): PlayerStats {
  const aegis = ship.special === 'aegis';
  const shield = (20 + u.shield * 15) * (aegis ? 2 : 1);
  return {
    maxHp: ship.hp + u.hull * 20,
    maxShield: shield,
    shieldRegen: aegis ? 0.54 : 0.18,
    damage: ship.damage * (1 + u.damage * 0.15),
    fireRate: ship.fireRate * (1 + u.fireRate * 0.08),
    agility: ship.speed * (1 + u.thrusters * 0.1),
    streams: 1 + u.multishot + (ship.bonusStreams ?? 0),
    coinMult: 1 + u.coinBonus * 0.1,
    magnet: 70 + u.magnet * 25,
    special: ship.special,
    bombs: 1 + p.bombBay,
    chain: p.chainReaction + (ship.special === 'volatile' ? 1 : 0),
    crit: p.critCore * 0.05,
    dropMult: 1 + p.luckyDrop * 0.25,
    bossMult: 1 + p.bossBreaker * 0.15,
    revives: p.phoenix,
    siphon: 0,
  };
}

/* ---------- Economy ---------- */
export const DAILY_REWARDS = [100, 150, 250, 350, 500, 700, 1200];
export const DAILY_CRYSTALS = [10, 10, 15, 15, 20, 30, 80];

export const PASS_XP_PER_TIER = 400;
export const PASS_TIERS_COUNT = 30;

export interface PassReward {
  tier: number;
  kind: 'coins' | 'ship';
  amount: number;
  crystals: number;
  shipId?: ShipId;
}

export const PASS_TIERS: PassReward[] = Array.from({ length: PASS_TIERS_COUNT }, (_, i) => {
  const tier = i + 1;
  const crystals = tier % 5 === 0 ? 50 : tier % 3 === 0 ? 15 : 0;
  if (tier === 15) return { tier, kind: 'ship', amount: 3000, crystals, shipId: 'needle' };
  if (tier === 30) return { tier, kind: 'ship', amount: 6000, crystals, shipId: 'sovereign' };
  if (tier % 5 === 0) return { tier, kind: 'coins', amount: 1000 * (tier / 5), crystals };
  return { tier, kind: 'coins', amount: 150 + tier * 25, crystals };
});

/* ---------- Warp gate (gacha) ---------- */
export const PULL_COST = 50;
export const PULL10_COST = 450;
export const RATE_5 = 0.02;
export const RATE_4 = 0.13;
export const PITY_5 = 50;
export const PITY_4 = 10;
export const GACHA_5: ShipId[] = ['seraph', 'eclipse'];
export const GACHA_4: ShipId[] = ['tempest', 'warden'];
export const DUPE_REFUND: Record<4 | 5, { coins: number; crystals: number }> = {
  4: { coins: 2000, crystals: 15 },
  5: { coins: 8000, crystals: 60 },
};

export type AchievementMetric = 'kills' | 'bosses' | 'bestWave' | 'totalCoins' | 'runs' | 'ships' | 'pulls';

export interface AchievementDef {
  id: string;
  name: string;
  desc: string;
  metric: AchievementMetric;
  target: number;
  reward: number;
  crystals: number;
}

export const ACHIEVEMENTS: AchievementDef[] = [
  { id: 'first-blood', name: 'First Blood', desc: 'Destroy your first enemy', metric: 'kills', target: 1, reward: 50, crystals: 10 },
  { id: 'exterminator', name: 'Exterminator', desc: 'Destroy 500 enemies', metric: 'kills', target: 500, reward: 600, crystals: 20 },
  { id: 'annihilator', name: 'Annihilator', desc: 'Destroy 5,000 enemies', metric: 'kills', target: 5000, reward: 3000, crystals: 60 },
  { id: 'giant-slayer', name: 'Giant Slayer', desc: 'Defeat your first boss', metric: 'bosses', target: 1, reward: 300, crystals: 30 },
  { id: 'boss-hunter', name: 'Boss Hunter', desc: 'Defeat 10 bosses', metric: 'bosses', target: 10, reward: 2000, crystals: 60 },
  { id: 'deep-space', name: 'Deep Space', desc: 'Reach wave 10', metric: 'bestWave', target: 10, reward: 500, crystals: 20 },
  { id: 'void-walker', name: 'Void Walker', desc: 'Reach wave 25', metric: 'bestWave', target: 25, reward: 2500, crystals: 60 },
  { id: 'collector', name: 'Collector', desc: 'Earn 10,000 coins in total', metric: 'totalCoins', target: 10000, reward: 1000, crystals: 20 },
  { id: 'veteran', name: 'Veteran', desc: 'Complete 25 runs', metric: 'runs', target: 25, reward: 800, crystals: 30 },
  { id: 'warp-runner', name: 'Warp Runner', desc: 'Make 30 warp gate pulls', metric: 'pulls', target: 30, reward: 1500, crystals: 50 },
  { id: 'armada', name: 'Armada', desc: 'Own every ship', metric: 'ships', target: SHIPS.length, reward: 5000, crystals: 100 },
];
