import {
  DUPE_REFUND,
  GACHA_4,
  GACHA_5,
  PITY_4,
  PITY_5,
  PULL10_COST,
  PULL_COST,
  RATE_4,
  RATE_5,
  type Rarity,
  type ShipId,
} from '@generated/data/config';
import { earn, type SaveData } from '@generated/data/progress';

export interface PullResult {
  rarity: Rarity;
  kind: 'ship' | 'coins';
  shipId?: ShipId;
  /** first time owning this ship */
  isNew: boolean;
  coins: number;
  crystals: number;
}

const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)] ?? arr[0]!;

export function pullCost(count: 1 | 10): number {
  return count === 10 ? PULL10_COST : PULL_COST;
}

/** Rolls `count` pulls against the save. Returns the new save and the results (or null when unaffordable). */
export function warp(save: SaveData, count: 1 | 10): { save: SaveData; results: PullResult[] } | null {
  const cost = pullCost(count);
  if (save.crystals < cost) return null;
  let s: SaveData = { ...save, crystals: save.crystals - cost };
  let { pity5, pity4 } = s.gacha;
  const owned = new Set(s.ownedShips);
  const results: PullResult[] = [];

  for (let i = 0; i < count; i++) {
    pity5++;
    pity4++;
    const roll = Math.random();
    let rarity: Rarity = 3;
    if (pity5 >= PITY_5 || roll < RATE_5) rarity = 5;
    else if (pity4 >= PITY_4 || roll < RATE_5 + RATE_4) rarity = 4;

    if (rarity === 3) {
      const coins = 250 + Math.floor(Math.random() * 7) * 100;
      results.push({ rarity, kind: 'coins', isNew: false, coins, crystals: 0 });
      s = earn(s, coins);
      continue;
    }
    if (rarity === 5) pity5 = 0;
    pity4 = 0;
    const shipId = pick(rarity === 5 ? GACHA_5 : GACHA_4);
    if (owned.has(shipId)) {
      const refund = DUPE_REFUND[rarity];
      results.push({ rarity, kind: 'ship', shipId, isNew: false, coins: refund.coins, crystals: refund.crystals });
      s = earn(s, refund.coins, refund.crystals);
    } else {
      owned.add(shipId);
      results.push({ rarity, kind: 'ship', shipId, isNew: true, coins: 0, crystals: 0 });
    }
  }

  s = { ...s, ownedShips: [...owned], gacha: { pulls: s.gacha.pulls + count, pity5, pity4 } };
  return { save: s, results };
}
