/** Local (on-device) ranking used by the GitHub Pages edition, where no server is available. */
import type { RunSummary } from '@generated/engine/types';

export interface LocalRun {
  id: string;
  callsign: string;
  wave: number;
  kills: number;
  bosses: number;
  ship: string;
  at: string;
}

const KEY = 'nova-siege-local-ranking-v1';
const KEEP = 50;

export function readRuns(): LocalRun[] {
  try {
    const raw = window.localStorage.getItem(KEY);
    const parsed: unknown = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (r): r is LocalRun =>
        !!r && typeof r === 'object' && typeof (r as LocalRun).id === 'string' && typeof (r as LocalRun).wave === 'number' && typeof (r as LocalRun).kills === 'number',
    );
  } catch (e) {
    console.error('Could not read local ranking', e);
    return [];
  }
}

function writeRuns(runs: LocalRun[]) {
  try {
    window.localStorage.setItem(KEY, JSON.stringify(runs));
  } catch (e) {
    console.error('Could not save local ranking', e);
  }
}

/** Keep the best runs by wave and by kills so both tabs stay meaningful. */
export function recordRun(run: RunSummary, callsign: string, ship: string): LocalRun[] {
  const entry: LocalRun = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    callsign: callsign.trim().slice(0, 16) || 'Pilot',
    wave: run.wave,
    kills: run.kills,
    bosses: run.bosses,
    ship,
    at: new Date().toISOString(),
  };
  const all = [...readRuns(), entry];
  const byWave = [...all].sort((a, b) => b.wave - a.wave || b.kills - a.kills).slice(0, KEEP);
  const byKills = [...all].sort((a, b) => b.kills - a.kills || b.wave - a.wave).slice(0, KEEP);
  const keep = new Map<string, LocalRun>();
  for (const r of [...byWave, ...byKills]) keep.set(r.id, r);
  const next = [...keep.values()];
  writeRuns(next);
  return next;
}

export function renameRuns(callsign: string) {
  const name = callsign.trim().slice(0, 16) || 'Pilot';
  writeRuns(readRuns().map((r) => ({ ...r, callsign: name })));
}

export function clearRuns() {
  writeRuns([]);
}
