import type { Game } from '@generated/engine/Game';
import type { Enemy, PowerKind } from '@generated/engine/types';

export interface Palette {
  bg: string;
  fg: string;
  grid: string;
  danger: string;
}

const POWER_GLYPH: Record<PowerKind, string> = { rapid: 'R', triple: 'T', shield: 'S', magnet: 'M', repair: 'H' };

export function readPalette(): Palette {
  const css = getComputedStyle(document.documentElement);
  const get = (name: string, fallback: string) => css.getPropertyValue(name).trim() || fallback;
  return {
    bg: get('--background', '240 36% 5.5%'),
    fg: get('--foreground', '240 30% 97%'),
    grid: get('--grid-line', '240 31% 12.5%'),
    danger: get('--destructive', '356 82% 62%'),
  };
}

const c = (tok: string, a = 1) => `hsl(${tok} / ${a})`;

function polygon(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, sides: number, rot: number) {
  ctx.beginPath();
  for (let i = 0; i < sides; i++) {
    const a = rot + (i / sides) * Math.PI * 2;
    const px = x + Math.cos(a) * r;
    const py = y + Math.sin(a) * r;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
}

function drawSprite(ctx: CanvasRenderingContext2D, img: HTMLImageElement | null | undefined, x: number, y: number, size: number) {
  if (!img || !img.complete || !img.naturalWidth) return false;
  const ratio = img.naturalWidth / img.naturalHeight;
  const w = ratio >= 1 ? size : size * ratio;
  const h = ratio >= 1 ? size / ratio : size;
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.drawImage(img, x - w / 2, y - h / 2, w, h);
  ctx.restore();
  return true;
}

function drawEnemy(ctx: CanvasRenderingContext2D, e: Enemy, pal: Palette) {
  ctx.strokeStyle = c(pal.fg, e.flash > 0 ? 1 : 0.92);
  ctx.fillStyle = c(pal.fg, e.flash > 0 ? 0.7 : 0.06);
  ctx.lineWidth = e.kind === 'tank' ? 2 : 1.5;
  const t = e.t;
  switch (e.kind) {
    case 'scout':
      ctx.beginPath();
      ctx.moveTo(e.x, e.y + e.r);
      ctx.lineTo(e.x - e.r, e.y - e.r * 0.7);
      ctx.lineTo(e.x, e.y - e.r * 0.2);
      ctx.lineTo(e.x + e.r, e.y - e.r * 0.7);
      ctx.closePath();
      break;
    case 'zigzag':
      polygon(ctx, e.x, e.y, e.r, 4, Math.PI / 4 + t);
      break;
    case 'tank':
      polygon(ctx, e.x, e.y, e.r, 6, t * 0.4);
      break;
    case 'shooter':
      ctx.beginPath();
      ctx.moveTo(e.x - e.r, e.y - e.r * 0.6);
      ctx.lineTo(e.x, e.y + e.r);
      ctx.lineTo(e.x + e.r, e.y - e.r * 0.6);
      ctx.lineTo(e.x + e.r * 0.4, e.y - e.r * 0.6);
      ctx.lineTo(e.x, e.y + e.r * 0.2);
      ctx.lineTo(e.x - e.r * 0.4, e.y - e.r * 0.6);
      ctx.closePath();
      break;
    case 'diver':
      polygon(ctx, e.x, e.y, e.r, 3, e.diving ? Math.atan2(e.vy, e.vx) : Math.PI / 2);
      break;
  }
  ctx.fill();
  ctx.stroke();
  if (e.kind === 'tank') {
    polygon(ctx, e.x, e.y, e.r * 0.5, 6, -t * 0.8);
    ctx.stroke();
  }
  if (e.hp < e.maxHp && e.kind === 'tank') {
    ctx.fillStyle = c(pal.fg, 0.2);
    ctx.fillRect(e.x - e.r, e.y - e.r - 9, e.r * 2, 2);
    ctx.fillStyle = c(pal.fg, 0.9);
    ctx.fillRect(e.x - e.r, e.y - e.r - 9, (e.r * 2 * e.hp) / e.maxHp, 2);
  }
}

export function render(g: Game, ctx: CanvasRenderingContext2D, pal: Palette, reducedMotion: boolean) {
  const { w, h } = g;
  ctx.fillStyle = c(pal.bg);
  ctx.fillRect(0, 0, w, h);
  ctx.save();
  if (!reducedMotion && g.shake > 0) ctx.translate((Math.random() - 0.5) * g.shake, (Math.random() - 0.5) * g.shake);

  // vector grid, scrolling
  const gs = 36;
  const off = (g.time * 40) % gs;
  ctx.strokeStyle = c(pal.grid);
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (let x = 0; x <= w; x += gs) {
    ctx.moveTo(x + 0.5, 0);
    ctx.lineTo(x + 0.5, h);
  }
  for (let y = off - gs; y <= h; y += gs) {
    ctx.moveTo(0, y + 0.5);
    ctx.lineTo(w, y + 0.5);
  }
  ctx.stroke();

  for (const s of g.stars) {
    ctx.fillStyle = c(pal.fg, 0.25 + s.z * 0.6);
    const sz = s.z > 0.85 ? 2 : 1;
    ctx.fillRect(s.x * w, s.y * h, sz, sz * (1 + s.z * 3));
  }

  // coins
  ctx.lineWidth = 1.5;
  for (const coin of g.coins) {
    const sx = Math.abs(Math.cos(coin.t * 5)) * 6 + 1;
    ctx.strokeStyle = c(pal.fg, 0.95);
    ctx.fillStyle = c(pal.fg, 0.35);
    ctx.beginPath();
    ctx.moveTo(coin.x, coin.y - 7);
    ctx.lineTo(coin.x + sx, coin.y);
    ctx.lineTo(coin.x, coin.y + 7);
    ctx.lineTo(coin.x - sx, coin.y);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  // power-ups
  ctx.font = '700 13px "Roboto Mono", monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  for (const u of g.powerUps) {
    const pulse = 1 + Math.sin(u.t * 6) * 0.08;
    ctx.shadowColor = c(pal.fg, 0.9);
    ctx.shadowBlur = 14;
    ctx.strokeStyle = c(pal.fg);
    ctx.lineWidth = 1.5;
    polygon(ctx, u.x, u.y, 14 * pulse, 6, Math.PI / 6);
    ctx.stroke();
    polygon(ctx, u.x, u.y, 18 * pulse, 6, Math.PI / 6);
    ctx.strokeStyle = c(pal.fg, 0.35);
    ctx.stroke();
    ctx.shadowBlur = 0;
    ctx.fillStyle = c(pal.fg);
    ctx.fillText(POWER_GLYPH[u.kind], u.x, u.y + 1);
  }

  // enemies
  ctx.shadowColor = c(pal.fg, 0.7);
  ctx.shadowBlur = 10;
  for (const e of g.enemies) drawEnemy(ctx, e, pal);
  ctx.shadowBlur = 0;

  // boss
  const b = g.boss;
  if (b) {
    const size = b.r * 2.6;
    const drawn = drawSprite(ctx, g.bossImages[b.spriteIndex], b.x, b.y, size);
    if (!drawn) {
      ctx.strokeStyle = c(pal.fg);
      ctx.lineWidth = 2;
      polygon(ctx, b.x, b.y, b.r, 8, b.t * 0.3);
      ctx.stroke();
    }
    if (b.flash > 0) {
      ctx.fillStyle = c(pal.fg, 0.18);
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.r * 0.75, 0, Math.PI * 2);
      ctx.fill();
    }
    if (b.phase === 2) {
      ctx.strokeStyle = c(pal.danger, 0.4 + Math.sin(b.t * 10) * 0.2);
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.r * 0.85, 0, Math.PI * 2);
      ctx.stroke();
    }
  }

  // enemy bullets
  for (const eb of g.eBullets) {
    ctx.fillStyle = c(pal.danger, 0.28);
    ctx.beginPath();
    ctx.arc(eb.x, eb.y, eb.r + 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = c(pal.fg);
    ctx.beginPath();
    ctx.arc(eb.x, eb.y, eb.r - 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = c(pal.danger);
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(eb.x, eb.y, eb.r, 0, Math.PI * 2);
    ctx.stroke();
  }

  // player bullets
  for (const pb of g.bullets) {
    if (pb.homing) {
      ctx.fillStyle = c(pal.fg);
      ctx.fillRect(pb.x - 2, pb.y - 2, 4, 4);
      ctx.fillStyle = c(pal.fg, 0.3);
      ctx.fillRect(pb.x - pb.vx * 0.02 - 1, pb.y - pb.vy * 0.02 - 1, 3, 3);
      continue;
    }
    ctx.strokeStyle = c(pal.fg, 0.35);
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(pb.x, pb.y);
    ctx.lineTo(pb.x - pb.vx * 0.018, pb.y - pb.vy * 0.018);
    ctx.stroke();
    ctx.strokeStyle = c(pal.fg);
    ctx.lineWidth = 1.5;
    ctx.stroke();
  }

  // player
  const p = g.player;
  if (p.alive && !(p.invuln > 0 && Math.floor(g.time * 20) % 2 === 0)) {
    // engine trail
    ctx.fillStyle = c(pal.fg, 0.5 + Math.random() * 0.3);
    ctx.fillRect(p.x - 2, p.y + 22, 4, 10 + Math.random() * 10);
    if (!drawSprite(ctx, g.shipImage, p.x, p.y, 84)) {
      ctx.strokeStyle = c(pal.fg);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y - 24);
      ctx.lineTo(p.x + 18, p.y + 18);
      ctx.lineTo(p.x, p.y + 8);
      ctx.lineTo(p.x - 18, p.y + 18);
      ctx.closePath();
      ctx.stroke();
    }
    if (p.shield > 1) {
      const a = Math.min(1, p.shield / Math.max(1, g.stats.maxShield));
      ctx.strokeStyle = c(pal.fg, 0.12 + a * 0.3);
      ctx.lineWidth = 1.5;
      polygon(ctx, p.x, p.y, 38, 6, g.time * 0.6);
      ctx.stroke();
    }
    ctx.fillStyle = c(pal.fg);
    ctx.beginPath();
    ctx.arc(p.x, p.y, 3, 0, Math.PI * 2);
    ctx.fill();
  }

  // particles
  for (const pt of g.particles) {
    const a = pt.life / pt.maxLife;
    const tok = pt.danger ? pal.danger : pal.fg;
    if (pt.kind === 'shock') {
      const rr = pt.size * (1 - a * a * 0.85);
      ctx.fillStyle = c(pal.fg, a * 0.08);
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, rr, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = c(pal.fg, a * 0.9);
      ctx.lineWidth = 3 * a + 1;
      ctx.stroke();
      ctx.strokeStyle = c(pal.fg, a * 0.35);
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, rr * 0.82, 0, Math.PI * 2);
      ctx.stroke();
    } else if (pt.kind === 'ring') {
      ctx.strokeStyle = c(tok, a * 0.8);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, pt.size * (1.4 - a), 0, Math.PI * 2);
      ctx.stroke();
    } else if (pt.kind === 'debris') {
      ctx.strokeStyle = c(tok, a);
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(pt.x, pt.y);
      ctx.lineTo(pt.x - pt.vx * 0.04, pt.y - pt.vy * 0.04);
      ctx.stroke();
    } else {
      ctx.fillStyle = c(tok, a);
      ctx.fillRect(pt.x - pt.size / 2, pt.y - pt.size / 2, pt.size, pt.size);
    }
  }
  ctx.restore();

  if (g.hitFlash > 0) {
    ctx.fillStyle = c(pal.danger, g.hitFlash * 0.5);
    ctx.fillRect(0, 0, w, h);
  }
  if (g.whiteFlash > 0 && !reducedMotion) {
    ctx.fillStyle = c(pal.fg, Math.min(0.75, g.whiteFlash * 1.2));
    ctx.fillRect(0, 0, w, h);
  }
  // vignette
  const grad = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.3, w / 2, h / 2, Math.max(w, h) * 0.75);
  grad.addColorStop(0, c(pal.bg, 0));
  grad.addColorStop(1, c(pal.bg, 0.7));
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);
}
