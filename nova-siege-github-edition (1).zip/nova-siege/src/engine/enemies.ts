import type { Game } from '@generated/engine/Game';
import type { Enemy, EnemyKind } from '@generated/engine/types';

let nextId = 1;

const BASE: Record<EnemyKind, { hp: number; r: number; speed: number; value: number; fire: number }> = {
  scout: { hp: 20, r: 14, speed: 115, value: 2, fire: 0 },
  zigzag: { hp: 32, r: 15, speed: 90, value: 3, fire: 0 },
  shooter: { hp: 48, r: 17, speed: 85, value: 5, fire: 1.9 },
  tank: { hp: 130, r: 24, speed: 45, value: 9, fire: 2.6 },
  diver: { hp: 36, r: 14, speed: 75, value: 6, fire: 0 },
};

export function buildWave(wave: number): EnemyKind[] {
  const count = Math.min(10 + wave * 2, 54);
  const list: EnemyKind[] = [];
  for (let i = 0; i < count; i++) {
    const r = Math.random();
    let k: EnemyKind = 'scout';
    if (wave >= 2 && r < 0.25) k = 'zigzag';
    else if (wave >= 3 && r < 0.42) k = 'shooter';
    else if (wave >= 4 && r < 0.52) k = 'tank';
    else if (wave >= 6 && r < 0.64) k = 'diver';
    list.push(k);
  }
  return list;
}

export function spawnEnemy(g: Game, kind: EnemyKind, at?: { x: number; y: number }) {
  const b = BASE[kind];
  const hp = b.hp * g.hpMult();
  const x = at?.x ?? 40 + Math.random() * Math.max(40, g.w - 80);
  const enemy: Enemy = {
    id: nextId++,
    kind,
    x,
    y: at?.y ?? -40,
    vx: 0,
    vy: b.speed * g.speedMult(),
    r: b.r,
    hp,
    maxHp: hp,
    t: Math.random() * 10,
    fireCd: 0.8 + Math.random() * 1.8,
    value: Math.ceil(b.value * (1 + g.wave * 0.12)),
    flash: 0,
    baseX: x,
    targetY: 70 + Math.random() * g.h * 0.32,
    diving: false,
  };
  g.enemies.push(enemy);
}

export function updateEnemy(g: Game, e: Enemy, dt: number) {
  e.t += dt;
  e.flash = Math.max(0, e.flash - dt);
  const p = g.player;
  switch (e.kind) {
    case 'scout':
      e.y += e.vy * dt;
      e.x = e.baseX + Math.sin(e.t * 2) * 30;
      break;
    case 'zigzag':
      e.y += e.vy * dt;
      e.x = Math.max(20, Math.min(g.w - 20, e.baseX + Math.sin(e.t * 3.2) * 110));
      break;
    case 'tank':
      e.y += e.vy * dt;
      break;
    case 'shooter':
      if (e.t > 12) e.y += 140 * dt;
      else if (e.y < e.targetY) e.y += e.vy * dt * 1.6;
      else e.x = Math.max(20, Math.min(g.w - 20, e.baseX + Math.sin(e.t * 1.2) * 70));
      break;
    case 'diver':
      if (!e.diving) {
        e.y += e.vy * dt;
        if (e.y > g.h * 0.18) {
          e.diving = true;
          const dx = p.x - e.x;
          const dy = p.y - e.y;
          const d = Math.hypot(dx, dy) || 1;
          const sp = 330 * g.speedMult();
          e.vx = (dx / d) * sp;
          e.vy = (dy / d) * sp;
        }
      } else {
        e.x += e.vx * dt;
        e.y += e.vy * dt;
      }
      break;
  }

  const fire = BASE[e.kind].fire;
  if (fire > 0) {
    e.fireCd -= dt;
    if (e.fireCd <= 0 && e.y > 10 && e.y < g.h * 0.7 && p.alive) {
      e.fireCd = fire / g.fireMult();
      const sp = (170 + g.wave * 6) * Math.min(1.6, g.speedMult());
      if (e.kind === 'tank') {
        for (let i = -1; i <= 1; i++) g.enemyShootAt(e.x, e.y + e.r, sp * 0.8, i * 0.28);
      } else {
        g.enemyShootAt(e.x, e.y + e.r, sp, 0);
      }
    }
  }
}

export function isOffscreen(g: Game, e: Enemy): boolean {
  return e.y > g.h + 60 || e.x < -80 || e.x > g.w + 80 || e.y < -200;
}
