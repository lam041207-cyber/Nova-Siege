import type { Game } from '@generated/engine/Game';
import type { Bullet, Coin, EnemyBullet, Particle, PowerUp } from '@generated/engine/types';

export function updateBullets(g: Game, dt: number) {
  const keep: Bullet[] = [];
  let hitSound = false;
  for (const b of g.bullets) {
    if (b.homing) {
      const t = g.nearestTarget(b.x, b.y);
      if (t) {
        const a = Math.atan2(t.y - b.y, t.x - b.x);
        b.vx += Math.cos(a) * 1500 * dt;
        b.vy += Math.sin(a) * 1500 * dt;
      }
      const sp = Math.hypot(b.vx, b.vy);
      if (sp > 560) {
        b.vx = (b.vx / sp) * 560;
        b.vy = (b.vy / sp) * 560;
      }
    }
    b.x += b.vx * dt;
    b.y += b.vy * dt;
    b.life -= dt;
    let alive = b.life > 0 && b.y > -30 && b.x > -30 && b.x < g.w + 30 && b.y < g.h + 30;
    for (const e of g.enemies) {
      if (!alive) break;
      if (e.hp <= 0 || b.hits.includes(e.id)) continue;
      if (Math.hypot(e.x - b.x, e.y - b.y) < e.r + 4) {
        const { dmg, crit } = g.rollDamage(b.dmg);
        e.hp -= dmg;
        e.flash = 0.08;
        b.hits.push(e.id);
        hitSound = true;
        if (crit) g.particles.push({ x: b.x, y: b.y, vx: 0, vy: 0, life: 0.25, maxLife: 0.25, size: 16, kind: 'ring' });
        if (e.hp <= 0) g.killEnemy(e);
        if (b.pierce > 0) b.pierce--;
        else alive = false;
      }
    }
    const boss = g.boss;
    if (alive && boss && !boss.entering && Math.hypot(boss.x - b.x, boss.y - b.y) < boss.r * 0.72) {
      const { dmg } = g.rollDamage(b.dmg);
      alive = false;
      hitSound = true;
      if (Math.random() < 0.3) g.particles.push({ x: b.x, y: b.y, vx: (Math.random() - 0.5) * 120, vy: -60, life: 0.25, maxLife: 0.25, size: 2, kind: 'spark' });
      g.damageBoss(boss, dmg);
    }
    if (alive) keep.push(b);
  }
  g.bullets = keep;
  g.enemies = g.enemies.filter((e) => e.hp > 0);
  if (hitSound) g.onEvent('hit');

  const p = g.player;
  const eb: EnemyBullet[] = [];
  for (const b of g.eBullets) {
    b.x += b.vx * dt;
    b.y += b.vy * dt;
    if (p.alive && Math.hypot(p.x - b.x, p.y - b.y) < b.r + 9) {
      g.damagePlayer(12 + g.wave * 1.2);
      g.burst(b.x, b.y, 6, 120, true);
      continue;
    }
    if (b.y > -20 && b.y < g.h + 20 && b.x > -20 && b.x < g.w + 20) eb.push(b);
  }
  g.eBullets = eb;

  if (p.alive) {
    for (const e of g.enemies) {
      if (Math.hypot(e.x - p.x, e.y - p.y) < e.r + 15) {
        g.damagePlayer(e.kind === 'tank' ? 40 : 25);
        e.hp -= 80;
        e.flash = 0.1;
        if (e.hp <= 0) g.killEnemy(e);
      }
    }
    g.enemies = g.enemies.filter((e) => e.hp > 0);
    const boss = g.boss;
    if (boss && Math.hypot(boss.x - p.x, boss.y - p.y) < boss.r * 0.6 + 12) g.damagePlayer(35);
  }
}

/** Chain-reaction explosions from destroyed enemies. */
export function updateBlasts(g: Game, dt: number) {
  if (!g.blasts.length) return;
  const pending = g.blasts;
  g.blasts = [];
  let fired = 0;
  for (const bl of pending) {
    bl.delay -= dt;
    if (bl.delay > 0) {
      g.blasts.push(bl);
      continue;
    }
    fired++;
    g.shock(bl.x, bl.y, bl.r, 0.35);
    for (const e of g.enemies) {
      if (e.hp <= 0) continue;
      if (Math.hypot(e.x - bl.x, e.y - bl.y) < bl.r + e.r) {
        e.hp -= bl.dmg;
        e.flash = 0.1;
        if (e.hp <= 0) g.killEnemy(e);
      }
    }
    const boss = g.boss;
    if (boss && !boss.entering && Math.hypot(boss.x - bl.x, boss.y - bl.y) < bl.r + boss.r * 0.6) g.damageBoss(boss, bl.dmg * 0.5);
  }
  g.enemies = g.enemies.filter((e) => e.hp > 0);
  if (fired) g.onEvent('chain');
}

export function updatePickups(g: Game, dt: number) {
  const p = g.player;
  const vacuum = g.waveState === 'clear' || g.powers.magnet > 0;
  const radius = g.powers.magnet > 0 ? 9999 : g.stats.magnet;
  const coins: Coin[] = [];
  let picked = false;
  for (const c of g.coins) {
    c.t += dt;
    const dx = p.x - c.x;
    const dy = p.y - c.y;
    const d = Math.hypot(dx, dy) || 1;
    if (p.alive && (vacuum || d < radius) && c.t > 0.25) {
      c.vx += (dx / d) * 1400 * dt;
      c.vy += (dy / d) * 1400 * dt;
      c.vx *= 0.92;
      c.vy *= 0.92;
    } else {
      c.vx *= 0.96;
      c.vy = c.vy * 0.96 + 60 * dt;
    }
    c.x += c.vx * dt;
    c.y += c.vy * dt;
    if (p.alive && d < 22) {
      g.coinsEarned += c.value * g.stats.coinMult;
      picked = true;
      continue;
    }
    if (c.y < g.h + 20) coins.push(c);
  }
  g.coins = coins;
  if (picked) g.onEvent('coin');

  const ups: PowerUp[] = [];
  for (const u of g.powerUps) {
    u.t += dt;
    u.y += u.vy * dt;
    if (p.alive && Math.hypot(p.x - u.x, p.y - u.y) < 30) {
      g.applyPower(u.kind);
      continue;
    }
    if (u.y < g.h + 30) ups.push(u);
  }
  g.powerUps = ups;
}

export function updateParticles(g: Game, dt: number) {
  for (const s of g.stars) {
    s.y += (s.z * 60 * dt) / Math.max(1, g.h);
    if (s.y > 1) {
      s.y = 0;
      s.x = Math.random();
    }
  }
  const next: Particle[] = [];
  for (const pt of g.particles) {
    pt.life -= dt;
    if (pt.life <= 0) continue;
    pt.x += pt.vx * dt;
    pt.y += pt.vy * dt;
    pt.vx *= 0.94;
    pt.vy *= 0.94;
    next.push(pt);
  }
  g.particles = next.length > 900 ? next.slice(-900) : next;
}
