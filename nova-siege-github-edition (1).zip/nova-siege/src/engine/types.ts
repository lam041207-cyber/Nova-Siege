import type { RunPerkDef } from '@generated/data/config';

export type EnemyKind = 'scout' | 'zigzag' | 'tank' | 'shooter' | 'diver';

export interface Enemy {
  id: number;
  kind: EnemyKind;
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  hp: number;
  maxHp: number;
  t: number;
  fireCd: number;
  value: number;
  flash: number;
  baseX: number;
  targetY: number;
  diving: boolean;
}

export interface Bullet {
  x: number;
  y: number;
  vx: number;
  vy: number;
  dmg: number;
  pierce: number;
  homing: boolean;
  life: number;
  hits: number[];
}

export interface EnemyBullet {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
}

export type PowerKind = 'rapid' | 'triple' | 'shield' | 'magnet' | 'repair';

export interface PowerUp {
  x: number;
  y: number;
  vy: number;
  kind: PowerKind;
  t: number;
}

export interface Coin {
  x: number;
  y: number;
  vx: number;
  vy: number;
  value: number;
  t: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  kind: 'spark' | 'ring' | 'debris' | 'shock';
  danger?: boolean;
}

export interface Blast {
  x: number;
  y: number;
  r: number;
  dmg: number;
  delay: number;
}

export interface Boss {
  x: number;
  y: number;
  r: number;
  hp: number;
  maxHp: number;
  t: number;
  phase: 1 | 2;
  pattern: number;
  patternT: number;
  fireT: number;
  spriteIndex: number;
  cycle: number;
  spiral: number;
  entering: boolean;
  flash: number;
  minionsSpawned: boolean;
}

export interface Banner {
  title: string;
  sub: string;
  danger?: boolean;
}

export type GameEvent =
  | 'shoot'
  | 'hit'
  | 'explode'
  | 'bigExplode'
  | 'chain'
  | 'coin'
  | 'power'
  | 'playerHit'
  | 'shieldHit'
  | 'bossWarn'
  | 'bossSpawn'
  | 'bossDown'
  | 'bomb'
  | 'waveStart'
  | 'perkOffer'
  | 'perkPick'
  | 'revive'
  | 'death'
  | 'crit';

export interface HudSnapshot {
  hp: number;
  maxHp: number;
  shield: number;
  maxShield: number;
  wave: number;
  coins: number;
  kills: number;
  bombs: number;
  revives: number;
  boss: { hp: number; maxHp: number; name: string; phase: 1 | 2 } | null;
  powers: { kind: PowerKind; remaining: number; total: number }[];
  banner: Banner | null;
  perkOffer: RunPerkDef[] | null;
  runPerks: string[];
}

export interface RunSummary {
  wave: number;
  kills: number;
  coins: number;
  crystals: number;
  bosses: number;
  xp: number;
  durationSec: number;
}
