import type { Game } from '@generated/engine/Game';
import type { Boss } from '@generated/engine/types';
import { spawnEnemy } from '@generated/engine/enemies';

export function spawnBoss(g: Game) {
  const cycle = Math.max(1, Math.floor(g.wave / 5));
  const hp = 1500 * (1 + (cycle - 1) * 0.95);
  const boss: Boss = {
    x: g.w / 2,
    y: -180,
    r: Math.min(105, Math.max(70, g.w * 0.2)),
    hp,
    maxHp: hp,
    t: 0,
    phase: 1,
    pattern: 0,
    patternT: 0,
    fireT: 1,
    spriteIndex: (cycle - 1) % 3,
    cycle,
    spiral: 0,
    entering: true,
    flash: 0,
    minionsSpawned: false,
  };
  g.boss = boss;
}

export function updateBoss(g: Game, b: Boss, dt: number) {
  b.t += dt;
  b.flash = Math.max(0, b.flash - dt);
  const homeY = g.h * 0.2;
  if (b.entering) {
    b.y += 110 * dt;
    if (b.y >= homeY) b.entering = false;
    return;
  }
  b.x = g.w / 2 + Math.sin(b.t * 0.55) * g.w * 0.28;
  b.y = homeY + Math.sin(b.t * 1.1) * 18;

  if (b.phase === 1 && b.hp < b.maxHp * 0.5) {
    b.phase = 2;
    g.showBanner({ title: 'PHASE 2', sub: 'CORE OVERLOAD // EVADE', danger: true }, 1.6);
    g.shake = 14;
  }

  b.patternT += dt;
  if (b.patternT > 4.2) {
    b.patternT = 0;
    b.pattern = (b.pattern + 1) % 4;
    b.minionsSpawned = false;
    b.fireT = 0.4;
  }

  const p2 = b.phase === 2;
  const rate = p2 ? 0.7 : 1;
  const sp = 150 + b.cycle * 14 + (p2 ? 30 : 0);
  b.fireT -= dt;
  if (b.fireT > 0) return;

  switch (b.pattern) {
    case 0: {
      const n = 14 + b.cycle * 2 + (p2 ? 6 : 0);
      const off = b.t * 0.7;
      for (let i = 0; i < n; i++) g.enemyShootDir(b.x, b.y, off + (i / n) * Math.PI * 2, sp * 0.85);
      b.fireT = 1.15 * rate;
      break;
    }
    case 1: {
      const n = p2 ? 7 : 5;
      for (let i = 0; i < n; i++) g.enemyShootAt(b.x, b.y + b.r * 0.6, sp * 1.15, (i - (n - 1) / 2) * 0.16);
      b.fireT = 0.6 * rate;
      break;
    }
    case 2: {
      b.spiral += 0.32;
      const arms = p2 ? 4 : 3;
      for (let i = 0; i < arms; i++) g.enemyShootDir(b.x, b.y, b.spiral + (i / arms) * Math.PI * 2, sp * 0.75);
      b.fireT = 0.11 * rate;
      break;
    }
    default: {
      if (!b.minionsSpawned) {
        b.minionsSpawned = true;
        const n = 3 + Math.min(4, b.cycle);
        for (let i = 0; i < n; i++) {
          spawnEnemy(g, i % 2 ? 'diver' : 'scout', { x: b.x + (i - (n - 1) / 2) * 40, y: b.y + 20 });
        }
      }
      g.enemyShootAt(b.x, b.y + b.r * 0.6, sp, 0);
      b.fireT = 0.9 * rate;
    }
  }
}
