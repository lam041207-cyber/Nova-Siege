import { BOSS_NAMES, RUN_PERKS, type PlayerStats, type RunPerkDef, type RunPerkId } from '@generated/data/config';
import { buildWave, isOffscreen, spawnEnemy, updateEnemy } from '@generated/engine/enemies';
import { spawnBoss, updateBoss } from '@generated/engine/boss';
import { updateBullets, updateBlasts, updatePickups, updateParticles } from '@generated/engine/physics';
import type {
  Banner, Blast, Boss, Bullet, Coin, Enemy, EnemyBullet, EnemyKind, GameEvent, HudSnapshot, Particle, PowerKind, PowerUp, RunSummary,
} from '@generated/engine/types';

export const POWER_DURATION: Record<PowerKind, number> = { rapid: 8, triple: 8, magnet: 10, shield: 0, repair: 0 };
export const POWER_KINDS: PowerKind[] = ['rapid', 'triple', 'shield', 'magnet', 'repair'];

export interface GameOptions {
  stats: PlayerStats;
  shipImage: HTMLImageElement | null;
  bossImages: HTMLImageElement[];
  onOver: (s: RunSummary) => void;
  onEvent?: (e: GameEvent) => void;
}

export class Game {
  w = 360;
  h = 640;
  stats: PlayerStats;
  shipImage: HTMLImageElement | null;
  bossImages: HTMLImageElement[];
  onOver: (s: RunSummary) => void;
  onEvent: (e: GameEvent) => void;

  player = { x: 180, y: 560, tx: 180, ty: 560, hp: 100, shield: 20, invuln: 0, lastHit: -10, fireCd: 0, missileCd: 0, novaCd: 2, alive: true };
  enemies: Enemy[] = [];
  bullets: Bullet[] = [];
  eBullets: EnemyBullet[] = [];
  powerUps: PowerUp[] = [];
  coins: Coin[] = [];
  particles: Particle[] = [];
  blasts: Blast[] = [];
  stars: { x: number; y: number; z: number }[] = [];
  boss: Boss | null = null;

  wave = 0;
  waveState: 'intro' | 'fight' | 'bossIntro' | 'boss' | 'clear' = 'intro';
  stateT = 0;
  spawnQueue: EnemyKind[] = [];
  spawnT = 0;
  kills = 0;
  coinsEarned = 0;
  crystalsEarned = 0;
  bossesKilled = 0;
  time = 0;
  powers: Record<PowerKind, number> = { rapid: 0, triple: 0, shield: 0, magnet: 0, repair: 0 };
  bombs = 1;
  revives = 0;
  runPerks: RunPerkId[] = [];
  perkOffer: RunPerkDef[] | null = null;
  perkDelay = -1;
  shake = 0;
  hitFlash = 0;
  whiteFlash = 0;
  banner: Banner | null = null;
  bannerT = 0;
  overT = -1;
  finished = false;
  paused = false;

  constructor(o: GameOptions) {
    this.stats = { ...o.stats };
    this.shipImage = o.shipImage;
    this.bossImages = o.bossImages;
    this.onOver = o.onOver;
    this.onEvent = o.onEvent ?? (() => {});
    this.player.hp = o.stats.maxHp;
    this.player.shield = o.stats.maxShield;
    this.bombs = o.stats.bombs;
    this.revives = o.stats.revives;
    for (let i = 0; i < 90; i++) this.stars.push({ x: Math.random(), y: Math.random(), z: 0.2 + Math.random() * 0.8 });
    this.startWave(1);
  }

  resize(w: number, h: number) {
    const first = this.w === 360 && this.h === 640;
    this.w = w;
    this.h = h;
    if (first) {
      this.player.x = this.player.tx = w / 2;
      this.player.y = this.player.ty = h * 0.82;
    }
  }

  setTarget(x: number, y: number) {
    this.player.tx = Math.max(16, Math.min(this.w - 16, x));
    this.player.ty = Math.max(40, Math.min(this.h - 20, y));
  }

  hpMult = () => 1 + (this.wave - 1) * 0.2;
  speedMult = () => Math.min(1.7, 1 + (this.wave - 1) * 0.035);
  fireMult = () => Math.min(2.2, 1 + (this.wave - 1) * 0.06);
  get frozen() {
    return this.paused || this.finished || (this.perkOffer !== null && this.perkDelay <= 0);
  }

  showBanner(b: Banner, dur: number) {
    this.banner = b;
    this.bannerT = dur;
  }

  startWave(n: number) {
    this.wave = n;
    if (n % 5 === 0) {
      this.waveState = 'bossIntro';
      this.stateT = 2.6;
      this.showBanner({ title: 'WARNING', sub: `BOSS INBOUND // WAVE ${n}`, danger: true }, 2.6);
      this.onEvent('bossWarn');
    } else {
      this.waveState = 'intro';
      this.stateT = 1.6;
      this.spawnQueue = buildWave(n);
      this.spawnT = 0;
      this.showBanner({ title: `WAVE ${String(n).padStart(2, '0')}`, sub: `${this.spawnQueue.length} HOSTILES // ENGAGE` }, 1.6);
      this.onEvent('waveStart');
    }
  }

  enemyShootDir(x: number, y: number, angle: number, speed: number) {
    this.eBullets.push({ x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, r: 5 });
  }

  enemyShootAt(x: number, y: number, speed: number, spread: number) {
    this.enemyShootDir(x, y, Math.atan2(this.player.y - y, this.player.x - x) + spread, speed);
  }

  burst(x: number, y: number, n: number, power: number, danger = false) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = (0.3 + Math.random()) * power;
      const life = 0.35 + Math.random() * 0.5;
      this.particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life, maxLife: life, size: 1 + Math.random() * 2.5, kind: i % 6 === 0 ? 'debris' : 'spark', danger });
    }
    this.particles.push({ x, y, vx: 0, vy: 0, life: 0.45, maxLife: 0.45, size: power * 0.12, kind: 'ring' });
  }

  shock(x: number, y: number, size: number, life = 0.5) {
    this.particles.push({ x, y, vx: 0, vy: 0, life, maxLife: life, size, kind: 'shock' });
  }

  dropCoins(x: number, y: number, value: number, pieces: number) {
    const per = Math.max(1, Math.round(value / pieces));
    for (let i = 0; i < pieces; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = 40 + Math.random() * 120;
      this.coins.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 40, value: per, t: Math.random() * 6 });
    }
  }

  rollDamage(base: number): { dmg: number; crit: boolean } {
    const crit = Math.random() < this.stats.crit;
    return { dmg: base * (crit ? 2.5 : 1), crit };
  }

  killEnemy(e: Enemy) {
    this.kills++;
    const big = e.kind === 'tank';
    this.burst(e.x, e.y, big ? 26 : 14, big ? 260 : 180);
    this.dropCoins(e.x, e.y, e.value, big ? 4 : 1 + Math.floor(Math.random() * 2));
    const chance = (big ? 0.22 : 0.055) * this.stats.dropMult;
    if (Math.random() < chance) {
      const kind = POWER_KINDS[Math.floor(Math.random() * POWER_KINDS.length)] ?? 'rapid';
      this.powerUps.push({ x: e.x, y: e.y, vy: 70, kind, t: 0 });
    }
    if (this.stats.siphon > 0 && this.player.alive) this.player.hp = Math.min(this.stats.maxHp, this.player.hp + this.stats.siphon);
    if (this.stats.chain > 0) {
      const lvl = this.stats.chain;
      this.blasts.push({ x: e.x, y: e.y, r: 50 + lvl * 18, dmg: this.stats.damage * (1.2 + lvl * 0.4), delay: 0.07 });
    }
    if (big) this.shake = Math.max(this.shake, 6);
    this.onEvent(big ? 'bigExplode' : 'explode');
  }

  damageBoss(b: Boss, amount: number) {
    b.hp -= amount * this.stats.bossMult;
    b.flash = 0.06;
    if (b.hp <= 0) this.killBoss(b);
  }

  killBoss(b: Boss) {
    this.bossesKilled++;
    this.boss = null;
    for (let i = 0; i < 6; i++) this.burst(b.x + (Math.random() - 0.5) * b.r * 1.6, b.y + (Math.random() - 0.5) * b.r, 30, 360);
    this.shock(b.x, b.y, Math.max(this.w, this.h) * 0.6, 0.9);
    this.dropCoins(b.x, b.y, 220 * b.cycle, 26);
    this.crystalsEarned += 15 * b.cycle;
    this.powerUps.push({ x: b.x - 30, y: b.y, vy: 60, kind: 'repair', t: 0 });
    this.powerUps.push({ x: b.x + 30, y: b.y, vy: 60, kind: POWER_KINDS[Math.floor(Math.random() * 3)] ?? 'rapid', t: 0 });
    this.eBullets = [];
    this.shake = 24;
    this.whiteFlash = 0.5;
    this.waveState = 'clear';
    this.stateT = 3;
    this.showBanner({ title: 'BOSS DOWN', sub: `+${15 * b.cycle} CRYSTALS // ${BOSS_NAMES[b.spriteIndex] ?? 'TARGET'}` }, 2.4);
    this.onEvent('bossDown');
    const pool = [...RUN_PERKS].sort(() => Math.random() - 0.5);
    this.perkOffer = pool.slice(0, 3);
    this.perkDelay = 1.6;
  }

  choosePerk(id: RunPerkId) {
    if (!this.perkOffer) return;
    const s = this.stats;
    switch (id) {
      case 'overcharge': s.damage *= 1.25; break;
      case 'hyper': s.fireRate *= 1.2; break;
      case 'spread': s.streams += 1; break;
      case 'nanites': s.maxHp += 25; this.player.hp = s.maxHp; break;
      case 'munitions': this.bombs += 2; break;
      case 'chain': s.chain += 1; break;
      case 'crit': s.crit += 0.1; break;
      case 'siphon': s.siphon += 1; break;
      case 'greed': s.coinMult *= 1.3; s.magnet += 60; break;
    }
    this.runPerks.push(id);
    this.perkOffer = null;
    this.onEvent('perkPick');
  }

  useBomb() {
    const p = this.player;
    if (this.bombs <= 0 || !p.alive || this.frozen) return;
    this.bombs--;
    for (const b of this.eBullets.slice(0, 40)) this.particles.push({ x: b.x, y: b.y, vx: 0, vy: -30, life: 0.3, maxLife: 0.3, size: 3, kind: 'spark' });
    this.eBullets = [];
    const dmg = 220 * this.hpMult();
    for (const e of this.enemies) {
      e.hp -= dmg;
      e.flash = 0.15;
      if (e.hp <= 0) this.killEnemy(e);
    }
    this.enemies = this.enemies.filter((e) => e.hp > 0);
    if (this.boss && !this.boss.entering) this.damageBoss(this.boss, this.boss.maxHp * 0.06);
    this.shock(p.x, p.y, Math.max(this.w, this.h) * 1.1, 0.8);
    this.shock(p.x, p.y, Math.max(this.w, this.h) * 0.6, 0.6);
    p.invuln = Math.max(p.invuln, 1);
    this.shake = 30;
    this.whiteFlash = 0.45;
    this.onEvent('bomb');
  }

  damagePlayer(amount: number) {
    const p = this.player;
    if (p.invuln > 0 || !p.alive) return;
    p.lastHit = this.time;
    p.invuln = 0.7;
    this.shake = Math.max(this.shake, 9);
    this.hitFlash = 0.25;
    const absorbed = Math.min(p.shield, amount);
    p.shield -= absorbed;
    p.hp -= amount - absorbed;
    this.onEvent(amount - absorbed > 0 ? 'playerHit' : 'shieldHit');
    if (p.hp > 0) return;
    if (this.revives > 0) {
      this.revives--;
      p.hp = this.stats.maxHp * 0.5;
      p.shield = this.stats.maxShield;
      p.invuln = 2.5;
      this.eBullets = [];
      this.shock(p.x, p.y, Math.max(this.w, this.h) * 0.8, 0.9);
      this.whiteFlash = 0.6;
      this.showBanner({ title: 'PHOENIX', sub: 'HULL RESTORED // FIGHT ON' }, 1.8);
      this.onEvent('revive');
      return;
    }
    p.hp = 0;
    p.alive = false;
    this.burst(p.x, p.y, 60, 380);
    this.shock(p.x, p.y, 260, 0.8);
    this.shake = 26;
    this.overT = 1.6;
    this.onEvent('death');
  }

  applyPower(kind: PowerKind) {
    const p = this.player;
    if (kind === 'shield') p.shield = this.stats.maxShield;
    else if (kind === 'repair') p.hp = Math.min(this.stats.maxHp, p.hp + this.stats.maxHp * 0.35);
    else this.powers[kind] = POWER_DURATION[kind];
    this.particles.push({ x: p.x, y: p.y, vx: 0, vy: 0, life: 0.5, maxLife: 0.5, size: 50, kind: 'ring' });
    this.onEvent('power');
  }

  summary(): RunSummary {
    return {
      wave: this.wave,
      kills: this.kills,
      coins: Math.round(this.coinsEarned),
      crystals: this.crystalsEarned,
      bosses: this.bossesKilled,
      xp: this.wave * 25 + this.kills * 2 + this.bossesKilled * 150,
      durationSec: Math.round(this.time),
    };
  }

  abandon() {
    if (this.finished) return;
    this.finished = true;
    this.onOver(this.summary());
  }

  snapshot(): HudSnapshot {
    const b = this.boss;
    return {
      hp: this.player.hp,
      maxHp: this.stats.maxHp,
      shield: this.player.shield,
      maxShield: this.stats.maxShield,
      wave: this.wave,
      coins: Math.round(this.coinsEarned),
      kills: this.kills,
      bombs: this.bombs,
      revives: this.revives,
      boss: b ? { hp: b.hp, maxHp: b.maxHp, name: BOSS_NAMES[b.spriteIndex] ?? 'BOSS', phase: b.phase } : null,
      powers: (['rapid', 'triple', 'magnet'] as PowerKind[])
        .filter((k) => this.powers[k] > 0)
        .map((k) => ({ kind: k, remaining: this.powers[k], total: POWER_DURATION[k] })),
      banner: this.bannerT > 0 ? this.banner : null,
      perkOffer: this.perkOffer && this.perkDelay <= 0 ? this.perkOffer : null,
      runPerks: this.runPerks,
    };
  }

  update(dt: number) {
    if (this.perkOffer && this.perkDelay > 0) {
      this.perkDelay -= dt;
      if (this.perkDelay <= 0) this.onEvent('perkOffer');
    }
    if (this.frozen) return;
    this.time += dt;
    this.shake = Math.max(0, this.shake - dt * 40);
    this.hitFlash = Math.max(0, this.hitFlash - dt);
    this.whiteFlash = Math.max(0, this.whiteFlash - dt);
    this.bannerT = Math.max(0, this.bannerT - dt);
    for (const k of POWER_KINDS) this.powers[k] = Math.max(0, this.powers[k] - dt);
    this.updatePlayer(dt);
    this.updateWaves(dt);
    for (const e of this.enemies) updateEnemy(this, e, dt);
    this.enemies = this.enemies.filter((e) => !isOffscreen(this, e));
    if (this.boss) updateBoss(this, this.boss, dt);
    updateBullets(this, dt);
    updateBlasts(this, dt);
    updatePickups(this, dt);
    updateParticles(this, dt);
    if (this.overT >= 0) {
      this.overT -= dt;
      if (this.overT < 0) this.abandon();
    }
  }

  private shoot(x: number, y: number, angle: number, speed: number, dmg: number, pierce: number, homing: boolean, life = 1.5) {
    this.bullets.push({ x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, dmg, pierce, homing, life, hits: [] });
  }

  private updatePlayer(dt: number) {
    const p = this.player;
    const s = this.stats;
    if (!p.alive) return;
    const k = Math.min(1, dt * 11 * s.agility);
    p.x += (p.tx - p.x) * k;
    p.y += (p.ty - p.y) * k;
    p.invuln = Math.max(0, p.invuln - dt);
    if (this.time - p.lastHit > 3) p.shield = Math.min(s.maxShield, p.shield + s.maxShield * s.shieldRegen * dt);

    p.fireCd -= dt;
    if (p.fireCd <= 0) {
      p.fireCd = 1 / (s.fireRate * (this.powers.rapid > 0 ? 1.8 : 1));
      const lanes = s.streams + (this.powers.triple > 0 ? 2 : 0);
      const pierce = s.special === 'pierce' || s.special === 'seraph' ? 2 : 0;
      for (let i = 0; i < lanes; i++) {
        const off = i - (lanes - 1) / 2;
        this.shoot(p.x + off * 7, p.y - 26, -Math.PI / 2 + off * 0.075, 860, s.damage, pierce, false);
      }
      if (s.special === 'sideguns') {
        for (const d of [-1, 1]) this.shoot(p.x + d * 22, p.y - 6, -Math.PI / 2 + d * 0.32, 760, s.damage * 0.8, 0, false);
      }
      this.onEvent('shoot');
    }
    if (s.special === 'missiles' || s.special === 'seraph') {
      p.missileCd -= dt;
      if (p.missileCd <= 0) {
        p.missileCd = s.special === 'seraph' ? 0.7 : 0.85;
        for (const d of [-1, 1]) this.bullets.push({ x: p.x + d * 20, y: p.y, vx: d * 160, vy: -260, dmg: s.damage * 1.6, pierce: 0, homing: true, life: 3, hits: [] });
      }
    }
    if (s.special === 'nova') {
      p.novaCd -= dt;
      if (p.novaCd <= 0) {
        p.novaCd = 2;
        const n = 18;
        for (let i = 0; i < n; i++) this.shoot(p.x, p.y, (i / n) * Math.PI * 2 + this.time, 520, s.damage * 0.9, 1, false, 1.1);
        this.shock(p.x, p.y, 90, 0.4);
      }
    }
  }

  private updateWaves(dt: number) {
    this.stateT -= dt;
    switch (this.waveState) {
      case 'intro':
        if (this.stateT <= 0) this.waveState = 'fight';
        break;
      case 'bossIntro':
        if (this.stateT <= 0) {
          spawnBoss(this);
          this.waveState = 'boss';
          this.onEvent('bossSpawn');
        }
        break;
      case 'fight':
        this.spawnT -= dt;
        if (this.spawnT <= 0 && this.spawnQueue.length) {
          const k = this.spawnQueue.shift();
          if (k) spawnEnemy(this, k);
          this.spawnT = Math.max(0.22, 0.85 - this.wave * 0.03);
        }
        if (!this.spawnQueue.length && !this.enemies.length) {
          this.waveState = 'clear';
          this.stateT = 1.2;
        }
        break;
      case 'clear':
        if (this.stateT <= 0 && this.player.alive && !this.perkOffer) this.startWave(this.wave + 1);
        break;
      default:
        break;
    }
  }

  nearestTarget(x: number, y: number): { x: number; y: number } | null {
    let best: { x: number; y: number } | null = this.boss && !this.boss.entering ? this.boss : null;
    let bd = best ? Math.hypot(best.x - x, best.y - y) : Infinity;
    for (const e of this.enemies) {
      const d = Math.hypot(e.x - x, e.y - y);
      if (d < bd && e.y > 0) {
        bd = d;
        best = e;
      }
    }
    return best;
  }
}
