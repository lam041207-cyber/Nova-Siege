import { useCallback, useEffect, useState } from 'react';
import type { Screen } from '@generated/data/screens';
import type { RunSummary } from '@generated/engine/types';
import type { TrackId } from '@generated/audio/tracks';
import { applyRun } from '@generated/data/progress';
import { audio } from '@generated/audio/arcadeAudio';
import { useSave, useSaveLifecycle } from '@generated/hooks/useSave';
import { MainMenu } from '@generated/components/menu/MainMenu';
import { Hangar } from '@generated/components/menu/Hangar';
import { Store } from '@generated/components/menu/Store';
import { BattlePass } from '@generated/components/menu/BattlePass';
import { Rewards } from '@generated/components/menu/Rewards';
import { Leaderboard, syncScore } from '@generated/components/menu/Leaderboard';
import { WarpGate } from '@generated/components/warp/WarpGate';
import { GameScreen } from '@generated/components/game/GameScreen';
import { ResultsScreen, type SyncState } from '@generated/components/game/ResultsScreen';
import { LegalScreen } from '@generated/components/legal/LegalScreen';
import { AgeGate } from '@generated/components/legal/AgeGate';
import { DownloadScreen } from '@generated/components/menu/DownloadScreen';
import { DonateScreen } from '@generated/components/donate/DonateScreen';
import { LEGAL_VERSION, type LegalTab } from '@generated/data/legal';

const SCREEN_MUSIC: Partial<Record<Screen, TrackId>> = {
  menu: 'menu', hangar: 'menu', shop: 'menu', pass: 'menu', rewards: 'menu', leaderboard: 'menu', results: 'menu', warp: 'warp', legal: 'menu', download: 'menu', donate: 'menu',
};

export default function App() {
  const hydrated = useSaveLifecycle();
  const { save, update } = useSave();
  const [screen, setScreen] = useState<Screen>('menu');
  const [runKey, setRunKey] = useState(0);
  const [lastRun, setLastRun] = useState<{ run: RunSummary; newBest: boolean } | null>(null);
  const [sync, setSync] = useState<SyncState>('syncing');
  const [legalTab, setLegalTab] = useState<LegalTab>('terms');
  const underage = save.legal.underage;
  const cleared = !underage && save.legal.version === LEGAL_VERSION;

  useEffect(() => {
    if (underage) audio.music(null);
  }, [underage]);

  const openLegal = useCallback((tab: LegalTab) => {
    setLegalTab(tab);
    setScreen('legal');
  }, []);

  useEffect(() => {
    document.documentElement.classList.add('dark');
    const unlock = () => audio.unlock();
    window.addEventListener('pointerdown', unlock);
    window.addEventListener('keydown', unlock);
    return () => {
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
    };
  }, []);

  useEffect(() => {
    audio.setEnabled(save.settings.music, save.settings.sfx);
  }, [save.settings.music, save.settings.sfx]);

  useEffect(() => {
    if (screen !== 'play') {
      window.scrollTo({ top: 0 });
      audio.music(SCREEN_MUSIC[screen] ?? 'menu');
    }
  }, [screen]);

  const launch = useCallback(() => {
    setRunKey((k) => k + 1);
    setScreen('play');
  }, []);

  const handleOver = (run: RunSummary) => {
    const next = applyRun(save, run);
    setLastRun({ run, newBest: run.wave > save.bestWave });
    update((s) => applyRun(s, run));
    setScreen('results');
    setSync('syncing');
    syncScore(next, run)
      .then(() => setSync('synced'))
      .catch((e: unknown) => {
        console.error('Leaderboard submit failed', e);
        setSync('failed');
      });
  };

  const back = () => setScreen('menu');

  if (!hydrated) {
    return (
      <div className="hud-grid grid min-h-[100dvh] place-items-center text-xs font-bold tracking-[0.24em] text-muted-foreground">
        <span className="hud-blink">BOOTING // NAV SYSTEMS</span>
      </div>
    );
  }

  if (!cleared) {
    return (
      <main className="hud-grid relative min-h-[100dvh] overflow-x-hidden text-foreground">
        <AgeGate />
      </main>
    );
  }

  return (
    <main className="hud-grid relative min-h-[100dvh] overflow-x-hidden text-foreground">
      {screen === 'menu' && <MainMenu go={setScreen} onLaunch={launch} onLegal={openLegal} />}
      {screen === 'legal' && <LegalScreen key={legalTab} initialTab={legalTab} onBack={back} />}
      {screen === 'download' && <DownloadScreen onBack={back} />}
      {screen === 'donate' && <DonateScreen onBack={back} />}
      {screen === 'hangar' && <Hangar onBack={back} onLaunch={launch} />}
      {screen === 'shop' && <Store onBack={back} onWarp={() => setScreen('warp')} />}
      {screen === 'pass' && <BattlePass onBack={back} />}
      {screen === 'rewards' && <Rewards onBack={back} />}
      {screen === 'warp' && <WarpGate onBack={back} />}
      {screen === 'leaderboard' && <Leaderboard onBack={back} />}
      {screen === 'play' && <GameScreen key={runKey} onOver={handleOver} />}
      {screen === 'results' && lastRun && (
        <ResultsScreen
          run={lastRun.run}
          newBest={lastRun.newBest}
          sync={sync}
          onFarm={launch}
          onHangar={() => setScreen('hangar')}
          onRanks={() => setScreen('leaderboard')}
          onMenu={back}
        />
      )}
    </main>
  );
}
