import type { SectionSpec, SongSpec } from '@generated/audio/tracks';

/* ───────────────────────── COMBAT // "SIEGE PROTOCOL" ─ A minor, 148 bpm, ~2:40 per pass ───────────────────────── */

const C_RIFF = `
  A4 - A4 C5 - A4 E5 - D5 - C5 - B4 - C5 - |
  A4 - A4 C5 - A4 F5 - E5 - D5 - C5 - D5 - |
  G4 - G4 B4 - G4 D5 - C5 - B4 - A4 - B4 - |
  E5 - - - D5 - - - B4 - - - G#4 - B4 -`;

const C_VERSE_A = `
  E5 - - - E5 - D5 E5 - - C5 - - - A4 - |
  F5 - - - F5 - E5 F5 - - A5 - G5 - F5 - |
  E5 - - - G5 - - - C6 - - - B5 - G5 - |
  D5 - - - - - B4 - D5 - G5 - - - - - |
  E5 - - - E5 - D5 E5 - - C5 - - - A4 - |
  F5 - - - A5 - - - C6 - B5 - A5 - F5 - |
  G#5 - - - - - E5 - B5 - - - A5 - G#5 - |
  E5 - - - - - - - - - - - - - - -`;

const C_VERSE_B = `
  A5 - - - G5 - E5 - G5 - A5 - - - E5 - |
  F5 - - - E5 - C5 - E5 - F5 - - - A5 - |
  G5 - - - E5 - C5 - G5 - C6 - - - D6 - |
  B5 - - - - - - - G5 - - - D5 - - - |
  A5 - - - G5 - E5 - G5 - A5 - - - C6 - |
  C6 - - - A5 - F5 - A5 - C6 - D6 - C6 - |
  B5 - - - G#5 - E5 - G#5 - B5 - D6 - - - |
  E6 - - - - - - - B5 - - - G#5 - - -`;

const C_PRE = `
  D5 - F5 - A5 - F5 - D5 - F5 - A5 - D6 - |
  E5 - G5 - B5 - G5 - E5 - G5 - B5 - E6 - |
  F5 - A5 - C6 - A5 - F5 - A5 - C6 - F6 - |
  G5 - - - - - - - B5 - - - D6 - - -`;

const C_CHORUS = `
  C6 - - - - - A5 - C6 - - - D6 - C6 - |
  B5 - - - - - G5 - D6 - - - - - B5 - |
  G5 - - - - - E5 - G5 - B5 - - - A5 - |
  A5 - - - - - - - E5 - - - A5 - C6 - |
  C6 - - - - - A5 - C6 - - - F6 - E6 - |
  D6 - - - - - B5 - D6 - - - G6 - - - |
  E6 - - - - - C6 - A5 - - - B5 - C6 - |
  A5 - - - - - - - - - - - - - - -`;

const C_BREAK = `
  E5 - - - - - - - - - - - - - - - |
  - - - - - - - - D5 - - - C5 - - - |
  C5 - - - - - - - - - - - - - - - |
  - - - - - - - - A4 - - - C5 - - - |
  D5 - - - - - - - - - - - - - - - |
  - - - - - - - - F5 - - - E5 - - - |
  E5 - - - - - - - - - - - - - - - |
  G#4 - - - - - - - B4 - - - E5 - - -`;

const C_SOLO = `
  A5 C6 E6 C6 A5 C6 E6 C6 A5 B5 C6 D6 E6 D6 C6 B5 |
  A5 C6 F6 C6 A5 C6 F6 C6 A5 B5 C6 D6 E6 F6 E6 D6 |
  B5 D6 G6 D6 B5 D6 G6 D6 B5 C6 D6 E6 F6 E6 D6 C6 |
  B5 - G#5 - E5 - G#5 - B5 - D6 - E6 - - - |
  E6 D6 C6 B5 A5 B5 C6 D6 E6 - A5 - E6 - G6 - |
  F6 E6 D6 C6 A5 C6 D6 E6 F6 - C6 - F6 - A6 - |
  G6 F6 E6 D6 B5 D6 E6 F6 G6 - D6 - B5 - G5 - |
  G#5 A5 B5 C6 D6 E6 F6 G#6 - - - - E6 - - -`;

const ROCK_KICK = 'x-----x-x---x---';
const BACKBEAT = '----x-------x---';
const EIGHTHS = 'x-x-x-x-x-x-x-x-';
const SIXTEENTHS = 'xxxxxxxxxxxxxxxx';
const ROLL = 'x-x-x-x-xxxxxxxx';

const cRiff: SectionSpec = {
  name: 'riff', bars: 8, chords: ['Am', 'F', 'G', 'E'], lead: C_RIFF, double: true,
  bass: 'x-xxx-xxx-xxx-xo', stabs: 'x--x--x---x--x--', kick: 'x-x---x-x-x---x-', snare: BACKBEAT, hat: EIGHTHS, fill: true, crash: true,
};
const cVerse = (lead: string): SectionSpec => ({
  name: 'verse', bars: 8, chords: ['Am', 'F', 'C', 'G', 'Am', 'F', 'E', 'E'], lead,
  bass: 'x-xox-xox-xox-xo', arp: [0, 2, 4, 2], arpEvery: 2, kick: ROCK_KICK, snare: BACKBEAT, hat: EIGHTHS, fill: true,
});
const cPre: SectionSpec = {
  name: 'pre', bars: 4, chords: ['Dm', 'Em', 'F', 'G'], lead: C_PRE, bass: SIXTEENTHS, arp: [0, 1, 2, 3, 4, 5, 4, 3],
  kick: 'x---x---x---x---', snare: BACKBEAT, hat: SIXTEENTHS, snareLast: ROLL,
};
const cChorus = (transpose = 0): SectionSpec => ({
  name: 'chorus', bars: 8, chords: ['F', 'G', 'Em', 'Am', 'F', 'G', 'Am', 'Am'], lead: C_CHORUS, double: true, pad: true,
  bass: 'x-x-x-x-x-x-o-x-', stabs: 'x-------x-------', kick: EIGHTHS, snare: BACKBEAT, open: '--x---x---x---x-', crash: true, fill: true, transpose,
});

const COMBAT: SongSpec = {
  bpm: 148,
  loopFrom: 1,
  cycleShift: [0, 1, 2],
  sections: [
    { name: 'intro', bars: 4, chords: ['Am', 'Am', 'F', 'G'], bass: EIGHTHS, arp: [0, 1, 2, 3, 2, 1], pad: true, kick: 'x-------x-------', hat: '--x---x---x---x-', snareLast: ROLL, crash: true },
    cRiff,
    cVerse(C_VERSE_A),
    cPre,
    cChorus(),
    cRiff,
    cVerse(C_VERSE_B),
    cPre,
    cChorus(),
    { name: 'breakdown', bars: 8, chords: ['Am', 'Am', 'F', 'F', 'Dm', 'Dm', 'E', 'E'], lead: C_BREAK, leadWave: 'triangle', bass: 'x-------x-------', arp: [0, 1, 2, 3, 4, 5, 4, 3], pad: true, kick: 'x-------x-x-----', snare: '--------x-------', hat: '----x-------x---' },
    { name: 'build', bars: 4, chords: ['Dm', 'Dm', 'E', 'E'], bass: SIXTEENTHS, arp: [0, 1, 2, 3, 4, 5, 3, 4], kick: 'x---x---x---x---', snare: '----x---x---x-x-', hat: SIXTEENTHS, snareLast: SIXTEENTHS },
    { name: 'solo', bars: 8, chords: ['Am', 'F', 'G', 'E'], lead: C_SOLO, leadOct: -1, bass: 'x-xxx-xxx-xxx-xx', stabs: 'x--x--x---x--x--', kick: EIGHTHS, snare: BACKBEAT, hat: EIGHTHS, crash: true, fill: true },
    cChorus(2),
    { ...cRiff, bars: 4, name: 'outro' },
  ],
};

/* ───────────────────────── BOSS // "LEVIATHAN RISING" ─ E phrygian, 168 bpm, ~2:00 per pass ───────────────────────── */

const B_RIFF = `
  E4 E4 - E4 F4 - E4 - G4 - E4 - F4 - E4 - |
  F4 F4 - F4 A4 - F4 - C5 - B4 - A4 - F4 - |
  E4 E4 - E4 G4 - E4 - B4 - A4 - G4 - F4 - |
  F4 - A4 - C5 - E5 - F5 - - - E5 - C5 -`;

const B_ASSAULT_A = `
  B5 - - - B5 - A5 B5 - - G5 - - - E5 - |
  C6 - - - B5 - G5 - E5 - - - G5 - C6 - |
  D6 - - - C6 - A5 - F#5 - - - A5 - D6 - |
  B5 - - - - - - - E5 - G5 - B5 - - - |
  B5 - - - B5 - A5 B5 - - G5 - - - E5 - |
  C6 - - - E6 - D6 - C6 - - - B5 - G5 - |
  A5 - - - D6 - C6 - A5 - - - F#5 - A5 - |
  B5 - - - - - D#6 - F#6 - - - D#6 - B5 -`;

const B_ASSAULT_B = `
  E5 - G5 - B5 - E6 - D6 - B5 - G5 - B5 - |
  C6 - - - G5 - E5 - G5 - C6 - E6 - - - |
  D6 - - - A5 - F#5 - A5 - D6 - F#6 - - - |
  E6 - D6 - B5 - G5 - E5 - - - - - - - |
  G5 - B5 - E6 - B5 - G5 - B5 - E6 - G6 - |
  G6 - E6 - C6 - G5 - E6 - C6 - G5 - E5 - |
  F#5 - A5 - D6 - F#6 - A6 - - - F#6 - D6 - |
  D#6 - - - - - B5 - F#5 - - - D#5 - - -`;

const B_PRE = `
  G5 - G5 - G5 - A5 - G5 - E5 - - - C5 - |
  A5 - A5 - A5 - B5 - A5 - F#5 - - - D5 - |
  B5 - - - - - A5 - B5 - - - D#6 - - - |
  F#6 - - - - - - - D#6 - - - B5 - - -`;

const B_CHORUS = `
  E6 - - - - - - - D6 - - - B5 - - - |
  C6 - - - - - - - B5 - - - G5 - - - |
  A5 - - - - - D6 - F#6 - - - E6 - D6 - |
  D#6 - - - - - - - B5 - - - - - - - |
  E6 - - - - - G6 - F#6 - - - E6 - - - |
  E6 - - - - - - - D6 - C6 - B5 - - - |
  A5 - - - - - B5 - C6 - - - D6 - F#6 - |
  E6 - - - - - - - - - - - - - - -`;

const B_BREAK = `
  B4 - - - - - - - C5 - - - - - - - |
  B4 - - - - - - - - - - - - - - - |
  E5 - - - - - - - D5 - - - C5 - - - |
  B4 - - - - - - - - - - - - - - - |
  D#5 - - - - - - - E5 - - - - - - - |
  F#5 - - - - - - - - - - - - - - - |
  A5 - - - - - G5 - F#5 - - - E5 - - - |
  D#5 - - - - - - - - - - - - - - -`;

const B_BLAST = `
  E5 F5 G5 F5 E5 F5 G5 B5 E5 F5 G5 F5 E5 D5 E5 F5 |
  F5 G5 A5 G5 F5 G5 A5 C6 F5 G5 A5 G5 F5 E5 F5 G5 |
  G5 A5 B5 A5 G5 A5 B5 E6 G5 A5 B5 A5 G5 F5 G5 A5 |
  A5 - C6 - F6 - E6 - C6 - A5 - F5 - - - |
  E6 D6 B5 G5 E6 D6 B5 G5 E6 D6 B5 G5 E5 - - - |
  F6 E6 C6 A5 F6 E6 C6 A5 F6 E6 C6 A5 F5 - - - |
  G6 F6 D6 B5 G6 F6 D6 B5 G5 B5 D6 G6 - - - - |
  F#6 - D#6 - B5 - F#5 - D#5 - F#5 - B5 - - -`;

const bRiff = (leadOct = 0): SectionSpec => ({
  name: 'riff', bars: 8, chords: ['Em', 'F', 'Em', 'F'], lead: B_RIFF, leadOct, double: leadOct > 0,
  bass: 'xxoxxoxxxxoxxoxx', stabs: 'x--x--x-x--x--x-', kick: 'x-xxx-x-x-xxx-x-', snare: BACKBEAT, hat: EIGHTHS, crash: true, fill: true,
});
const bAssault = (lead: string, leadOct = 0): SectionSpec => ({
  name: 'assault', bars: 8, chords: ['Em', 'C', 'D', 'Em', 'Em', 'C', 'D', 'B'], lead, leadOct,
  bass: 'x-xxx-xxx-xxx-xx', arp: [0, 2, 1, 2], kick: 'x-x-x-x-x-x-x-x-', snare: BACKBEAT, hat: SIXTEENTHS, fill: true,
});
const bChorus = (transpose = 0): SectionSpec => ({
  name: 'chorus', bars: 8, chords: ['Em', 'C', 'D', 'B', 'Em', 'C', 'D', 'Em'], lead: B_CHORUS, leadOct: -1, double: true, pad: true,
  bass: 'xxxxxxxxxxxxxxxx', stabs: 'x-------x---x---', kick: 'x-x-x-x-x-x-x-x-', snare: BACKBEAT, open: '--x---x---x---x-', crash: true, fill: true, transpose,
});

const BOSS: SongSpec = {
  bpm: 168,
  loopFrom: 1,
  cycleShift: [0, 1, 3],
  sections: [
    { name: 'alarm', bars: 4, chords: ['Em', 'Em', 'Em', 'F'], bass: EIGHTHS, stabs: 'x---x---x---x---', pad: true, kick: 'x---x---x---x---', snareLast: SIXTEENTHS, crash: true, fill: true },
    bRiff(),
    bAssault(B_ASSAULT_A),
    { name: 'pre', bars: 4, chords: ['C', 'D', 'B', 'B'], lead: B_PRE, bass: SIXTEENTHS, arp: [0, 1, 2, 3, 4, 5, 4, 3], kick: 'x---x---x---x---', snare: '----x---x---x---', hat: SIXTEENTHS, snareLast: ROLL },
    bChorus(),
    bRiff(1),
    bAssault(B_ASSAULT_B, -1),
    { name: 'breakdown', bars: 8, chords: ['Em', 'Em', 'C', 'C', 'B', 'B', 'B', 'B'], lead: B_BREAK, leadWave: 'triangle', bass: 'x-------x-------', pad: true, stabs: 'x---------------', kick: 'x-------x-x-----', snare: '--------x-------', hat: '----x-------x---', snareLast: ROLL },
    { name: 'blast', bars: 8, chords: ['Em', 'F', 'Em', 'F', 'Em', 'F', 'G', 'B'], lead: B_BLAST, leadOct: -1, bass: SIXTEENTHS, stabs: 'x--x--x---x--x--', kick: SIXTEENTHS, snare: '----x-------x---', hat: EIGHTHS, crash: true, fill: true },
    bChorus(1),
    { ...bRiff(), bars: 4, name: 'outro' },
  ],
};

/* ───────────────────────── MENU // "COMMAND DECK" ─ D minor, 104 bpm, ~2:10 per pass ───────────────────────── */

const M_THEME_A = `
  D5 - - - - - A4 - D5 - E5 - F5 - - - |
  F5 - - - E5 - D5 - - - C5 - D5 - - - |
  C5 - - - - - A4 - C5 - D5 - E5 - F5 - |
  E5 - - - - - - - G5 - - - - - - - |
  G5 - - - - - F5 - E5 - D5 - - - G5 - |
  F5 - - - - - D5 - - - Bb4 - D5 - F5 - |
  E5 - - - - - - - C#5 - - - E5 - - - |
  A5 - - - - - - - - - - - - - - -`;

const M_THEME_B = `
  D6 - - - - - C6 - Bb5 - - - A5 - - - |
  G5 - - - - - E5 - G5 - - - C6 - - - |
  A5 - - - - - - - F5 - - - D5 - - - |
  D5 - - - F5 - - - A5 - - - D6 - - - |
  Bb5 - - - - - A5 - G5 - - - D5 - - - |
  C#6 - - - - - - - A5 - - - E5 - - - |
  F5 - - - - - E5 - D5 - - - A5 - - - |
  E5 - - - - - - - - - - - C#5 - - -`;

const M_MARCH = `
  D4 - - D4 D4 - F4 - A4 - - - G4 - F4 - |
  E4 - - E4 E4 - G4 - A4 - - - - - - - |
  D4 - - D4 D4 - F4 - Bb4 - - - A4 - G4 - |
  F4 - - F4 F4 - G4 - A4 - - - - - - - |
  G4 - - G4 G4 - Bb4 - D5 - - - C5 - Bb4 - |
  A4 - - A4 A4 - Bb4 - C5 - - - D5 - - - |
  E5 - - - C#5 - - - A4 - - - C#5 - - - |
  E5 - - - - - - - - - - - - - - -`;

const M_BRIDGE = `
  G5 - - - Bb5 - - - D6 - - - C6 - Bb5 - |
  A5 - - - - - - - F5 - - - - - - - |
  Bb5 - - - D6 - - - F6 - - - Eb6 - D6 - |
  C#6 - - - - - - - E6 - - - - - - - |
  G6 - - - F6 - - - D6 - - - Bb5 - - - |
  A5 - - - F5 - - - D5 - - - F5 - - - |
  G5 - - - Bb5 - - - Eb6 - - - D6 - C6 - |
  C#6 - - - - - - - - - - - A5 - - -`;

const mThemeA = (heavy: boolean): SectionSpec => ({
  name: 'themeA', bars: 8, chords: ['Dm', 'Bb', 'F', 'C', 'Gm', 'Bb', 'A', 'A'], lead: M_THEME_A,
  leadWave: heavy ? 'square' : 'triangle', double: heavy, pad: true, arp: [0, 1, 2, 3], arpEvery: 2,
  bass: heavy ? 'x-xox-xox-xox-xo' : 'x-------x---x---', stabs: heavy ? 'x-------x-------' : undefined,
  kick: heavy ? 'x---x---x---x---' : 'x-------x-------', snare: heavy ? BACKBEAT : '--------x-------', hat: '--x---x---x---x-',
  open: heavy ? '------x-------x-' : undefined, crash: heavy, fill: true,
});

const MENU: SongSpec = {
  bpm: 104,
  loopFrom: 1,
  sections: [
    { name: 'intro', bars: 4, chords: ['Dm', 'Bb', 'F', 'A'], pad: true, arp: [0, 1, 2, 3, 2, 1, 0, 2], arpEvery: 2, bass: 'x---------------', kick: 'x---------------', crash: true, fill: true },
    mThemeA(false),
    { name: 'themeB', bars: 8, chords: ['Bb', 'C', 'Dm', 'Dm', 'Gm', 'A', 'Dm', 'A'], lead: M_THEME_B, pad: true, bass: 'x---x---x---x---', arp: [0, 2, 4, 2], arpEvery: 2, kick: ROCK_KICK, snare: BACKBEAT, hat: EIGHTHS, fill: true },
    { name: 'march', bars: 8, chords: ['Dm', 'Dm', 'Bb', 'Bb', 'Gm', 'Gm', 'A', 'A'], lead: M_MARCH, leadOct: 1, double: true, bass: 'x--xx-x-x--xx-x-', stabs: 'x--x----x--x----', kick: 'x---x---x---x---', snare: '----x--x----x-xx', snareLast: ROLL },
    mThemeA(true),
    { name: 'bridge', bars: 8, chords: ['Gm', 'Dm', 'Bb', 'A', 'Gm', 'Dm', 'Eb', 'A'], lead: M_BRIDGE, leadOct: -1, pad: true, arp: [0, 1, 2, 3, 4, 5, 4, 3], bass: 'x-x-x-x-x-x-x-x-', kick: 'x-----x-x-------', snare: BACKBEAT, hat: EIGHTHS, snareLast: ROLL },
    { name: 'finale', bars: 8, chords: ['Bb', 'C', 'Dm', 'Dm', 'Gm', 'A', 'Dm', 'A'], lead: M_THEME_B, double: true, pad: true, bass: 'x-xox-xox-xox-xo', stabs: 'x-------x-------', kick: 'x---x---x---x---', snare: BACKBEAT, open: '--x---x---x---x-', crash: true, fill: true, transpose: 2 },
    { name: 'outro', bars: 4, chords: ['Dm', 'Bb', 'Gm', 'A'], pad: true, arp: [0, 1, 2, 3, 2, 1, 0, 2], arpEvery: 2, bass: 'x---------------', kick: 'x-------x-------', fill: true },
  ],
};

/* ───────────────────────── WARP GATE // "SINGULARITY" ─ E minor, 76 bpm ───────────────────────── */

const WARP: SongSpec = {
  bpm: 76,
  loopFrom: 0,
  sections: [
    {
      name: 'drift', bars: 8, chords: ['Em', 'C', 'Am', 'B'], pad: true, arp: [0, 1, 2, 4, 3, 1], arpEvery: 2, bass: 'x---------------', hat: '--------x-------',
      lead: `- - - - - - - - B5 - - - - - - - | - - - - - - - - G5 - - - - - - - | - - - - - - - - E5 - - - - - - - | - - - - - - - - D#5 - - - - - - -`,
      leadWave: 'sine',
    },
    {
      name: 'pulse', bars: 8, chords: ['C', 'G', 'Am', 'B'], pad: true, arp: [0, 2, 4, 2, 3, 5], arpEvery: 1, bass: 'x-------x-------', kick: 'x-------x-------', hat: '----x-------x---',
      lead: `E6 - - - - - - - D6 - - - B5 - - - | D6 - - - - - - - B5 - - - G5 - - - | C6 - - - - - - - E6 - - - - - - - | D#6 - - - - - - - F#6 - - - - - - -`,
      leadWave: 'sine', crash: true,
    },
  ],
};

export const SONGS = { menu: MENU, combat: COMBAT, boss: BOSS, warp: WARP };
