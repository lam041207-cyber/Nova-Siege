/** Song format + compiler. Songs are arranged in sections (intro, verse, chorus, breakdown…) of 16-step bars. */
import { SONGS } from '@generated/audio/songs';

export type TrackId = 'menu' | 'combat' | 'boss' | 'warp';
export type Voice = 'bass' | 'lead' | 'double' | 'arp' | 'pad' | 'stab';
export type Drum = 'k' | 's' | 'h' | 'o' | 'c' | 't1' | 't2' | 't3';

export interface NoteEv {
  v: Voice;
  m: number;
  len: number;
  w?: OscillatorType;
}

export interface Step {
  notes: NoteEv[];
  drums: Drum[];
}

export interface Track {
  bpm: number;
  steps: Step[];
  loopStep: number;
  sectionStarts: number[];
  /** semitone shift applied on each full pass so repeats feel like a rising key change */
  cycleShift: number[];
}

export interface SectionSpec {
  name: string;
  bars: number;
  /** chord symbol per bar, cycled: 'Am', 'F', 'C#m', 'Bb', 'E5', 'Bdim', 'Dsus' */
  chords: string[];
  /** bars separated by '|', 16 whitespace tokens per bar ('-' = rest); cycled */
  lead?: string;
  leadOct?: number;
  leadWave?: OscillatorType;
  double?: boolean;
  /** x root · o octave · f fifth · '-' rest, 16 chars */
  bass?: string;
  /** chord-tone indexes 0-5 (5 = fifth, an octave up) */
  arp?: number[];
  arpEvery?: number;
  pad?: boolean;
  stabs?: string;
  kick?: string;
  snare?: string;
  hat?: string;
  open?: string;
  /** snare pattern for the final bar (roll / build) */
  snareLast?: string;
  fill?: boolean;
  crash?: boolean;
  transpose?: number;
}

export interface SongSpec {
  bpm: number;
  loopFrom: number;
  cycleShift?: number[];
  sections: SectionSpec[];
}

const SEMI: Record<string, number> = { C: 0, 'C#': 1, Db: 1, D: 2, 'D#': 3, Eb: 3, E: 4, F: 5, 'F#': 6, Gb: 6, G: 7, 'G#': 8, Ab: 8, A: 9, 'A#': 10, Bb: 10, B: 11 };

export function note(name: string): number {
  const m = /^([A-G][#b]?)(-?\d)$/.exec(name);
  if (!m) return 60;
  return 12 * (Number(m[2]) + 1) + (SEMI[m[1] ?? 'C'] ?? 0);
}

export const mtof = (m: number) => 440 * Math.pow(2, (m - 69) / 12);

/** Chord symbol → root (octave 3 midi) and six arp tones (triad + triad an octave up). */
function chord(sym: string): { root: number; tones: number[] } {
  const m = /^([A-G][#b]?)(m|dim|sus|5)?$/.exec(sym);
  const root = 48 + (SEMI[m?.[1] ?? 'A'] ?? 9);
  const q = m?.[2];
  const third = q === 'm' || q === 'dim' ? 3 : q === 'sus' ? 5 : q === '5' ? 7 : 4;
  const fifth = q === 'dim' ? 6 : q === '5' ? 12 : 7;
  const tri = [root + 12, root + 12 + third, root + 12 + fifth];
  return { root, tones: [...tri, ...tri.map((n) => n + 12)] };
}

const at = (pattern: string | undefined, i: number) => (pattern ? pattern[i % pattern.length] : '-');

function lengthUntilNext(tokens: string[], i: number, max: number): number {
  let len = 1;
  while (len < max && (tokens[i + len] ?? '-') === '-' && i + len < tokens.length) len++;
  return len;
}

function compile(song: SongSpec): Track {
  const steps: Step[] = [];
  const sectionStarts: number[] = [];
  for (const sec of song.sections) {
    sectionStarts.push(steps.length);
    const tr = sec.transpose ?? 0;
    const leadBars = sec.lead ? sec.lead.split('|').map((b) => b.trim().split(/\s+/)) : [];
    const bassTokens = (sec.bass ?? '').split('');
    for (let bar = 0; bar < sec.bars; bar++) {
      const ch = chord(sec.chords[bar % sec.chords.length] ?? 'Am');
      const lastBar = bar === sec.bars - 1;
      const leadTokens = leadBars.length ? (leadBars[bar % leadBars.length] ?? []) : [];
      for (let s = 0; s < 16; s++) {
        const notes: NoteEv[] = [];
        const drums: Drum[] = [];
        // bass
        const b = bassTokens[s];
        if (b && b !== '-') {
          const m = ch.root - 12 + (b === 'o' ? 12 : b === 'f' ? 7 : 0) + tr;
          notes.push({ v: 'bass', m, len: Math.min(8, lengthUntilNext(bassTokens, s, 8)) });
        }
        // lead
        const tk = leadTokens[s];
        if (tk && tk !== '-') {
          const m = note(tk) + (sec.leadOct ?? 0) * 12 + tr;
          const len = lengthUntilNext(leadTokens, s, 8);
          notes.push({ v: 'lead', m, len, w: sec.leadWave });
          if (sec.double) notes.push({ v: 'double', m: m - 12, len });
        }
        // arp
        if (sec.arp?.length) {
          const every = sec.arpEvery ?? 1;
          if (s % every === 0) {
            const idx = sec.arp[Math.floor((bar * 16 + s) / every) % sec.arp.length] ?? 0;
            notes.push({ v: 'arp', m: (ch.tones[idx] ?? ch.root) + tr, len: every });
          }
        }
        // pad: whole-bar chord
        if (sec.pad && s === 0) for (const n of ch.tones.slice(0, 3)) notes.push({ v: 'pad', m: n + tr, len: 16 });
        if (at(sec.stabs, s) === 'x') notes.push({ v: 'stab', m: ch.root + tr, len: 2 });
        // drums
        if (at(sec.kick, s) === 'x') drums.push('k');
        const snare = lastBar && sec.snareLast ? sec.snareLast : sec.snare;
        const fillZone = lastBar && sec.fill && s >= 12;
        if (fillZone) drums.push(s === 12 || s === 13 ? 't1' : s === 14 ? 't2' : 't3');
        else if (at(snare, s) === 'x') drums.push('s');
        if (at(sec.hat, s) === 'x') drums.push('h');
        if (at(sec.open, s) === 'x') drums.push('o');
        if (sec.crash && bar === 0 && s === 0) drums.push('c');
        steps.push({ notes, drums });
      }
    }
  }
  return {
    bpm: song.bpm,
    steps,
    loopStep: sectionStarts[song.loopFrom] ?? 0,
    sectionStarts,
    cycleShift: song.cycleShift ?? [0],
  };
}

export const TRACKS: Record<TrackId, Track> = {
  menu: compile(SONGS.menu),
  combat: compile(SONGS.combat),
  boss: compile(SONGS.boss),
  warp: compile(SONGS.warp),
};
