import { TRACKS, mtof, type Drum, type NoteEv, type Track, type TrackId } from '@generated/audio/tracks';

export type SfxName =
  | 'shoot' | 'hit' | 'explode' | 'bigExplode' | 'chain' | 'coin' | 'power' | 'playerHit' | 'shieldHit'
  | 'bossWarn' | 'bossSpawn' | 'bossDown' | 'bomb' | 'waveStart' | 'perkOffer' | 'perkPick' | 'revive' | 'death'
  | 'click' | 'buy' | 'claim' | 'error' | 'charge' | 'reveal3' | 'reveal4' | 'reveal5' | 'star' | 'flip';

const THROTTLE: Partial<Record<SfxName, number>> = { shoot: 0.07, hit: 0.045, explode: 0.05, chain: 0.06, coin: 0.055, shieldHit: 0.1, star: 0.04, flip: 0.05 };

type FilterKind = 'lowpass' | 'highpass' | 'bandpass';

interface SynthOpts {
  cutoff?: number;
  attack?: number;
  release?: number;
  detunes?: number[];
  slideTo?: number;
  sustain?: number;
}

/** Synthesised retro arcade sound: Web Audio oscillators + noise, no audio files. */
class ArcadeAudio {
  private ctx: AudioContext | null = null;
  private musicBus: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private echo: DelayNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private musicOn = true;
  private sfxOn = true;
  private desired: TrackId | null = null;
  private desiredResume = false;
  private playing: TrackId | null = null;
  private timer: ReturnType<typeof setInterval> | null = null;
  private step = 0;
  private cycle = 0;
  private nextTime = 0;
  private saved = new Map<TrackId, { step: number; cycle: number }>();
  private last = new Map<SfxName, number>();

  /** Call from a user gesture; browsers block audio until then. */
  unlock() {
    if (typeof window === 'undefined') return;
    if (!this.ctx) {
      const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      const ctx = new AC();
      const master = ctx.createGain();
      master.gain.value = 0.8;
      const comp = ctx.createDynamicsCompressor();
      master.connect(comp).connect(ctx.destination);
      this.musicBus = ctx.createGain();
      this.sfxBus = ctx.createGain();
      this.musicBus.gain.value = this.musicOn ? 0.6 : 0;
      this.sfxBus.gain.value = this.sfxOn ? 0.9 : 0;
      this.musicBus.connect(master);
      this.sfxBus.connect(master);
      // stereo-less echo send for the lead line
      const echo = ctx.createDelay(1);
      echo.delayTime.value = 0.3;
      const fb = ctx.createGain();
      fb.gain.value = 0.3;
      const wet = ctx.createGain();
      wet.gain.value = 0.22;
      const tone = ctx.createBiquadFilter();
      tone.type = 'lowpass';
      tone.frequency.value = 2400;
      echo.connect(tone).connect(fb).connect(echo);
      tone.connect(wet).connect(this.musicBus);
      this.echo = echo;
      const buf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
      this.noiseBuf = buf;
      this.ctx = ctx;
    }
    if (this.ctx.state === 'suspended') this.ctx.resume().catch((e: unknown) => console.error('Audio resume failed', e));
    if (this.desired !== this.playing) this.startTrack(this.desired, this.desiredResume);
  }

  get ready() {
    return this.ctx !== null;
  }

  setEnabled(music: boolean, sfx: boolean) {
    this.musicOn = music;
    this.sfxOn = sfx;
    const ctx = this.ctx;
    if (!ctx || !this.musicBus || !this.sfxBus) return;
    this.musicBus.gain.setTargetAtTime(music ? 0.6 : 0, ctx.currentTime, 0.08);
    this.sfxBus.gain.setTargetAtTime(sfx ? 0.9 : 0, ctx.currentTime, 0.05);
  }

  /** Switch songs. `resume` continues a song from the next section after where it was left. */
  music(id: TrackId | null, resume = false) {
    this.desired = id;
    this.desiredResume = resume;
    if (!this.ctx || id === this.playing) return;
    this.startTrack(id, resume);
  }

  private startTrack(id: TrackId | null, resume: boolean) {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    if (this.playing) this.saved.set(this.playing, { step: this.step, cycle: this.cycle });
    this.playing = id;
    const ctx = this.ctx;
    if (!ctx || !id) return;
    const track = TRACKS[id];
    this.step = 0;
    this.cycle = 0;
    const prev = this.saved.get(id);
    if (resume && prev) {
      const next = track.sectionStarts.find((s) => s > prev.step);
      this.step = next ?? track.loopStep;
      this.cycle = next === undefined ? prev.cycle + 1 : prev.cycle;
    }
    this.nextTime = ctx.currentTime + 0.08;
    this.timer = setInterval(() => this.schedule(track), 25);
  }

  private schedule(tr: Track) {
    const ctx = this.ctx;
    if (!ctx || !this.musicBus) return;
    const stepDur = 60 / tr.bpm / 4;
    if (this.nextTime < ctx.currentTime - 0.3) this.nextTime = ctx.currentTime + 0.02;
    while (this.nextTime < ctx.currentTime + 0.14) {
      const shift = tr.cycleShift[this.cycle % tr.cycleShift.length] ?? 0;
      const st = tr.steps[this.step];
      if (st) {
        for (const n of st.notes) this.playNote(n, shift, this.nextTime, stepDur, this.musicBus);
        for (const d of st.drums) this.playDrum(d, this.nextTime, this.musicBus);
      }
      this.nextTime += stepDur;
      this.step++;
      if (this.step >= tr.steps.length) {
        this.step = tr.loopStep;
        this.cycle++;
      }
    }
  }

  private playNote(n: NoteEv, shift: number, t: number, sd: number, bus: GainNode) {
    const f = mtof(n.m + shift);
    const dur = n.len * sd;
    switch (n.v) {
      case 'bass':
        this.synth(f, t, dur * 0.92, 'sawtooth', 0.11, [bus], { cutoff: 700, release: 0.05 });
        this.synth(f / 2, t, dur * 0.92, 'sine', 0.13, [bus], { release: 0.05 });
        break;
      case 'lead': {
        const w = n.w ?? 'square';
        const dests: AudioNode[] = this.echo ? [bus, this.echo] : [bus];
        this.synth(f, t, dur * 0.94, w, w === 'square' ? 0.042 : 0.09, dests, { cutoff: 3400, detunes: w === 'square' ? [-7, 7] : [0], attack: 0.01, release: 0.09 });
        break;
      }
      case 'double':
        this.synth(f, t, dur * 0.94, 'triangle', 0.07, [bus], { release: 0.08 });
        break;
      case 'arp':
        this.synth(f, t, Math.min(dur, sd) * 0.85, 'square', 0.022, [bus], { cutoff: 2200 });
        break;
      case 'pad':
        this.synth(f, t, dur, 'sawtooth', 0.016, [bus], { cutoff: 1100, detunes: [-10, 10], attack: 0.25, release: 0.35, sustain: 0.85 });
        break;
      case 'stab':
        for (const k of [1, 1.5, 2]) this.synth(f * k, t, dur * 0.9, 'sawtooth', 0.04, [bus], { cutoff: 1900, detunes: [-6, 6], release: 0.04 });
        break;
    }
  }

  private playDrum(d: Drum, t: number, bus: GainNode) {
    switch (d) {
      case 'k':
        this.tone(160, t, 0.18, 'sine', 0.55, bus, 42);
        this.noise(t, 0.012, 0.12, bus, 'lowpass', 3000);
        break;
      case 's':
        this.noise(t, 0.15, 0.2, bus, 'bandpass', 1800);
        this.tone(195, t, 0.08, 'triangle', 0.08, bus, 150);
        break;
      case 'h': this.noise(t, 0.03, 0.045, bus, 'highpass', 8000); break;
      case 'o': this.noise(t, 0.16, 0.05, bus, 'highpass', 7000); break;
      case 'c': this.noise(t, 1.4, 0.09, bus, 'highpass', 5000); break;
      case 't1': this.tone(220, t, 0.24, 'sine', 0.34, bus, 120); break;
      case 't2': this.tone(160, t, 0.26, 'sine', 0.36, bus, 90); break;
      case 't3': this.tone(110, t, 0.3, 'sine', 0.4, bus, 60); break;
    }
  }

  /** Filtered, optionally detuned voice with an attack / sustain / release envelope. */
  private synth(freq: number, t: number, dur: number, type: OscillatorType, vol: number, dests: AudioNode[], o: SynthOpts = {}) {
    const ctx = this.ctx;
    if (!ctx) return;
    const g = ctx.createGain();
    let input: AudioNode = g;
    if (o.cutoff) {
      const f = ctx.createBiquadFilter();
      f.type = 'lowpass';
      f.frequency.value = o.cutoff;
      f.connect(g);
      input = f;
    }
    const attack = o.attack ?? 0.006;
    const release = o.release ?? 0.06;
    const end = t + Math.max(dur, attack + 0.01);
    for (const det of o.detunes ?? [0]) {
      const osc = ctx.createOscillator();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, t);
      osc.detune.value = det;
      if (o.slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(20, o.slideTo), end);
      osc.connect(input);
      osc.start(t);
      osc.stop(end + release + 0.05);
    }
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + attack);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol * (o.sustain ?? 0.55)), end);
    g.gain.exponentialRampToValueAtTime(0.0001, end + release);
    for (const d of dests) g.connect(d);
  }

  private tone(freq: number, t: number, dur: number, type: OscillatorType, vol: number, dest: AudioNode, slideTo?: number) {
    const ctx = this.ctx;
    if (!ctx) return;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(dest);
    o.start(t);
    o.stop(t + dur + 0.03);
  }

  private noise(t: number, dur: number, vol: number, dest: AudioNode, kind: FilterKind, freq: number, freqEnd?: number) {
    const ctx = this.ctx;
    if (!ctx || !this.noiseBuf) return;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    const f = ctx.createBiquadFilter();
    f.type = kind;
    f.frequency.setValueAtTime(freq, t);
    if (freqEnd) f.frequency.exponentialRampToValueAtTime(Math.max(20, freqEnd), t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f).connect(g).connect(dest);
    src.start(t, Math.random() * 0.5);
    src.stop(t + dur + 0.03);
  }

  private arp(notes: number[], t: number, each: number, type: OscillatorType, vol: number, dest: AudioNode) {
    notes.forEach((f, i) => this.tone(f, t + i * each, each * 1.6, type, vol, dest));
  }

  sfx(name: SfxName, arg = 0) {
    const ctx = this.ctx;
    const bus = this.sfxBus;
    if (!ctx || !bus || !this.sfxOn) return;
    const t = ctx.currentTime;
    const gap = THROTTLE[name];
    if (gap) {
      const prev = this.last.get(name) ?? -1;
      if (t - prev < gap) return;
      this.last.set(name, t);
    }
    switch (name) {
      case 'shoot': this.tone(1250, t, 0.05, 'square', 0.03, bus, 520); break;
      case 'hit': this.tone(340, t, 0.04, 'triangle', 0.05, bus, 170); break;
      case 'explode':
        this.noise(t, 0.28, 0.2, bus, 'lowpass', 2400, 260);
        this.tone(150, t, 0.2, 'sine', 0.14, bus, 45);
        break;
      case 'bigExplode':
        this.noise(t, 0.75, 0.32, bus, 'lowpass', 1800, 110);
        this.tone(95, t, 0.6, 'sine', 0.28, bus, 28);
        break;
      case 'chain':
        this.noise(t, 0.18, 0.14, bus, 'bandpass', 1300, 380);
        this.tone(230, t, 0.12, 'square', 0.04, bus, 60);
        break;
      case 'coin':
        this.tone(988, t, 0.05, 'square', 0.045, bus);
        this.tone(1319, t + 0.05, 0.12, 'square', 0.045, bus);
        break;
      case 'power': this.arp([523, 659, 784, 1047], t, 0.055, 'square', 0.06, bus); break;
      case 'playerHit':
        this.tone(260, t, 0.25, 'sawtooth', 0.11, bus, 70);
        this.noise(t, 0.15, 0.14, bus, 'lowpass', 1200);
        break;
      case 'shieldHit': this.tone(900, t, 0.12, 'triangle', 0.08, bus, 380); break;
      case 'bossWarn':
        for (let i = 0; i < 6; i++) this.tone(i % 2 ? 330 : 440, t + i * 0.2, 0.18, 'square', 0.07, bus);
        break;
      case 'bossSpawn':
        this.tone(58, t, 1.3, 'sawtooth', 0.18, bus, 38);
        this.noise(t, 1.1, 0.12, bus, 'lowpass', 500, 90);
        break;
      case 'bossDown':
        this.sfx('bigExplode');
        this.noise(t + 0.15, 1.2, 0.25, bus, 'lowpass', 1200, 60);
        this.arp([523, 659, 784, 1047, 1319, 1568], t + 0.45, 0.09, 'square', 0.07, bus);
        break;
      case 'bomb':
        this.noise(t, 1.3, 0.42, bus, 'lowpass', 3200, 70);
        this.tone(320, t, 1.0, 'sine', 0.34, bus, 24);
        this.tone(80, t, 0.5, 'square', 0.08, bus, 30);
        break;
      case 'waveStart':
        this.tone(660, t, 0.08, 'square', 0.05, bus);
        this.tone(990, t + 0.09, 0.12, 'square', 0.05, bus);
        break;
      case 'perkOffer': this.arp([392, 523, 659, 784, 1047], t, 0.07, 'triangle', 0.09, bus); break;
      case 'perkPick': this.arp([784, 1047, 1568], t, 0.06, 'square', 0.06, bus); break;
      case 'revive':
        this.tone(200, t, 0.8, 'sine', 0.15, bus, 1600);
        this.arp([523, 784, 1047, 1568], t + 0.5, 0.08, 'square', 0.06, bus);
        break;
      case 'death':
        this.sfx('bigExplode');
        this.arp([523, 392, 330, 262, 196], t + 0.3, 0.13, 'square', 0.06, bus);
        break;
      case 'click': this.tone(720, t, 0.03, 'square', 0.035, bus); break;
      case 'buy': this.arp([660, 990, 1320], t, 0.05, 'square', 0.05, bus); break;
      case 'claim': this.arp([784, 988, 1175, 1568], t, 0.05, 'square', 0.05, bus); break;
      case 'error': this.tone(160, t, 0.14, 'square', 0.05, bus, 120); break;
      case 'charge':
        this.tone(110, t, 1.9, 'sawtooth', 0.06, bus, 1400);
        this.tone(220, t, 1.9, 'sine', 0.1, bus, 2200);
        this.noise(t, 1.9, 0.08, bus, 'highpass', 300, 6000);
        break;
      case 'reveal3': this.arp([523, 659, 784], t, 0.07, 'square', 0.06, bus); break;
      case 'reveal4':
        this.arp([523, 659, 784, 1047, 1319], t, 0.07, 'square', 0.06, bus);
        this.noise(t, 0.6, 0.08, bus, 'highpass', 5000);
        break;
      case 'reveal5':
        for (const f of [523, 659, 784, 1047]) this.tone(f, t, 1.6, 'sawtooth', 0.035, bus);
        this.arp([1047, 1319, 1568, 2093, 2637], t + 0.2, 0.08, 'square', 0.05, bus);
        this.noise(t, 1.4, 0.16, bus, 'highpass', 3000, 9000);
        this.tone(65, t, 1.2, 'sine', 0.25, bus, 40);
        break;
      case 'star': this.tone(1400 + arg * 220, t, 0.12, 'square', 0.05, bus); break;
      case 'flip': this.noise(t, 0.08, 0.08, bus, 'bandpass', 2600, 900); break;
    }
  }
}

export const audio = new ArcadeAudio();
