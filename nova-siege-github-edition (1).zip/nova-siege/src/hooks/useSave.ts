import { useCallback, useEffect } from 'react';
import { atom, useAtom } from 'jotai';
import { DEFAULT_SAVE, normalizeSave, type SaveData } from '@generated/data/progress';

const STORAGE_KEY = 'nova-siege-save-v1';

const saveAtom = atom<SaveData>(DEFAULT_SAVE);
const hydratedAtom = atom(false);

export function useSave() {
  const [save, setSave] = useAtom(saveAtom);
  const update = useCallback((fn: (s: SaveData) => SaveData) => setSave((prev) => fn(prev)), [setSave]);
  return { save, update };
}

/** Mount once at the app root: loads progress from this device and keeps it saved. */
export function useSaveLifecycle(): boolean {
  const [save, setSave] = useAtom(saveAtom);
  const [hydrated, setHydrated] = useAtom(hydratedAtom);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setSave(normalizeSave(JSON.parse(raw)));
    } catch (e) {
      console.error('Could not load saved progress', e);
    }
    setHydrated(true);
  }, [setSave, setHydrated]);

  useEffect(() => {
    if (!hydrated) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(save));
    } catch (e) {
      console.error('Could not save progress', e);
    }
  }, [save, hydrated]);

  return hydrated;
}
